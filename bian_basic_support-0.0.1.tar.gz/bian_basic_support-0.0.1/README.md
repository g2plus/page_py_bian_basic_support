<center><font size=13 color=#1E90FF>py_bian_basic_support</font></center>

# 项目概述

## 概述

python公用基础能力提供

## 打包与安装

### whl包安装(推荐)

> 打包编译

```python
python setup.py bdist_wheel sdist
```

执行完毕会生成`build`、`egg-info`和`dist`文件，build下放的是源码，dist下放的是编译好的包

通过运行这个命令，可以将Python项目打包成不同的分发包，以便于发布和安装

> 安装

用户可以使用 `pip` 来安装 wheel 分发包(`--force-reinstall`表示强制安装)

```cmd
pip install --force-reinstall -i https://pypi.tuna.tsinghua.edu.cn/simple/ bian_basic_support-0.0.1-py3-none-any.whl

pip install --force-reinstall --no-deps bian-basic-support
```

### 源码安装

在源码根目录下执行

```python
python install .

# or
python setup.py install
```

### 仓库安装

```cmd
pip install --extra-index-url http://192.168.123.21:8080/simple/ --trusted-host 192.168.123.21:8080 bian-basic-support
```

简化版(需要配置.pip)

```cmd
pip install --force-reinstall --no-deps bian-basic-support
```



# 项目结构规范

xxx



# 项目依赖

## 导出依赖

> 安装pipreqs

```cmd
pip install pipreqs
```

> 导出依赖, 强制覆盖原先的依赖

```cmd
pipreqs ./  --encoding=utf8 --force
```

## 安装依赖

> 安装依赖库

```cmd
pip install -r requirements.txt
```

### 离线安装

> 单个下载

```cmd
pip download package_name -d "下载的路径(windows下双引号来表示文件夹)"
```

> 批量下载

```cmd
pip download -d /tmp/packages -r requirements.txt
```

> 批量安装已经导出的包
>
> 其中 --no-index 代表忽视pip 忽视默认的依赖包索引
>
> --find-links= 代表从你指定的目录寻下找离线包 

```cmd
pip install --no-index --find-links=/tmp/packages -r requirements.txt
```