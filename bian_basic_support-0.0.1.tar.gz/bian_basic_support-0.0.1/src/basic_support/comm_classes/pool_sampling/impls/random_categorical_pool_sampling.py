# -*- encoding: utf-8 -*-
"""
@File    : random_categorical_pool_sampling.py
@Time    : 2022/5/30 11:33
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from collections.abc import Sequence
from itertools import groupby, chain
from typing import Iterable, List, Union, Dict

import petl as etl

from basic_calc.etl_process.petl_utils import gen_table_meta_and_head_content, head
from basic_support.comm_classes.pool_sampling.impls.random_pool_sampling import RandomPoolSampling


class RandomCategoricalPoolSampling(RandomPoolSampling):
    def __init__(self, sequence: Iterable, categorical_col_index: List[int],
                 sampling_size: Union[int, List[int], Dict[str, List[int]]], seed: int = None,
                 pool_size: int = 10000, keep_last: bool = False, presort: bool = True):
        super().__init__(sequence, sampling_size, seed, pool_size, keep_last)
        self.seed = seed
        self.presort = presort
        self.categorical_col_index = categorical_col_index
        self.__categorical_set = set()

    def __single_categorical_pool_sampling(self, sequence: Iterable, sampling_size: Union[int, List[int]]):
        pool_sampling = RandomPoolSampling(
            sequence=sequence, sampling_size=sampling_size, seed=self.seed, pool_size=self.pool_size,
            keep_last=self.keep_last
        )
        return pool_sampling

    def __add_categorical(self, cols, sequence):
        def row_mapper(row, categorical_col_index):
            obj = row[0]
            # num = len(row)
            # categorical = None
            if not isinstance(obj, str) and isinstance(obj, Sequence):  # 嵌套
                # categorical = [obj[_] for _ in self.categorical_col_index]
                return obj[categorical_col_index]
            else:
                # categorical = [row[_] for _ in self.categorical_col_index]
                return row[categorical_col_index]
            # return [*[row[_] for _ in range(num)], *categorical]
            # return [*[row[_] for _ in range(num)], categorical]

        max_id = max(cols)
        new_cols = [max_id + 1 + _ for _ in range(len(self.categorical_col_index))]
        # self.sequence = etl.rowmap(sequence, row_mapper, [*cols, *new_cols])
        # self.sequence = etl.addfields(sequence, [(_, partial(row_mapper, categorical_col_index=_)) for _ in new_cols])

        for i, row in enumerate(sequence):
            if i == 0:
                yield (*row, *new_cols)
            else:
                categorical = [row_mapper(row, _) for _ in self.categorical_col_index]
                yield (*row, *categorical)

    def __add_col_name(self):
        first_row, sequence = head(self.sequence, 1)
        col_num = len(first_row) - 1
        self.sequence = chain([tuple(range(col_num))], sequence)

    def single_sample(self, batch_size, seed: int = None) -> List:
        raise Exception('single_sample不存在！')

    def sampling(self) -> List:
        self.__add_col_name()
        cols, self.sequence = gen_table_meta_and_head_content(self.sequence)
        max_id = max(cols)
        self.sequence = self.__add_categorical(*gen_table_meta_and_head_content(self.sequence))
        keys = [max_id + 1 + _ for _ in range(len(self.categorical_col_index))]
        if self.presort is False:
            self.sequence = etl.sort(self.sequence, keys)
        # sampling_size = None
        # if isinstance(self.sampling_size, int):
        #     sampling_size = self.sampling_size
        # elif isinstance(self.sampling_size, list):
        #     sampling_size = cycle(self.sampling_size)
        # else:
        #     sampling_size = {k: cycle(v) for k, v in self.sampling_size.items()}
        for k, g in groupby(etl.data(self.sequence), lambda x: x[min(keys):]):
            g = [_[:min(keys)] for _ in g]
            sampling_size = None
            if isinstance(self.sampling_size, dict) and k in self.sampling_size:
                sampling_size = self.sampling_size[k]
            else:
                sampling_size = self.sampling_size
            if sampling_size is None:
                continue
            pool_sampling = self.__single_categorical_pool_sampling(g, sampling_size)
            yield k, list(pool_sampling)
