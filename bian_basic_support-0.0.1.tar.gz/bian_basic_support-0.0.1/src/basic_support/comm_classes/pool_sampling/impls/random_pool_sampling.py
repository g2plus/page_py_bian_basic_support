#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: random_pool_sampling.py
@Description: 随机水塘采样
              https://zhuanlan.zhihu.com/p/107793995
@time: 2022/5/27 17:04
"""
import random
from typing import List, Iterable

from basic_support.comm_classes.pool_sampling.abs_pool_sampling import AbsPoolSampling
from basic_support.comm_classes.pool_sampling.random_pool import RandomPool


class RandomPoolSampling(AbsPoolSampling):
    def __init__(self,
                 sequence: Iterable,
                 sampling_size: int or List[int],
                 seed: int = None,
                 pool_size: int = 100,
                 keep_last: bool = False):
        """
        随机水塘采样
        :param sequence: 采样来源序列
        :param sampling_size: 采样大小, 当输出为列表时, 每次采样的大小为该列表的轮询
        :param seed: 随机种子, 默认为None, 表示完全随机
        :param pool_size: 水塘大小，默认为10000
        :param keep_last: 是否保留最后一批, 默认不保留
        """
        super(RandomPoolSampling, self).__init__()
        self.sequence = sequence
        self.sampling_size = [sampling_size] if type(sampling_size) == int else sampling_size
        self.sampling_num = len(self.sampling_size)
        self.seed_rdn = random.Random(seed).sample
        self.pool_size = pool_size
        self.keep_last = keep_last
        self.random_pool = RandomPool(pool_size=pool_size)

    def single_sample(self, batch_size) -> List:
        values = []
        idx_lst = self.random_pool.get_in_idx()
        choice_lst = self.seed_rdn(idx_lst, batch_size)
        for choice in choice_lst:
            value = self.random_pool.pop(choice)
            values.append(value)
        return values

    def sampling(self) -> List:
        idx = 0
        for seq in self.sequence:
            self.random_pool.append(seq)
            if self.random_pool.full():
                sampling_size = self.sampling_size[idx % self.sampling_num]
                idx = idx + 1
                yield self.single_sample(batch_size=sampling_size)

        while len(self.random_pool) >= self.sampling_size[idx % self.sampling_num]:
            sampling_size = self.sampling_size[idx % self.sampling_num]
            idx = idx + 1
            yield self.single_sample(batch_size=sampling_size)

        last_len = len(self.random_pool)
        if self.keep_last and last_len:
            yield self.single_sample(batch_size=last_len)
