#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: random_pool.py
@Description: 随机池塘 支持添加元素，快速删除指定索引的数据
@time: 2022/5/30 13:29
"""

from basic_support.comm_classes.pool_sampling.ordered_set import OrderedSet


class RandomPool:
    def __init__(self, pool_size: int = 5):
        """
        随机池塘 支持添加元素，快速删除指定索引的数据
        :param pool_size: 水塘大小
        """
        self.pool_size = pool_size
        self.in_set = OrderedSet()
        self.out_set = OrderedSet(range(pool_size))
        self.dict = {idx: None for idx in range(pool_size)}

    def append(self, value):
        idx = self.out_set.pop()
        self.dict[idx] = value
        self.in_set.add(idx)

    def __getitem__(self, item):
        return self.dict[item]

    def pop(self, item: int):
        if item in self.in_set:
            self.in_set.remove(item)
            self.out_set.add(item)
            value = self.dict[item]
            self.dict[item] = None
            return value

    def __iter__(self):
        for item in self.in_set:
            yield self.dict[item]

    def get_in_idx(self):
        # return list(self.in_set)
        return list(self.in_set.map)

    def full(self):
        return len(self.in_set) == self.pool_size

    def __len__(self):
        return len(self.in_set)

    def __repr__(self):
        return str(self.dict)
