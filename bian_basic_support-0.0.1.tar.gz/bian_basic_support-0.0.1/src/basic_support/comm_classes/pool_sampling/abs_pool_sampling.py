#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_pool_sampling.py
@Description: 
@time: 2022/5/27 17:02
"""

from abc import ABCMeta, abstractmethod
from typing import List


class AbsPoolSampling(metaclass=ABCMeta):
    def __init__(self):
        pass

    def __iter__(self):
        return self.sampling()

    @abstractmethod
    def sampling(self) -> List:
        """ 采样 """
        pass
