# @Time    : 2020/8/14 15:13
# @Author  : YuQL
# @FileName: class_instance_meta.py
# @Software: PyCharm

from typing import List, Generic, TypeVar, Dict

from basic_support.comm_funcs.reflect_func import load_object

SuperClassLimit = TypeVar("SuperClassLimit", )


def _parse_val(val):
    if isinstance(val, list) or isinstance(val, dict):
        return _parse_args_vals(val)
    elif isinstance(val, ClassInstanceMeta):
        return val.build_instance()
    else:
        return val


def _parse_args_vals(args_vals: List[object] or Dict[object]) -> List[object] or Dict[object]:
    if isinstance(args_vals, list):
        return [_parse_val(val) for val in args_vals]
    elif isinstance(args_vals, dict):
        return {_parse_val(k): _parse_val(v) for k, v in args_vals.items()}
    else:
        raise Exception("args_vals只能是list或dict")


class ClassInstanceMeta(Generic[SuperClassLimit]):

    def __init__(self,
                 instance_class: type,
                 init_args_vals: List[object]
                 ):
        """
        类实例的元信息类
        :param instance_class: 对象的class
        :param init_args_vals: 对象类的构造函数参数值列表
        """
        self.class_full_name = "{}.{}".format(instance_class.__module__, instance_class.__name__)
        self.init_args_vals = init_args_vals

    def build_instance(self) -> SuperClassLimit:
        """
        构造一个对应的类对象
        :return:
        """
        class_type = load_object(self.class_full_name)
        return class_type(*_parse_args_vals(self.init_args_vals))
