#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: mail_tool.py
@Description: 邮箱工具
https://docs.python.org/zh-cn/dev/library/email.examples.html
@time: 2023/12/4 11:09
"""
from contextlib import closing
import mimetypes
import os
import smtplib
import traceback
from abc import abstractmethod
from dataclasses import dataclass, field
from email.message import EmailMessage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List

import pypinyin
from dotenv import load_dotenv

from basic_support.logger.logger_config import logger

# 加载.env文件
load_dotenv()


def init_address():
    return os.environ.get("QQ_MAIL")


def init_password():
    return os.environ.get("QQ_ACCESS_CODE")




@dataclass
class Account:
    # 发件人邮箱地址
    send_address: str = field(default_factory=init_address)

    # 发件人授权码
    password: str = field(default_factory=init_password)


@dataclass
class Message:
    # 邮件主题
    subject: str = None

    # 正文
    content: str = None

    # 收件人昵称和地址
    to_list: List[str] = field(default_factory=list)

    # 抄送人昵称和地址
    cc_list: List[str] = field(default_factory=list)

    # 附件文件或目录列表
    attach_list: List[str] = field(default_factory=list)

    def to_qq_form(self, send_address: str) -> str:
        """
        构建qq邮件的消息格式
        :param send_address:
        :return:
        """
        sender_name = os.environ.get("NICK_NAME", "大丰收")
        for to in self.to_list:
            # 定义一个复杂消息对象
            multi_msg = MIMEMultipart()
            # 发件人昵称和地址
            from email.utils import formataddr
            from email.header import Header
            multi_msg['From'] = formataddr((str(Header(sender_name, 'utf-8')), send_address))
            # 收件人昵称和地址
            multi_msg['To'] = to
            # 抄送人昵称和地址
            multi_msg['Cc'] = ';'.join(self.cc_list)
            # 邮件主题
            multi_msg['Subject'] = self.subject

            # 定义一个可以添加正文的邮件消息对象
            msg = MIMEText(self.content, 'html', 'utf-8')
            # 添加正文
            multi_msg.attach(msg)

            # 添加附件
            attach_msg = self.get_attach()
            multi_msg.attach(attach_msg)

            yield multi_msg.as_string(), to

    def read_attach(self, file_name: str, attach_msg: EmailMessage):
        """
        读取文件作为邮件的附件
        :param file_name: 文件名
        :param attach_msg: 消息对象
        :return:
        """
        ctype, encoding = mimetypes.guess_type(file_name)
        if ctype is None or encoding is not None:
            # No guess could be made, or the file is encoded (compressed), so use a generic bag-of-bits type.
            ctype = 'application/octet-stream'
        maintype, subtype = ctype.split('/', 1)

        with open(file_name, 'rb') as fp:
            attach_msg.add_attachment(fp.read(), maintype=maintype, subtype=subtype,
                                      filename=''.join(pypinyin.lazy_pinyin(file_name)))

    def get_attach(self) -> EmailMessage:
        """ 获取附件的消息对象 """
        attach_msg = EmailMessage()
        for file_or_path in self.attach_list:
            if os.path.isfile(file_or_path):
                self.read_attach(file_name=file_or_path, attach_msg=attach_msg)
            else:
                for file_name in os.listdir(file_or_path):
                    path = os.path.join(file_or_path, file_name)
                    if not os.path.isfile(path):
                        continue
                    self.read_attach(file_name=path, attach_msg=attach_msg)
        return attach_msg

    @property
    def qq_to_list(self):
        return ';'.join(self.to_list)


class AbsMailTool:
    def __init__(self, account: Account, ):
        self.account = account

    @abstractmethod
    def send(self, *args, **kwargs):
        raise Exception("未实现的方法")


class QQMailTool(AbsMailTool):
    def __init__(self, account: Account = None):
        """
        基于qq邮箱的STMP邮箱工机
        请根据报错原因查看此链接
        https://service.mail.qq.com/
        :param account:
        """
        account = account or Account()
        super().__init__(account=account)

    def send(self, message: Message) -> bool:
        """
        邮件发送
        :param message: 消息对象
        :return: 是否发送成功
        """
        try:
            # 验证邮箱配置
            if not self.account.send_address or not self.account.password:
                logger.error("邮箱配置缺失: send_address 或 password 为空")
                raise ValueError("邮箱配置缺失")
    
            # 获取邮件格式
            messages = list(message.to_qq_form(send_address=self.account.send_address))
            if not messages:
                logger.error("to_qq_form 返回空列表")
                raise ValueError("消息转换失败")
    
            # 验证 messages 格式
            for item in messages:
                if not isinstance(item, (tuple, list)) or len(item) != 2:
                    logger.error(f"to_qq_form 返回格式错误: {item}")
                    raise ValueError(f"无效的 to_qq_form 输出: {item}")
                msg, to = item
                if not isinstance(to, (str, list)) or (isinstance(to, list) and not all(isinstance(addr, str) for addr in to)):
                    logger.error(f"无效的收件人地址: {to}")
                    raise ValueError(f"收件人地址格式错误: {to}")
                if not isinstance(msg, str):
                    logger.error(f"无效的邮件内容: {msg}")
                    raise ValueError(f"邮件内容格式错误: {msg}")
    
            with closing(smtplib.SMTP_SSL('smtp.qq.com', 465)) as server:
                server.login(self.account.send_address, self.account.password)
                for msg, to in messages:
                    logger.debug(f"发送邮件: from={self.account.send_address}, to={to}")
                    try:
                        server.sendmail(from_addr=self.account.send_address, to_addrs=to, msg=msg)
                        import time
                        time.sleep(6)
                        logger.info(f"邮件发送成功, 发送对象为: {to}")
                    except smtplib.SMTPSenderRefused as e:
                        if b'250 OK' in e.args[1]:
                            logger.warning(f"邮件发送可能成功，但收到异常响应: {e}")
                            continue  # 假设邮件发送成功，继续处理下一个收件人
                        else:
                            logger.error(f"邮件发送失败: {e}")
                            raise
            return True
        except Exception as e:
            logger.exception(f"邮件发送异常: {e}")
            return False
