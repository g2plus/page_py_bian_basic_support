#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: pdf_tool.py
@Description: pdf相关的
@time: 2024/9/14 8:45
"""


class PdfTool:
    def __init__(self):
        import os
        import os
        import shutil
        import tempfile

        from PIL import Image, ImageDraw
        from PyPDF2 import PdfReader
        from pdf2image import convert_from_path, convert_from_bytes
        from pypdf import PdfReader, PdfWriter
        from tqdm import tqdm
