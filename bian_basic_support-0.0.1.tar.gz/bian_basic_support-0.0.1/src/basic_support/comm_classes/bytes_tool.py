#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: bytes_tool.py
@Description: 
@time: 2024/9/14 9:43
"""
import io


class BytesTool:
    @staticmethod
    def write_bytes_to_file(byte_data: bytes, file_name: str):
        # 将字节数据转换为 BytesIO 流
        byte_stream = io.BytesIO(byte_data)

        # 保存到文件，逐块写入
        with open(file_name, 'wb') as file:
            while True:
                chunk = byte_stream.read(1024)  # 每次读取 1024 字节
                if not chunk:
                    break
                file.write(chunk)

        # 关闭流
        byte_stream.close()
