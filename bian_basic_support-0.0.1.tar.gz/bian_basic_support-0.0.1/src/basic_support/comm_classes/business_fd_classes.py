#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: business_fd_classes.py
@Description: 用于存放业务使用的工具类
@time: 2023/9/21 9:02
"""
from abc import abstractmethod
from typing import List

import requests

from basic_support.comm_funcs.comm_utils import uniform_n_split_lst


class AbsCalEmbedding:
    def __init__(self, batch_size: int = 1024):
        self.batch_size = batch_size

    @abstractmethod
    def _cal_embedding(self, content: List[str]) -> List[List[float]]:
        """ 单个batch调用模型 """
        pass

    def embedding(self, contents: List[str]) -> List[List[float]]:
        """
        编码
        :param contents: 文本列表
        :return: 编码结果列表
        """
        res = []
        for content in uniform_n_split_lst(contents, batch_size=self.batch_size):
            res.extend(self._cal_embedding(content=content))
        return res


class RemoteEmbedding(AbsCalEmbedding):
    def __init__(self, model_url: str, batch_size: int = 1024):
        """
        远程模型服务调用
        :param model_url: 模型服务url
        :param batch_size: 批量大小
        """
        super(RemoteEmbedding, self).__init__(batch_size=batch_size)
        self.model_url = model_url

    def _cal_embedding(self, content: List[str]) -> List[List[float]]:
        x = requests.post(self.model_url, json=content)
        if x.status_code == 200:
            return x.json()['response']
        else:
            raise Exception("访问异常")


class LocalEmbedding(AbsCalEmbedding):
    def __init__(self, model_name: str, device: int = 0, batch_size: int = 1024):
        """
        本地模型服务调用
        :param model_name: 模型名字
        :param batch_size: 批量大小
        """
        super(LocalEmbedding, self).__init__(batch_size=batch_size)
        from transformers import BertTokenizer
        from transformers import BertModel
        import torch
        self.model_name = model_name
        self.tokenizer = BertTokenizer.from_pretrained(model_name)
        self.model = BertModel.from_pretrained(model_name)
        self.device = torch.device(f"cuda:{device}" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)

    def _cal_embedding(self, content: List[str]) -> List[List[float]]:
        import torch
        texts_pt = self.tokenizer(content, return_tensors="pt", padding=True, truncation=True)
        texts_pt.data = {k: v.to(self.device) for k, v in texts_pt.data.items()}
        # 获取模型的输出，即句子的隐藏状态
        with torch.no_grad():
            texts_output = self.model(**texts_pt)
        # 清除 GPU 显存
        torch.cuda.empty_cache()

        # 获取句子向量，使用 [CLS] 标记对应的隐藏状态作为句子向量
        texts_sentence_vector = texts_output.last_hidden_state[:, 0, :]
        return texts_sentence_vector.cpu().numpy().tolist()
