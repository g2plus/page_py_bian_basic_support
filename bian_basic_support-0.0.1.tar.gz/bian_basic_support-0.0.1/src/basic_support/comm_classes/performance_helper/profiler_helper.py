#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: profiler_helper.py
@Description: 时间性能监控类，主要监控执行状态、频率和时长
              pyinstrument 是一个非常强大的 Python 性能分析工具。它支持 Python 3.7+，能够分析异步代码，而且只需一条命令就能显示具体代码的耗时。用起来也很简单，非常适合我们这些时间宝贵的程序员。
              pip install pyinstrument
@time: 2021/7/17 15:51
"""
import os
from cProfile import Profile
from functools import wraps
from pstats import Stats

from basic_support.comm_funcs.comm_utils import gen_uuid32, script_run_helper


class ProfilerHelper:
    @staticmethod
    def profiler_wrap(sort_by: str = 'cumulative', print_stats: bool = True, print_callers: bool = True,
                      use_snakeviz: bool = False):
        """
        行状态、频率和时长装饰器
        :param sort_by: 排序规则
                        可选参数：
                              准则                       含义                       升序/降序排列
                              calls                    调用次数                        降序
                              cumulative               累计时间                        降序
                              cumtime                  累计时间                        降序
                              file                     文件                           升序
                              filename                 文件名                          升序
                              module                   模块名                          升序
                              ncalls                   调用总次数                       降序
                              pcalls                   原始调用书                       降序
                              line                     行号                            升序
                              name                     函数名                          升序
                              nfl                      函数名/文件名/行号组合             降序
                              stdname                  标准名称                         升序
                              time                     函数内部运行时间                   降序
                              tottime                  函数内部运行总时间                 降序
        :param print_stats: Create a Stats object based on the current profile and print the results to stdout.
        :param print_callers: 打印受测函数和调用函数的关系
        :param use_snakeviz: 是否使用snakeviz可视化结果
        :return:
        """

        def wrapper(func):
            @wraps(func)
            def inner_func(*args, **kwargs):
                profiler = Profile()
                res = profiler.runcall(func, *args, **kwargs)
                stats = Stats(profiler)
                # strip_dirs()：删除报告中所有函数文件名的路径信息，这个方法改变stats实例内部的顺序，任何运行该方法的实例都将随机排列项目的顺序。
                # 如果两个项目是相同的，那么这两个项目就可以合并。
                stats.strip_dirs()
                # sort_stats(*keys)：通过一系列条件依次对所有项目进行排序，从而调整stats对象
                stats.sort_stats(sort_by)
                if print_stats:
                    stats.print_stats()
                if print_callers:
                    stats.print_callers()
                if use_snakeviz:
                    path_snakeviz = os.path.join(os.getcwd(), f'func_{func.__name__}_{gen_uuid32()}.prof')
                    print(f"性能监控文件保存至: {path_snakeviz}")
                    stats.dump_stats(filename=path_snakeviz)
                    try:
                        import snakeviz
                    except:
                        cmd = 'pip install snakeviz'
                        print("snakeviz库不存在，执行在线安装")
                        script_run_helper(command_lst=[cmd])
                        print("snakeviz库执行在线安装完成")

                    cmd = f"snakeviz {path_snakeviz}"
                    script_run_helper(command_lst=[cmd])
                return res

            return inner_func

        return wrapper


@ProfilerHelper.profiler_wrap()
def fn(h, a=5, b=8):
    import re
    print(h, a, b)
    return re.compile("aaa|bbb")


if __name__ == '__main__':
    print(fn(464646, 8, b=8))
