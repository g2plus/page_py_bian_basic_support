#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: tracemalloc_helper.py
@Description: 内存监控类
@time: 2021/7/17 15:53
"""
import tracemalloc

from functools import wraps


class TracemallocHelper:
    @staticmethod
    def tracemalloc_wrap(key_type: str = 'lineno', monitor_type: str = 'statistics', top_k: int = 10,
                         filter_self: bool = True):
        """
        内存监控装饰器
        :param key_type: 比较的字段，'traceback', 'filename', 'lineno'
        :param monitor_type: 监控类型，'statistics', 'change'
        :param top_k: 关注top_k的内存占用,默认关注前10个
        :param filter_self: 是否过滤掉监控程序本身的消耗
        :return:
        """

        def wrapper(func):
            @wraps(func)
            def inner_func(*args, **kwargs):
                tracemalloc.start()
                # ... start your application ...
                res = func(*args, **kwargs)
                snapshot1 = tracemalloc.take_snapshot()
                # ... call the function leaking memory ...
                snapshot2 = tracemalloc.take_snapshot()

                if monitor_type == 'change':
                    top_stats = snapshot2.compare_to(snapshot1, key_type)
                elif monitor_type == 'statistics':
                    top_stats = snapshot2.statistics(key_type)
                else:
                    top_stats = snapshot2.statistics(key_type)
                print(f"[ Top {top_k} differences ]")
                for idx, stat in enumerate(top_stats[:top_k]):
                    if filter_self and 'tracemalloc.py' in str(stat):
                        continue
                    print('%03d' % idx, stat)
                return res

            return inner_func

        return wrapper


@TracemallocHelper.tracemalloc_wrap()
def fn(h, a=5, b=8):
    print(h, a, b)

    d = [dict(zip('xy', (5, 6))) for i in range(100000)]
    t = [tuple(zip('xy', (5, 6))) for i in range(100000)]
    return d, t


if __name__ == '__main__':
    fn(68, 7, b=78)
