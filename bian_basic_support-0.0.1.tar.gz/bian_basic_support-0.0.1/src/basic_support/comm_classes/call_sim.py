#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: call_sim.py
@Description: 
@time: 2024/1/17 14:05
"""
import Levenshtein
import numpy as np

from scipy import stats
from abc import abstractmethod


class AbsCallSim:

    def __init__(self):
        pass

    @abstractmethod
    def call_similarity(self, vector_a: np.array, vector_b: np.array) -> float:
        raise Exception("未实现的方法")


class CosSimilarity(AbsCallSim):
    def __init__(self):
        """ 计算向量的cos相似度 """
        super(CosSimilarity, self).__init__()

    def call_similarity(self, vector_a: np.array, vector_b: np.array) -> float:
        dot_product = np.dot(vector_a, vector_b)  # 点积
        norms = np.linalg.norm(vector_a) * np.linalg.norm(vector_b)  # 模长
        sim = dot_product / norms if norms != 0 else 0
        return sim


class PearsonrSimilarity(AbsCallSim):
    def __init__(self):
        """ 计算向量的皮尔森相似度 """
        super(PearsonrSimilarity, self).__init__()

    def call_similarity(self, vector_a: np.array, vector_b: np.array) -> float:
        sim = stats.pearsonr(vector_a, vector_b)
        return sim.statistic


class EuclideanSimilarity(AbsCallSim):
    def __init__(self):
        """ 计算向量的欧式相似度 """
        super(EuclideanSimilarity, self).__init__()

    def call_similarity(self, text_a: np.array, text_b: np.array) -> float:
        # 计算Levenshtein距离
        lev_distance = Levenshtein.distance(text_a, text_b)

        # 获取两个字符串中较长者的长度
        max_length = max(len(text_a), len(text_b))

        # 计算归一化相似度
        normalized_similarity = 1 - lev_distance / max_length
        return normalized_similarity
