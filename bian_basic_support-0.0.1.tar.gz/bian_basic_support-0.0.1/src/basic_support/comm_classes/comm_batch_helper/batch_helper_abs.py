#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: batch_helper_abs.py
@Description: 简化batch输出使用过程
@time: 2020/7/18 22:43
"""
from abc import ABC, ABCMeta, abstractmethod
from types import MethodType
from typing import Callable


class AbsBatchHelper(ABC, metaclass=ABCMeta):
    """
    样本处理并输出
    使用步骤：
    方式一：
        1. 添加样本append_sample(满批次会输出)
        2. 程序结束时 执行flush(),将剩余样本处理完毕
    方式二(建议)：
        with BatchHelper(...) as batch_helper:
            batch_helper.append_sample(...)
    """

    def __init__(self, batch_size=5000, deal_sample: Callable = None):
        """
        @param batch_size: 输出批次大小
        @param deal_sample: 样本处理函数, 需要的参数在append_sample时传入
        """
        if deal_sample is not None:
            # 外部定义的函数需要在这里转为对象的方法
            self.deal_sample = MethodType(deal_sample, self)
        else:
            self.deal_sample = lambda sample, *args, **kwargs: sample
        self.sample_lst = []
        self.batch_size = batch_size

    def append_sample(self, sample, *args, **kwargs):
        """
        添加单条样本
        @param sample: 样本
        @param args: self.deal_sample参数
        @param kwargs: self.deal_sample关键字参数
        """
        self.sample_lst.append(self.deal_sample(sample, *args, **kwargs))
        if len(self.sample_lst) >= self.batch_size:
            self.flush()

    @abstractmethod
    def write_fn(self, *args, **kwargs):
        """
        具体输出实现
        @param args: 参数
        @param kwargs: 关键字参数
        """
        pass

    def flush(self):
        """ 将列表里的数据清空输出 """
        if len(self.sample_lst) >= 1:
            self.write_fn()
            self.sample_lst = []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.flush()


if __name__ == '__main__':
    # 基本使用演示
    class SampleText(AbsBatchHelper):
        def __init__(self, fg, batch_size=2, deal_sample=None):
            super(SampleText, self).__init__(batch_size, deal_sample)
            self.fg = fg

        def write_fn(self):
            print(self.sample_lst)


    with SampleText(None, batch_size=2) as helper:
        [helper.append_sample(str(i)) for i in range(9)]
