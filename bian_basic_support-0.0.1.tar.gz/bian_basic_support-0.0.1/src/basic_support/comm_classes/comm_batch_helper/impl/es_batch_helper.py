#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: es_batch_helper.py
@Description: es输出助手
@time: 2022/6/15 17:17
"""

from typing import Callable

from basic_support.comm_classes.comm_batch_helper.batch_helper_abs import AbsBatchHelper
from basic_support.data_access.dao.impl.es_dao import EsDao


class EsBatchHelper(AbsBatchHelper):
    def __init__(self, dao: EsDao, index_name: str, batch_size=500, deal_sample: Callable = None):
        """
        :param dao: dao对象
        :param index_name: 索引名
        :param batch_size: 写入批次大小
        :param deal_sample: 样本处理函数
        """
        super(EsBatchHelper, self).__init__(batch_size, deal_sample)
        self.dao = dao
        self.index_name = index_name

    def write_fn(self):
        """ 并行化写入 """
        self.dao.parallel_write(self.index_name, list(self.sample_lst), chunk_size=self.batch_size)
