#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: parquet_batch_helper.py
@Description: parquet数据批量写入工具
@time: 2024/12/18 13:47
"""
from typing import Callable

from tqdm import tqdm

from basic_support.comm_classes.comm_batch_helper.batch_helper_abs import AbsBatchHelper
from basic_support.comm_classes.parquet_tool import ParquetTool
from basic_support.comm_funcs.comm_utils import iter_slice_tool


class ParquetBatchHelper(AbsBatchHelper):
    def __init__(self, output_base_path: str, max_file_size: int = 100 * 10000, batch_size: int = 5000,
                 is_clean: bool = True, deal_sample: Callable = None):
        """
        @param output_base_path: 文件名
        @param batch_size: 批量输出大小
        @param deal_sample: 样本处理函数
        """
        super(ParquetBatchHelper, self).__init__(batch_size, deal_sample)
        self.parquet_util = ParquetTool(base_path=output_base_path, max_file_size=max_file_size, is_clean=is_clean)

    def write_fn(self):
        for k, samples in iter_slice_tool(self.sample_lst, self.batch_size):
            self.parquet_util.write_batch(list(samples))

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.flush()
            self.parquet_util.finalize()
        except Exception as e:
            pass


def run():
    output_base_path = "noup_test_datas"
    with ParquetBatchHelper(output_base_path=output_base_path, batch_size=1000) as parquet_helper:
        for i in range(13126):
            parquet_helper.append_sample({'sample': i})

    parquet_util = ParquetTool(output_base_path)  # 设置每个文件最大1MB
    # 逐批读取并打印数据
    # datas = []
    for data_batch in tqdm(parquet_util.read_parquet_iter(batch_size=5000), f"数据遍历中"):
        print(len(data_batch))


if __name__ == '__main__':
    run()
