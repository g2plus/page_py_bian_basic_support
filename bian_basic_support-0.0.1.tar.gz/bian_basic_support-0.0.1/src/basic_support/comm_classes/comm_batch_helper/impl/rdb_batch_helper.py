#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: rdb_batch_helper.py
@Description: 关系库输出助手
@time: 2022/6/15 17:18
"""
from concurrent import futures
from typing import Callable

from basic_support.comm_classes.comm_batch_helper.batch_helper_abs import AbsBatchHelper
from basic_support.comm_funcs.comm_utils import iter_uniform_tool
from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao


class RdbBatchHelper(AbsBatchHelper):
    def __init__(self, dao: AbstractRdbDao, insert_sql: str, batch_size: int = 5000,
                 threading_num: int or None = None, deal_sample: Callable = None):
        """
        :param dao: dao对象
        :param insert_sql: 插入语句
        :param batch_size: 批次写入大小
        :param threading_num: 线程数，取值为None或整数，当取None时，不启动多线程写入方式，默认不启动
        :param deal_sample: 样本处理函数
        """
        super(RdbBatchHelper, self).__init__(batch_size, deal_sample)
        self.dao = dao
        self.insert_sql = insert_sql
        self.threading_num = threading_num
        self.executor = futures.ThreadPoolExecutor(max_workers=self.threading_num) if self.threading_num else None

    def write_fn(self):
        if self.executor:
            tasks = []
            for data in iter_uniform_tool(self.sample_lst, n=self.threading_num):
                task = self.executor.submit(self.dao.insert_batch_row, sql=self.insert_sql, values=data)
                tasks.append(task)
            [future.result() for future in futures.as_completed(tasks)]
        else:
            self.dao.insert_batch_row(self.insert_sql, self.sample_lst)
            # for k, samples in iter_slice_tool(self.sample_lst, 1000):
            #     self.dao.insert_batch_row(self.insert_sql, list(samples))
