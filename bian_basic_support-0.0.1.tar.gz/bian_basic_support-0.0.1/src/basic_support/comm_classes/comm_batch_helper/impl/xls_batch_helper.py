#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: xls_batch_helper.py
@Description: xls输出助手
@time: 2022/6/15 17:19
"""

import os
from collections import defaultdict
from typing import Callable

import pandas as pd

from basic_support.comm_classes.comm_batch_helper.batch_helper_abs import AbsBatchHelper


class XlsBatchHelper(AbsBatchHelper):
    def __init__(self, file_name: str = 'default.xls',
                 head: bool = False, index: bool = False, engine=None,
                 encoding='utf-8', batch_size: int = 2000, deal_sample: Callable = None):
        """
        xls批量输出助手
        :param file_name: 输出文件名
        :param engine: 用于编写的引擎。如果为None，则默认为io.excel.<extension>.writer
        :param head: 是否带有头部
        :param index: 是否需要索引
        :param encoding: 编码方式，默认utf-8编码
        :param batch_size: 批次写入大小
        :param deal_sample: 样本处理函数，默认None，即不对样本做任何处理
        """
        super(XlsBatchHelper, self).__init__(batch_size, deal_sample)
        if os.path.exists(file_name):
            os.remove(file_name)
        try:
            self.xls_writer = pd.ExcelWriter(file_name, mode='w', encoding=encoding, engine=engine)
        except:
            self.xls_writer = pd.ExcelWriter(file_name, mode='w', engine=engine)
        self.head = head
        self.index = index
        self.idx_member = defaultdict(int)
        self.sheet_df_dic = {}

    def append_sample(self, sample, sheet_name=None, *args, **kwargs):
        """
        添加样本
        :param sample: 样本
        :param sheet_name: 目标sheet
        :param args:
        :param kwargs:
        """
        df_data = sample
        sheet_name = sheet_name if sheet_name else 'sheet1'
        sheet_is_none = sheet_name in self.sheet_df_dic and self.sheet_df_dic[sheet_name] is None
        if sheet_name not in self.sheet_df_dic or sheet_is_none:
            self.sheet_df_dic[sheet_name] = df_data
        else:
            self.sheet_df_dic[sheet_name] = self.sheet_df_dic[sheet_name].append(df_data, ignore_index=not self.index)
        if len(self.sample_lst) >= self.batch_size:
            self.write_fn(sheet_name)
            self.sheet_df_dic[sheet_name] = None

    def write_fn(self, sheet_name):
        """
        @param sheet_name: sheet名
        """
        if self.idx_member[sheet_name] == 0:
            self.sheet_df_dic[sheet_name].to_excel(excel_writer=self.xls_writer,
                                                   sheet_name=sheet_name,
                                                   startrow=self.idx_member[sheet_name],
                                                   index=self.index)
            self.idx_member[sheet_name] = self.idx_member[sheet_name] + len(self.sheet_df_dic[sheet_name]) + 1
        else:
            self.sheet_df_dic[sheet_name].to_excel(excel_writer=self.xls_writer,
                                                   sheet_name=sheet_name,
                                                   startrow=self.idx_member[sheet_name],
                                                   index=self.index, header=self.head)
            self.idx_member[sheet_name] = self.idx_member[sheet_name] + len(self.sheet_df_dic[sheet_name])
        self.sheet_df_dic[sheet_name] = None

    def flush(self):
        """
        将剩余数据写入到文件
        """
        for sheet_name, df in self.sheet_df_dic.items():
            if df is not None and len(df) >= 1:
                self.write_fn(sheet_name)
        self.xls_writer.save()
