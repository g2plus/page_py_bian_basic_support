#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: text_batch_helper.py
@Description: 文件输出助手
@time: 2020/7/31 9:19
"""
from typing import Callable

from basic_support.comm_classes.comm_batch_helper.batch_helper_abs import AbsBatchHelper
from basic_support.comm_funcs.comm_utils import iter_slice_tool


class TextBatchHelper(AbsBatchHelper):
    def __init__(self, file_name, batch_size: int = 5000, deal_sample: Callable = None):
        """
        @param file_name: 文件名
        @param batch_size: 批量输出大小
        @param deal_sample: 样本处理函数
        """
        super(TextBatchHelper, self).__init__(batch_size, deal_sample)
        self.file = open(file_name, 'w', encoding='utf-8')

    def write_fn(self):
        for k, samples in iter_slice_tool(self.sample_lst, self.batch_size):
            self.file.writelines(list(samples))

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.flush()
        self.file.flush()
        try:
            self.file.close()
        except Exception as e:
            pass

