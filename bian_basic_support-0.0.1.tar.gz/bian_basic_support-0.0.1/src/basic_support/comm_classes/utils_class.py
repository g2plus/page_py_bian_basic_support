#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: utils_class.py
@Description: 存放一些工具类
@time: 2020/6/5 11:07
"""
import asyncio
import json
import threading
import time
from typing import Callable


class Stack:
    """模拟栈"""

    def __init__(self):
        self.items = []

    def empty(self):
        return len(self.items) == 0

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def peek(self):
        if not self.empty():
            return self.items[len(self.items) - 1]

    def size(self):
        return len(self.items)

    def get_all(self):
        return [item for item in self.items]


class Queue:
    """
    模拟队列，增加附加供能
    """

    def __init__(self):
        self.items = []

    def empty(self):
        return len(self.items) == 0

    def push(self, item):
        self.items.append(item)

    def pop(self):
        value = self.items[0] if not self.empty() else None
        self.items = self.items[1:]
        return value

    def peek(self):
        return self.items[0] if not self.empty() else None

    def get_all(self):
        return [item for item in self.items]


class ThreadingTee:
    def __init__(self, tee_obj, lock):
        self.tee_obj = tee_obj
        self.lock = lock

    def __iter__(self):
        return self

    def __next__(self):
        with self.lock:
            return next(self.tee_obj)

    def __copy__(self):
        return ThreadingTee(self.tee_obj.__copy__(), self.lock)


class Timer:
    """
    计时器类：perf_counter()会包含sleep()休眠时间，适用测量短持续时间，钟表时间，并包含了所有休眠时间
            process_time()不包括sleep()休眠时间期间经过的时间，计算该进程所花费的 CPU 时间
    """

    def __init__(self,
                 time_func=None,
                 only_cpu=False):
        """
        func: 计时函数
        only_cpu：是否只计算 计算该进程所花费的 CPU 时间
        """
        self.__elapsed = 0.0
        if time_func is None and not only_cpu:
            self.__func = time.perf_counter
        elif time_func is None and only_cpu:
            self.__func = time.process_time
        else:
            self.__func = time_func
        self.__start = None

    def start(self):
        """
        计时开始
        """
        if self.__start is not None:
            raise RuntimeError('Already started')
        self.__start = self.__func()

    def stop(self):
        """
        计时结束
        """
        if self.__start is None:
            raise RuntimeError('Not started')
        end = self.__func()
        self.__elapsed = end - self.__start
        self.__start = None

    def call_cumulative_with_seconds(self, precision=4):
        """ 获取累计时间 """
        if self.__start is None:
            raise RuntimeError('Not started')
        end = self.__func()
        self.__elapsed = end - self.__start
        return round(self.__elapsed, precision)

    def reset(self):
        """
        计时结果清零
        """
        self.__elapsed = 0.0

    def reset_and_restart(self):
        """
        计时结果清零 并且 重新计时
        """
        self.reset()
        self.stop()
        self.start()

    @property
    def running(self):
        """
        查看是否正在计时
        """
        return self.__start is not None

    def call_time_with_seconds(self, precision=4):
        """
        以秒为单位 查看运行时间
        """
        return round(self.__elapsed, precision)

    def call_time_with_minutes(self, precision=4):
        """
        以分钟为单位 查看运行时间
        """
        return round(self.__elapsed / 60.0, precision)

    def call_time_with_hours(self, precision=4):
        """
        以小时为单位 查看运行时间
        """
        return round(self.__elapsed / 3600.0, precision)

    def __enter__(self):
        """
        with 模块计时开始
        """
        self.start()
        return self

    def __exit__(self, *args):
        """
        with 模块计时结束
        """
        self.stop()


class IterMeanAndVariance:
    """ 迭代计算均值和方差 """

    def __init__(self):
        self.count = 0
        self.mean = 0
        self.m2 = 0

    def add(self, curr_value):
        self.count = self.count + 1
        delta = curr_value - self.mean
        self.mean = self.mean + delta / self.count
        delta2 = curr_value - self.mean
        self.m2 = self.m2 + delta * delta2

    @property
    def mean_and_m2(self):
        """
        :return: 均值和方差
        """
        return self.mean, self.m2 / self.count


def count_down(n):
    while n >= 0:
        n = n - 1


class UniversalCache:
    def __init__(
            self,
            fetch_func: Callable,
            ttl: int = 60,
            redis_host: str = "localhost",
            redis_port: int = 6379,
            redis_db: int = 0,
            redis_key: str = "universal_cache"
    ):
        """
        fetch_func: 同步或异步函数，返回 dict
        ttl: 缓存有效期（秒）
        Redis: 多进程共享
        """
        import redis
        self.fetch_func = fetch_func
        self.ttl = ttl
        self.redis_key = redis_key
        self._sync_lock = threading.Lock()
        self._async_lock = asyncio.Lock()
        self.redis_client = redis.Redis(host=redis_host, port=redis_port, db=redis_db)

    # -------------------- 同步接口 --------------------
    def get(self) -> dict:
        """同步获取缓存"""
        with self._sync_lock:
            cached = self.redis_client.get(self.redis_key)
            if cached:
                return json.loads(cached)
            # 缓存不存在或过期，刷新
            data = self.fetch_func()
            self.redis_client.set(self.redis_key, json.dumps(data), ex=self.ttl)
            return data

    # -------------------- 异步接口 --------------------
    async def aget(self) -> dict:
        """异步获取缓存"""
        async with self._async_lock:
            cached = self.redis_client.get(self.redis_key)
            if cached:
                return json.loads(cached)
            # 异步判断 fetch_func 是否可 await
            if asyncio.iscoroutinefunction(self.fetch_func):
                data = await self.fetch_func()
            else:
                # 同步函数在 async 中调用
                loop = asyncio.get_running_loop()
                data = await loop.run_in_executor(None, self.fetch_func)
            self.redis_client.set(self.redis_key, json.dumps(data), ex=self.ttl)
            return data


if __name__ == '__main__':
    def fetch_user_key():
        print("Fetching user/key...")
        return {"username": "alice", "key": "abcd1234"}


    cache = UniversalCache(fetch_user_key, ttl=30)


    async def async_fetch_user_key():
        await asyncio.sleep(0.5)
        return {"username": "alice", "key": "abcd1234"}


    async_cache = UniversalCache(async_fetch_user_key, ttl=30)

    timer = Timer()

    timer.start()
    time.sleep(1)
    timer.stop()
    print(f"耗时: {timer.call_time_with_seconds()}")
    timer.start()
    time.sleep(2)
    timer.stop()
    print(f"耗时: {timer.call_time_with_seconds()}")

    # 累计时间
    timer.start()
    while timer.call_cumulative_with_seconds() <= 3:
        print(timer.call_cumulative_with_seconds())
        time.sleep(0.2)

    # with timer:
    #     count_down(10000000)
    # print(timer.call_time_with_seconds(5))
    # timer.reset()
    # with timer:
    #     count_down(10000000)
    # print(timer.call_time_with_seconds(5))
    # timer.reset()
    # with timer:
    #     count_down(10000000)
    # print(timer.call_time_with_seconds(5))
