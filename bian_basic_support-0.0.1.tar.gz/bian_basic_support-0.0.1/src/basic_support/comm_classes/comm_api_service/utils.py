#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: utils.py
@Description: 
@time: 2024/7/31 8:43
"""
import asyncio
from functools import partial, wraps

from basic_support.comm_classes.comm_api_service.config import ServiceConfig
from basic_support.comm_classes.comm_api_service.impls.fast_api_service import FastApiService


class SetupRoute:

    @staticmethod
    def post(path: str):
        def decorator(func):
            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                result = await func(*args, **kwargs)
                return result

            # 判断函数是否为异步函数
            wrapper = async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

            def register_route(instance: FastApiService, cfg: ServiceConfig):
                instance.app.post(f"{cfg.url_prefix}{path}")(partial(wrapper, instance))

            wrapper.register_route = register_route
            return wrapper

        return decorator

    @staticmethod
    def put(path: str):
        def decorator(func):
            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                result = await func(*args, **kwargs)
                return result

            # 判断函数是否为异步函数
            wrapper = async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

            def register_route(instance: FastApiService, cfg: ServiceConfig):
                instance.app.put(f"{cfg.url_prefix}{path}")(partial(wrapper, instance))

            wrapper.register_route = register_route
            return wrapper

        return decorator

    @staticmethod
    def get(path: str):
        def decorator(func):
            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                result = await func(*args, **kwargs)
                return result

            # 判断函数是否为异步函数
            wrapper = async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

            def register_route(instance: FastApiService, cfg: ServiceConfig):
                instance.app.get(f"{cfg.url_prefix}{path}")(partial(wrapper, instance))

            wrapper.register_route = register_route
            return wrapper

        return decorator
