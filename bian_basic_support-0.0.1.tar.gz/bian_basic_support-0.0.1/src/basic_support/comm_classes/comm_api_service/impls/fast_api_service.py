#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: fast_api_service.py
@Description: 基于fastapi的服务基类
@time: 2024/7/31 8:42
"""
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from basic_support.comm_classes.comm_api_service.abs_service import AbsService
from basic_support.comm_classes.comm_api_service.config import ServiceConfig


class FastApiService(AbsService):
    def __init__(self, cfg: ServiceConfig):
        super().__init__(cfg=cfg)
        self.app = FastAPI()
        self.app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"],
                                allow_headers=["*"])
        self._setup_routes()

    def _setup_routes(self):
        """
        在这边注册接口服务
        如：self.app.post("/create_chat_completion")(self.create_chat_completion)
        """
        for attr_name in dir(self):
            attr = getattr(self, attr_name)
            if callable(attr) and hasattr(attr, 'register_route'):
                attr.register_route(self, self.cfg)

    def _run_server(self, *args, **kwargs):
        uvicorn.run(self.app, host="0.0.0.0", port=self.cfg.port)
