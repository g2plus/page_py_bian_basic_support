#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_service.py
@Description: 通用服务抽象类
@time: 2024/7/31 8:40
"""
from abc import abstractmethod

from basic_support.comm_classes.comm_api_service.config import ServiceConfig


class AbsService:
    def __init__(self, cfg: ServiceConfig):
        self.cfg = cfg

    @abstractmethod
    def _run_server(self, *args, **kwargs):
        pass

    def run(self):
        self._run_server()
