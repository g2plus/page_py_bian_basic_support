#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: config.py
@Description: 
@time: 2024/7/31 8:41
"""
import time
from dataclasses import dataclass, field
from typing import Literal, Optional, Dict, List

from pydantic import BaseModel
from pydantic import BaseModel, Field


@dataclass
class ServiceConfig:
    port: int = field(default=6006, metadata={'help': "服务端口"})
    url_prefix: str = field(default='', metadata={'help': "服务url地址前缀, 格式为/xx/xx"})
