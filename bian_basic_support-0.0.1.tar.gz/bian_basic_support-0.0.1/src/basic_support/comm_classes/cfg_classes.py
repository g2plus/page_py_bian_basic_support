#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: cfg_classes.py
@Description: 基于的通用配置类
@time: 2024/1/25 15:00
"""

from dataclasses import dataclass, field
from typing import List
from enum import Enum

from basic_support.comm_funcs.time_utils import DateTimeGen

from basic_support.comm_funcs.comm_utils import gen_uuid32


class ConcurrentType(Enum):
    """
    并发类型枚举类
    """
    process = 'process'
    thread = 'thread'

    @staticmethod
    def get_all_values():
        return [member.value for name, member in ConcurrentType.__members__.items()]


@dataclass
class BaseMailConfig:
    """
    基础邮箱相关配置
    """
    # 结果发送到邮箱
    mail_to: List[str] = field(default_factory=lambda: ['1832044043@qq.com'], metadata={"help": "结果发送到的邮箱列表"})


@dataclass
class BaseDbOutputConfig:
    """
    基础关系库输出配置
    """
    # 输出表名
    output_table: str = field(metadata={"help": f"输出表名"})

    # 是否清空表
    is_truncate: bool = field(default=False, metadata={"help": f"输出前是否清表"})

    # 是否输出到关系库
    is_write_to_db: bool = field(default=True, metadata={"help": '是否输出到关系库'})


@dataclass
class BaseConcurrentConfig:
    """
    基础并发配置
    """
    # 并发类型
    concurrent_type: str = field(default='thread',
                                 metadata={"help": f"并发的类型, 目前支持: {ConcurrentType.get_all_values()}"})

    # 并发数量
    concurrent_num: int = field(default=4, metadata={"help": f"并发的数量"})


@dataclass
class BaseFileConfig:
    file: str = field(default=None, metadata={"help": "文件路径"})

    def __post_init__(self):
        assert self.file, '配置文件不能为空'


@dataclass
class BaseDbInfos:
    """
    基础关系库属性配置类
    """
    id: str = field(default_factory=gen_uuid32, metadata={"help": "记录id"})
    version: int = field(default=None, metadata={"help": "版本号"})
    desc_info: str = field(default=None, metadata={"help": "记录描述"})
    insert_time: str = field(default_factory=DateTimeGen.get_now, metadata={"help": "入库时间"})
