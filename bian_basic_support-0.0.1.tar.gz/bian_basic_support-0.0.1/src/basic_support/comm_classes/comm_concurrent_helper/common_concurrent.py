#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: common_concurrent.py
@Description: 
@time: 2023/10/1 22:04
"""
from concurrent import futures
from multiprocessing import cpu_count
from typing import Iterable, Callable, Any

from basic_support.comm_classes.comm_concurrent_helper.concurrent_type_enum import ConCurrentTypeEnum
from basic_support.logger.logger_config import logger


class CommonConcurrent:
    def __init__(self, timeout: int = 1e6, num_of_processor: int = None,
                 concurrent_type: ConCurrentTypeEnum = ConCurrentTypeEnum.THREAD):
        # 任务超时
        self.timeout = timeout
        # 并发数量
        self.num_of_processor = num_of_processor or cpu_count()
        # 并发类型(多线程或多进程)
        self.concurrent_type = concurrent_type
        # 执行器池子
        self.executor_pool = futures.ProcessPoolExecutor if self.concurrent_type == ConCurrentTypeEnum.PROCESS else futures.ThreadPoolExecutor

        self.before_func = self.def_before_func
        self.handle_func = self.def_handle_func
        self.after_func = self.def_after_func

    def def_before_func(self, data: Any, *args, **kwargs) -> Any:
        return data

    def set_before_func(self, before_func: Callable):
        self.before_func = before_func

    def def_handle_func(self, data: Any, *args, **kwargs) -> Any:
        return data

    def set_handle_func(self, handle_func: Callable):
        self.handle_func = handle_func

    def def_after_func(self, data: Any, *args, **kwargs) -> Any:
        return data

    def set_after_func(self, after_func: Callable):
        self.after_func = after_func

    def run(self, data_iter: Iterable):
        logger.info(f"{self.concurrent_type.value}任务开始执行")
        with self.executor_pool(max_workers=self.num_of_processor) as executor:
            # 获取所有的handler
            handlers = list(self.iterator_handle())
            keys = list(self._iterator_handle_key())

            # 提交任务
            tasks = []
            for identifier in range(self.num_of_processor):
                task = executor.submit(single_processor, identifier=identifier, num_of_processor=self.num_of_processor,
                                       handler_with_key=zip(keys, handlers), content=content, timeout=self.timeout)
                tasks.append(task)

            completed_res = []
            for future in futures.as_completed(tasks):
                result = future.result()
                if hasattr(result, '__iter__'):
                    completed_res.extend(result)
                else:
                    completed_res.append(result)
            logger.info(f"{self.concurrent_type.value}任务执行完成, 开始返回结果")

            # 保持结果有序
            completed_res.sort(key=lambda k: k[0])

            outputs = []
            for _, output in completed_res:
                outputs.extend(output)
            yield outputs
            logger.info(f"{self.concurrent_type.value}执行完毕")
