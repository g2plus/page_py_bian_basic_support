#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: concurrent_type_enum.py
@Description: 
@time: 2023/10/4 17:23
"""

from enum import Enum


class ConCurrentTypeEnum(Enum):
    THREAD = "多线程方式"
    PROCESS = "多进程方式"
