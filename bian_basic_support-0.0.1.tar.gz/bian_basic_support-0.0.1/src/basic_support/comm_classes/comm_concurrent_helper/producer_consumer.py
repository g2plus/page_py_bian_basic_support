#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: producer_consumer.py
@Description: 
@time: 2023/10/2 20:06
"""
import os
import queue
import threading
import types
from abc import ABC, ABCMeta
from multiprocessing import Process, Queue, cpu_count, Lock, Manager
from typing import Any, Dict
from typing import Generator, Iterator, Callable

from basic_support.comm_classes.comm_concurrent_helper.concurrent_type_enum import ConCurrentTypeEnum
from basic_support.logger.logger_config import logger

# 结束标志，用于通知消费者结束
END_SIGNAL = None


class ProducerConsumer(ABC, metaclass=ABCMeta):
    def __init__(self, producer_func: Callable[[any, ...], any] = None,
                 consumer_func: Callable[[any, ..., Dict], any] = None,
                 consumer_before_func: Callable[[], Dict] = None,
                 concurrent_type: ConCurrentTypeEnum = ConCurrentTypeEnum.THREAD, num_of_worker: int = None,
                 num_os_producer: int = 1):
        """
        :param producer_func: 生产者单样本处理函数
        :param consumer_func: 消费者单样本处理函数
        :param consumer_before_func: 消费者对象构建函数
        :param concurrent_type: 并发类型
        :param num_of_worker: 总工作的线程或进程数
        :param num_os_producer: 生产者数量，num_of_consumer = num_of_worker-num_os_producer
        """
        self.num_of_worker = min(num_of_worker, cpu_count()) if num_of_worker else cpu_count()
        self.size_of_queue = 1024
        assert isinstance(concurrent_type, ConCurrentTypeEnum), f'不支持{ConCurrentTypeEnum}以外的类型'
        self.concurrent_type = concurrent_type
        self.num_of_producer = num_os_producer

        # 设置样本处理函数
        self.producer_func = producer_func or self._def_producer_func
        self.consumer_func = consumer_func or self._def_consumer_func
        self.consumer_before_func = consumer_before_func

        # 初始化进程间共享列表 其他的还有共享字典等，都是进程安全的
        # self.dealt_sample_lst = Manager().list()

        # 定义线程或进程相关对象
        self.que = queue.Queue if self.concurrent_type == ConCurrentTypeEnum.THREAD else Queue
        self.concurrent = threading.Thread if self.concurrent_type == ConCurrentTypeEnum.THREAD else Process

    def run(self, data_iter: Iterator[Any]) -> Generator:
        """
        执行函数
        :param data_iter: 数据迭代器(非生成器)，如果是生成器会触发生产者数量置为1
        :return: 结果生成器
        """

        if isinstance(data_iter, types.GeneratorType):
            num_of_producer = 1
            logger.debug(
                f"输入的数据迭代器是[生成器], 这里将生产者的数量置为1, 如果希望使用多生产者, 请确保数据迭代器是非生成器类型")
        else:
            num_of_producer = self.num_of_producer
        num_of_consumer = self.num_of_worker - num_of_producer

        if self.concurrent_type == ConCurrentTypeEnum.THREAD:
            lock = threading.Lock()
            signal_lst = []
        else:
            lock = Lock()
            signal_lst = Manager().list()

        # 1. 新建一个大小为 size_of_queue 的队列
        work_queue = self.que(self.size_of_queue)
        res_queue = self.que(self.size_of_queue)

        # 2.多个生产者 - 这里要注意任务的拆分，数据的产生来源是不是可以被多个生产者共享
        process_list = []  # 进程队列
        for choice in range(num_of_producer):
            sent = self.concurrent(target=self._producer, args=(
                work_queue, data_iter, choice, num_of_producer, num_of_consumer, signal_lst,
                lock))
            sent.start()
            process_list.append(sent)

        # 3. 多个消费者
        for choice in range(num_of_consumer):
            process = self.concurrent(target=self._consumer, args=(work_queue, res_queue, choice))
            process.start()
            process_list.append(process)

        count = 0
        while True:
            res = res_queue.get()
            if res is END_SIGNAL:
                count += 1
                if count >= num_of_consumer:
                    break
                continue
            _, res = res
            yield res

        # 4. 阻塞，等待任务完成
        # [process.join() for process in process_list]

        logger.debug("生产者消费者[执行函数] 结束")

    def _producer(self, work_queue: Queue or queue.Queue, data_iter: Iterator[Any], choice: int, num_of_producer: int,
                  num_of_consumer, signal_lst, lock):
        """
        生产者
            JoinableQueue 比Queue多了task_done() 与join()两个函数，多用于生产者消费者问题。
            task_done()是用在get()后，发送通知说我get完了
            join()是说Queue里所有的task都已处理。
        :param work_queue: 工作队列
        :param data_iter: 数据迭代器
        :param choice: 样本选择的索引
        """
        logger.debug(f"生产者[{choice}] 开始工作")

        for idx, data in enumerate(data_iter):
            if idx % num_of_producer == choice:
                task = self.producer_func(data)
                logger.debug(f"生产者[{choice}] 添加任务")
                try:
                    work_queue.put((idx, task))
                except Exception as e:
                    logger.warning(f"生产者[{choice}] 添加任务发生超时")
                logger.debug(f"生产者[{choice}] 完成任务添加")

        with lock:
            signal_lst.append(None)
            if len(signal_lst) == num_of_producer:
                for _ in range(num_of_consumer):
                    work_queue.put(END_SIGNAL)

        logger.debug(f"生产者[{choice}] 工作结束")

    def _consumer(self, work_queue: Queue or queue.Queue, res_queue: Queue or queue.Queue, choice: int):
        """
        消费者
        :param work_queue: 工作队列
        :param res_queue: 结果队列
        """
        objs = self.consumer_before_func() if self.consumer_before_func else None
        con_type = '线程' if self.concurrent_type == ConCurrentTypeEnum.THREAD else '进程'
        while True:
            logger.debug(f'进程号: {os.getpid()} {con_type}[{choice}] 获取任务中...')
            try:
                task = work_queue.get()
            except Exception as e:
                logger.warning(f'进程号: {os.getpid()} {con_type}[{choice}] 获取任务发生超时')
                break
            logger.debug(f'进程号: {os.getpid()} {con_type}[{choice}] 获取到任务')
            if task is END_SIGNAL:
                res_queue.put(END_SIGNAL)
                break

            # 处理数据
            _, task = task
            logger.debug(f"{con_type}[{choice}] 开始处理")
            res_data = self.consumer_func(task, objs)
            logger.debug(f"{con_type}[{choice}] 处理结束")
            res_queue.put((None, res_data))
        logger.debug(f'进程号: {os.getpid()} {con_type}[{choice}] 处理结束')

    def _def_producer_func(self, data: Any) -> Any:
        return data

    def _def_consumer_func(self, data: Any) -> Any:
        return data
