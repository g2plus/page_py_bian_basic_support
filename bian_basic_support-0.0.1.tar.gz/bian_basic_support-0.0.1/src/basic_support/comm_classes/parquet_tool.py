#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: parquet_tool.py
@Description:
        别再用CSV了，更高效的Python文件存储方案
        https://www.cnblogs.com/harrylyx/p/15141986.html
@time: 2024/12/17 17:28
"""
import os
import shutil
import traceback
from contextlib import contextmanager
from functools import wraps
from typing import List, Dict, Callable, Iterable, Any

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from tqdm import tqdm

from basic_support.comm_funcs.comm_utils import iter_slice_tool
from basic_support.logger.logger_config import logger


class ParquetTool:
	def __init__(self, base_path: str, partion_tag: str = None, max_file_size=100 * 10000, is_clean: bool = True,
				 schema=None):
		"""
		初始化工具类

		:param base_path: Parquet文件的基础路径，分区文件将保存在此路径下
		:param partion_tag: 分区标识(用于并发写)
		:param max_file_size: 每个Parquet文件的最大记录数
		:param is_clean: 是否清空目标文件夹
		:param schema: 数据的schema信息
		"""
		self.base_path = base_path
		self.is_clean = is_clean

		self.partion_tag = partion_tag
		self.max_file_size = max_file_size
		self.current_file_index = 0
		self.current_file_path = None
		self.writer = None
		self.current_file_size = 0
		self.current_schema = schema

		self.is_read_to_write = False

	def _get_new_writer(self):
		"""
		创建一个新的ParquetWriter

		:return: ParquetWriter实例
		"""
		tag = f"[tag:{self.partion_tag}]" if self.partion_tag else ""
		self.current_file_path = os.path.join(self.base_path, f"{tag}part-{self.current_file_index:05d}.parquet")

		self.current_file_index += 1
		self.current_file_size = 0
		return pq.ParquetWriter(self.current_file_path, self.current_schema)

	def write_batch(self, batch_data: List[Dict], is_write_table: bool = False):
		"""
		写入一批数据到Parquet文件

		:param batch_data: 一批数据，通常是一个列表的字典
		:param is_write_table: 是否以table的形式写入(不建议)
		"""

		if not self.is_read_to_write:
			if self.is_clean and os.path.exists(self.base_path):
				shutil.rmtree(self.base_path)
			os.makedirs(self.base_path, exist_ok=True)
			self.is_read_to_write = True
			logger.info(f"目标文件夹准备文件")

		if is_write_table:
			df = pd.DataFrame(batch_data)

			if self.current_schema is None:
				# 自动推断数据架构
				self.current_schema = pa.Schema.from_pandas(df)
				logger.info(f"数据的schema为: {self.current_schema}")

			table = pa.Table.from_pandas(df)

			if self.writer is None:
				self.writer = self._get_new_writer()

			self.writer.write_table(table)
			self.current_file_size += table.num_rows
		else:
			record = pa.RecordBatch.from_pylist(batch_data)

			if self.current_schema is None:
				# 自动推断数据架构
				df = record.to_pandas()
				self.current_schema = pa.Schema.from_pandas(df)
				logger.info(f"数据的schema为: {self.current_schema}")

			if self.writer is None:
				self.writer = self._get_new_writer()

			self.writer.write_batch(record)

			self.current_file_size += record.num_rows

		if self.current_file_size >= self.max_file_size:
			self.writer.close()
			self.writer = self._get_new_writer()

	def finalize(self):
		"""
		最后关闭ParquetWriter
		"""
		try:
			if self.writer is not None:
				self.writer.close()
				self.writer = None
			if self.current_file_size == 0 and self.current_file_path is not None:
				os.remove(self.current_file_path)
		except Exception as e:
			logger.warning(f"{traceback.format_exc()}")
		finally:
			logger.info(f"环境句柄等清理完毕")

	def _read_parquet_with_table(self, base_path, batch_size=500):
		"""
		[batch_size划分不准确]读取分区的Parquet文件，以批量方式返回数据。该方法手动处理批次划分。

		:param base_path: str, Parquet文件的基础路径。
		:param batch_size: int, 每批次读取的最大行数。默认为500。
		:return: 生成器，每次返回一条记录，以Python基础类型表示。
		"""
		sorted_files = sorted(os.listdir(base_path), key=lambda x: int(x.split('-')[1].split('.')[0]))

		for file_name in tqdm(sorted_files, desc="文件遍历中"):
			if file_name.endswith(".parquet"):
				file_path = os.path.join(base_path, file_name)
				reader = pq.ParquetFile(file_path)
				num_row_groups = reader.num_row_groups
				for row_group in range(num_row_groups):
					table = reader.read_row_group(row_group)
					num_batches = (table.num_rows + batch_size - 1) // batch_size

					for batch_index in range(num_batches):
						start = batch_index * batch_size
						end = min(start + batch_size, table.num_rows)
						batch = table.slice(start, end)

						# Convert to list of dictionaries with Python native types
						batch_as_list = batch.to_pylist()
						for record in batch_as_list:
							yield record

	def _read_parquet_with_batch(self, base_path, batch_size=500):
		"""
		读取分区的Parquet文件，以批量方式返回数据。该方法利用pyarrow的iter_batches功能进行批次处理。

		:param base_path: str, Parquet文件的基础路径。
		:param batch_size: int, 每批次读取的最大行数。默认为500。
		:return: 生成器，每次返回一条记录，以Python基础类型表示。
		"""
		sorted_files = sorted(os.listdir(base_path), key=lambda x: int(x.split('-')[1].split('.')[0]))

		for file_name in tqdm(sorted_files, desc="文件遍历中"):
			if file_name.endswith(".parquet"):
				file_path = os.path.join(base_path, file_name)
				reader = pq.ParquetFile(file_path)

				# 使用 iter_batches 直接按批次处理数据
				for batch in reader.iter_batches(batch_size=batch_size):
					batch_as_list = batch.to_pylist()
					for record in batch_as_list:
						yield record

	def read_parquet_iter(self, batch_size=5000, ):
		"""
		建议使用
		:param batch_size:
		:return:
		"""
		data_iter = self._read_parquet_with_batch(base_path=self.base_path, batch_size=batch_size)
		for k, records in iter_slice_tool(data_iter, batch_size=batch_size):
			for record in records:
				yield record


def write_to_parquet(output_base_path: str, is_write_to_parquet: bool = True, batch_size: int = 5000,
					 max_file_size: int = 100 * 10000):
	"""
	输出到parquet 的装饰器
	:param output_base_path: 输出到parquet的基础文件目录(用于存放数据)
	:param is_write_to_parquet: 是否真正输出
	:param batch_size: 单批量写入大小
	:param max_file_size: 单个文件最大记录数
	:return:
	"""

	def write_func(func: Callable[..., Iterable[Dict[str, Any]]]):
		parquet_util = ParquetTool(output_base_path, max_file_size=max_file_size)

		@wraps(func)
		def inner(*args, **kwargs):
			nonlocal parquet_util
			data_iter = func(*args, **kwargs)
			if data_iter is None:
				return data_iter
			for k, records in iter_slice_tool(data_iter, batch_size=batch_size):
				records = list(records)
				if is_write_to_parquet:
					parquet_util.write_batch(batch_data=records)
				logger.info(
					f"{output_base_path}{'' if is_write_to_parquet else '[模拟]'}写入完成, 记录数为: {len(records)}")

			parquet_util.finalize()
			logger.info(f"入库任务结束")
			return data_iter

		return inner

	return write_func


@contextmanager
def write_to_parquet_context(output_base_path: str, is_clean: bool = True, max_file_size: int = 100 * 10000):
	"""
	输出到parquet 的上下文管理器
	:param output_base_path: 输出到parquet的基础文件目录(用于存放数据)
	:param is_clean: 是否清空文件夹
	:param max_file_size: 单个文件最大记录数
	"""
	parquet_util = ParquetTool(base_path=output_base_path, max_file_size=max_file_size, is_clean=is_clean)
	try:
		yield parquet_util
	finally:
		parquet_util.finalize()
