#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: mixin_class.py
@Description: 实现一些常用的混入类
@time: 2020/7/5 9:43
"""
from reprlib import recursive_repr
from typing import Dict, Iterable

from basic_support.comm_funcs.comm_utils import iter_slice_tool
from basic_support.data_access.dao.dao_utils import DaoUtils
from basic_support.logger.logger_config import logger


class ReprMixin:
    """
    类表示的混入类，结合__init__的参数列表，返回符合初始化函数的repr表示
    """
    __slots__ = ()  # 混入类没有实例变量，因为直接实例化混入类是没有任何意义的

    @recursive_repr()
    def __repr__(self):
        """
        __repr__() 生成的文本字符串标准做法是需要让 eval(repr(x)) == x 为真。
        如果实在不能这样子做，应该创建一个有用的文本表示，并使用 < 和 > 括起来。
        """
        if not hasattr(self, '__init_args__'):
            import inspect
            self.__init_args__ = inspect.getfullargspec(self.__init__).args[1:]
        try:
            repr_str = f"{self.__class__.__name__}({', '.join(['%s=%r' % (k, type(self.__dict__[k])(self.__dict__[k])) for k in self.__init_args__ if k in self.__dict__.keys()])})"
        except:
            repr_str = f"{self.__class__.__name__}({', '.join(['%s=%r' % (k, self.__dict__[k]) for k in self.__init_args__ if k in self.__dict__.keys()])})"
        return repr_str


class EasyEqMixin:
    """
    简单对象比较 的 混入类
    """
    __slots__ = ()

    def __hash__(self):
        return sum(hash(v) for k, v in self.__dict__.items() if v.__hash__)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self is other:
            return True
        if self.__dict__.keys() != other.__dict__.keys():
            return False
        return all(self.__dict__[k] == other.__dict__[k] for k in self.__dict__.keys())


class ToDictMixin:
    """
    属性转字典 的 混入类
    """
    __slots__ = ()

    @property
    def to_dict(self):
        def convert_to_dict(obj):
            if isinstance(obj, dict):
                return {k: convert_to_dict(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_to_dict(item) for item in obj]
            elif hasattr(obj, '__dict__'):
                return {key: convert_to_dict(value) for key, value in obj.__dict__.items()}
            else:
                return obj

        return convert_to_dict(self)


class BuildFromDictMixin:
    """
    根据输入的字典构建对象
    """
    __slots__ = ()

    @classmethod
    def build_from_record(cls, record: Dict):
        obj = cls(**record)
        return obj


class WriteToDbMixin:
    __slots__ = ('is_clean', 'is_write')

    def write_to_db(self, dao, table_name: str, records: Iterable[Dict], batch_size: int = 5000):
        """
        入库操作
        :param dao:
        :param table_name: 表名
        :param records: 记录值
        :param batch_size: 批量写入的大小
        :return:
        """
        if hasattr(self, 'is_clean') and self.is_clean:
            dao.truncate_table(table_name=table_name)
            logger.info(f"清空[{table_name}] 完成")

        if (not hasattr(self, 'is_write') or (hasattr(self, 'is_write') and self.is_write)) and records:
            inserter = None

            for key, datas in iter_slice_tool(records, batch_size=batch_size):
                datas = list(datas)

                if inserter is None:
                    inserter, sql = DaoUtils.utils_inject_insert_sql_with_params(dao=dao,
                                                                                 table_name=table_name,
                                                                                 params=list(datas[0].keys()),
                                                                                 time_cols=('insert_time',))
                inserter(datas)
                logger.info(f"入库[{len(datas)}]条")

            # inserter, sql = DaoUtils.utils_inject_insert_sql_with_params(dao=dao, table_name=table_name,
            #                                                              params=list(records[0].keys()),
            #                                                              time_cols=('insert_time',))
            # inserter(records)
            # logger.info(f"{table_name}入库完成, 记录数为: {len(records)}")
        else:
            logger.warning(f"写入动作没开启: is_write={self.is_write}")
