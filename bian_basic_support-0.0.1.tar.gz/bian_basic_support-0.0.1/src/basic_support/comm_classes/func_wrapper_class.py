# @Time    : 2020/8/4 9:09
# @Author  : YuQL
# @FileName: func_wrapper_class.py
# @Software: PyCharm
from typing import Callable, Generic, TypeVar

P1 = TypeVar("P1")
P2 = TypeVar("P2")
P3 = TypeVar("P3")
P4 = TypeVar("P4")
P5 = TypeVar("P5")


class OneDynamicParamFuncWrapperClass(Generic[P1]):

    def __init__(self, func: Callable, **kwargs):
        """
        将函数包装成一个动态参数调用对象的辅助类
        :param func:
        :param kwargs:
        """
        self._func = func
        self._kwargs = kwargs if kwargs is not None else dict()

    def __call__(self, param: P1):
        return self._func(param, **self._kwargs)


class TwoDynamicParamFuncWrapperClass(Generic[P1, P2]):

    def __init__(self, func: Callable, **kwargs):
        """
        将函数包装成两个动态参数调用对象的辅助类
        :param func:
        :param kwargs:
        """
        self._func = func
        self._kwargs = kwargs if kwargs is not None else dict()

    def __call__(self, param1: P1, param2: P2):
        return self._func(param1, param2, **self._kwargs)


class ThreeDynamicParamFuncWrapperClass(Generic[P1, P2, P3]):
    def __init__(self, func: Callable, **kwargs):
        """
        将函数包装成三个动态参数调用对象的辅助类
        :param func:
        :param kwargs:
        """
        self._func = func
        self._kwargs = kwargs if kwargs is not None else dict()

    def __call__(self, param1: P1, param2: P2, param3: P3):
        return self._func(param1, param2, param3, **self._kwargs)


class FourDynamicParamFuncWrapperClass(Generic[P1, P2, P3, P4]):
    def __init__(self, func: Callable, **kwargs):
        """
        将函数包装成四个动态参数调用对象的辅助类
        :param func:
        :param kwargs:
        """
        self._func = func
        self._kwargs = kwargs if kwargs is not None else dict()

    def __call__(self, param1: P1, param2: P2, param3: P3, param4: P4):
        return self._func(param1, param2, param3, param4, **self._kwargs)

class FiveDynamicParamFuncWrapperClass(Generic[P1, P2, P3, P4]):
    def __init__(self, func: Callable, **kwargs):
        """
        将函数包装成四个动态参数调用对象的辅助类
        :param func:
        :param kwargs:
        """
        self._func = func
        self._kwargs = kwargs if kwargs is not None else dict()

    def __call__(self, param1: P1, param2: P2, param3: P3, param4: P4, param5: P5):
        return self._func(param1, param2, param3, param4, param5, **self._kwargs)
