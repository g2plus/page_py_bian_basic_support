#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: default_dict_with_key.py
@Description: 默认工厂带key的 默认字典
@time: 2021/9/10 13:28
"""
from collections import defaultdict


class DefaultDictWithKey(defaultdict):
    def __init__(self, *args, **kwargs):
        super(DefaultDictWithKey, self).__init__(*args, **kwargs)

    def __missing__(self, key):
        if self.default_factory is not None:
            self[key] = value = self.default_factory(key)
            return value
        else:
            raise KeyError(key)


# if __name__ == '__main__':
#     class InitClassMaker:
#         def __init__(self, connect_key: str):
#             self.connect_key = connect_key
#
#         def fn(self):
#             print(f"我是构建字典时的key: {self.connect_key}")
#
#
#     dic = DefaultDictWithKey(InitClassMaker)
#     dic['hyc'].fn()
