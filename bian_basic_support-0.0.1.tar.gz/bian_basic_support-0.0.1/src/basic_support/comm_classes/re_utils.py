#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: re_utils.py
@Description: 正则匹配的工具类
            在线正则表达式验证：https://regex101.com/
@time: 2023/7/7 15:04
"""
from typing import Iterable, List

import regex as re


class RePattern:
    """ 常用的正则表达式 """
    # url正则表达式(待验证)
    url_pattern = "(https?|ftp|file)://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]"
    # 数字正则表达式
    number_pattern = "\d+[,.\-0-9]+"


re_pattern = RePattern()


class ReMatch:
    def __init__(self, match, start: int = 0):
        """
        指定起始位置的Match类
        :param match: re.Match对象
        :param start:
        """
        self.match = match
        self.start_idx = start

    @property
    def endpos(self):
        """ 本次搜索结束位置索引 """
        if self.match:
            return self.match.endpos + self.start_idx
        else:
            return None

    @property
    def lastgroup(self):
        """ 本次搜索匹配到的最后一个分组的别名 """
        if self.match:
            return self.match.lastgroup
        else:
            return None

    @property
    def lastindex(self):
        """ 本次搜索匹配到的最后一个分组的索引 """
        if self.match:
            return self.match.lastindex + self.start_idx if type(self.match.lastindex) == int else self.match.lastindex
        else:
            return None

    @property
    def pos(self):
        """ 本次搜索开始位置索引 """
        if self.match:
            return self.match.pos + self.start_idx
        else:
            return None

    @property
    def re(self):
        """ 本次搜索使用的SRE_Pattern对象 """
        if self.match:
            return self.match.re
        else:
            return None

    @property
    def regs(self):
        """ 列表，元素为元组，包含本次搜索匹配到的所有分组的起止位置 """
        if self.match:
            return tuple([(s + self.start_idx, e + self.start_idx) for s, e in self.match.regs])
        else:
            return None

    def end(self, *args, **kwargs):
        """ 返回指定分组的结束位置，默认返回正则表达式所匹配到的最后一个字符的索引 """
        return self.match.end(*args, **kwargs) + self.start_idx

    def expand(self, *args, **kwargs):
        """ 根据模版返回相应的字符串，类似与 sub 函数里面的 repl， 可使用 \1 或者 \g 来选择分组 """
        return self.match.expand(*args, **kwargs)

    def group(self, *args, **kwargs):
        """ 根据提供的索引或名字返回响应分组的内容，默认返回 start() 到 end() 之间的字符串， 提供多个参数将返回一个元组 """
        return self.match.group(*args, **kwargs)

    def groupdict(self, *args, **kwargs):
        """ 返回一个包含所有匹配到的命名分组的字典，没有命名的分组不包含在内，key 为组名， value 为匹配到的内容，参数 default 为没有参与本次匹配的命名分组提供默认值 """
        return self.match.groupdict(*args, **kwargs)

    def _build_key_2_index(self):
        groups = self.match.groups()
        group_2_index = []
        for idx, group in enumerate(groups, start=1):
            group_2_index.append((group, self.match.start(idx) + self.start_idx, self.match.end(idx) + self.start_idx))

        return group_2_index

    def groupdict_with_index(self, *args, **kwargs):
        """ 同groupdict, 但匹配结果包装为带索引的ContentWithIndex对象 """
        value = self.match.groupdict(*args, **kwargs)
        new_group_dict = dict()
        for k, v in value.items():
            for group, s, e in self._build_key_2_index():
                if v == group:
                    new_group_dict[k] = ContentWithIndex(content=v, start=s, end=e)
        assert len(new_group_dict) == len(value)
        return new_group_dict

    def groups(self, *args, **kwargs):
        """ 以元组形式返回每一个分组匹配到的字符串，包括没有参与匹配的分组，其值为 default """
        return self.match.groups(*args, **kwargs)

    def span(self, *args, **kwargs):
        """ 返回指定分组的起止位置组成的元组，默认返回由 start() 和 end() 组成的元组 """
        return tuple([(s + self.start_idx, e + self.start_idx) for s, e in self.match.span(*args, **kwargs)])

    def start(self, *args, **kwargs):
        """ 返回指定分组的开始位置，默认返回正则表达式所匹配到的第一个字符的索引 """
        return self.match.start(*args, **kwargs) + self.start_idx

    def start_and_end(self):
        return self.start(), self.end()

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        if self.match:
            return f"<regex.Match object; span=({self.start()}, {self.end()}), match='{self.match.group()}'>"
        else:
            return f"<regex.Match object; span=(None, None), match='{self.match}'>"


class ContentWithIndex:
    def __init__(self, content: str, start: int, end: int):
        """
        带索引的切分结果
        :param content: 切分结果
        :param start: 起始位置
        :param end: 结束位置
        """
        self.content = content
        self.start = start
        self.end = end

    @property
    def pos(self):
        return self.start

    @property
    def posend(self):
        return self.end

    def start_and_end(self):
        return self.start, self.end

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"{self.content} ({self.start}, {self.end})"


class ReUtils:
    def __init__(self):
        """ 正则匹配的工具类 """
        pass

    @staticmethod
    def match(pattern, string, flags=0, start: int = 0):
        match = re.match(pattern=pattern, string=string, flags=flags)
        return ReMatch(match=match, start=start)

    @staticmethod
    def fullmatch(pattern, string, flags=0, start: int = 0):
        match = re.fullmatch(pattern=pattern, string=string, flags=flags)
        return ReMatch(match=match, start=start)

    @staticmethod
    def search(pattern, string, flags=0, start: int = 0):
        match = re.search(pattern=pattern, string=string, flags=flags)
        return ReMatch(match=match, start=start)

    @staticmethod
    def sub(pattern, repl, string, count=0, flags=0):
        return re.sub(pattern=pattern, repl=repl, string=string, count=count, flags=flags)

    @staticmethod
    def subn(pattern, repl, string, count=0, flags=0):
        return re.subn(pattern=pattern, repl=repl, string=string, count=count, flags=flags)

    @staticmethod
    def split(pattern, string, maxsplit=0, flags=0):
        return re.split(pattern=pattern, string=string, maxsplit=maxsplit, flags=flags)

    @staticmethod
    def split_with_index(pattern, string, maxsplit: int = 0, flags=0, start: int = 0) -> List[ContentWithIndex]:
        """
        split带内容索引
        :param pattern:
        :param string:
        :param maxsplit:
        :param flags:
        :param start:
        :return:
        """
        matches = ReUtils.finditer(pattern, string, flags, start=start)  # 使用re.finditer()获取匹配的位置和内容
        content_with_indexs = []
        start_idx = start
        for match in matches:
            end_idx = match.start()  # 当前分隔符的起始位置
            content_with_index = ContentWithIndex(content=string[start_idx - start:end_idx - start], start=start_idx,
                                                  end=end_idx)
            content_with_indexs.append(content_with_index)  # 添加分隔符之前的文本及其位置信息
            start_idx = match.end()  # 更新下一个分隔符的起始位置
            if maxsplit and len(content_with_indexs) >= maxsplit:
                content_with_index = ContentWithIndex(content=string[start_idx - start:], start=start_idx,
                                                      end=len(string))
                content_with_indexs.append(content_with_index)  # 添加分隔符之前的文本及其位置信息
                break
        else:
            # 添加最后一个分隔符之后的文本
            content_with_index = ContentWithIndex(content=string[start_idx - start:], start=start_idx,
                                                  end=len(string) + start)
            content_with_indexs.append(content_with_index)

        # if maxsplit and len(content_with_indexs) < maxsplit + 1 and start_idx < len(string):
        #     # 添加最后一个分隔符之后的文本
        #     content_with_index = ContentWithIndex(content=string[start_idx-start:], start=start_idx, end=len(string))
        #     content_with_indexs.append(content_with_index)

        return content_with_indexs

    @staticmethod
    def findall(pattern, string, flags=0):
        return re.findall(pattern=pattern, string=string, flags=flags)

    @staticmethod
    def finditer(pattern, string, flags=0, start: int = 0) -> Iterable[ReMatch]:
        for match in re.finditer(pattern=pattern, string=string, flags=flags):
            yield ReMatch(match=match, start=start)


if __name__ == '__main__':
    pat = ','
    doc = ',h,y,c,'

    text = '22python world'
    m = ReUtils.match(r"python", text)
    print(m.group(0)) if m else print('not match')

    max_split = 3
    res = re.split(pat, doc, maxsplit=max_split)
    print(res)
    res = ReUtils.split_with_index(pat, doc, maxsplit=max_split)
    print(res)

    max_split = 1
    res = re.split(pat, doc, maxsplit=max_split)
    print(res)
    res1 = ReUtils.split_with_index(pat, doc, maxsplit=max_split)
    print(res)
    assert len(res) == len(res1)

    max_split = 4
    res = re.split(pat, doc, maxsplit=max_split)
    print(res)
    res1 = ReUtils.split_with_index(pat, doc, maxsplit=max_split)
    print(res)
    assert len(res) == len(res1)

    max_split = 5
    res = re.split(pat, doc, maxsplit=max_split)
    print(res)
    res1 = ReUtils.split_with_index(pat, doc, maxsplit=max_split)
    print(res)
    assert len(res) == len(res1)

    # ReUtils.split(pat, doc, maxsplit=3)
    # Out[12]: ['', 'h', 'y', 'c,b,v,']
    # ReUtils.split(pat, doc, maxsplit=1)
    # Out[13]: ['', 'h,y,c,b,v,']
    # re.split(pat, doc, maxsplit=1)
    # Out[14]: ['', 'h,y,c,b,v,']
    # ReUtils.split(pat, doc, maxsplit=8)
    # Out[15]: ['', 'h', 'y', 'c', 'b', 'v', '']
    # re.split(pat, doc, maxsplit=9)
    # Out[16]: ['', 'h', 'y', 'c', 'b', 'v', '']
    # res = ReUtils.split(pat, doc, maxsplit=8)
    # res = ReUtils.split_with_index(pat, doc, maxsplit=8)
    # ReUtils.split_with_index(pat, doc, maxsplit=8)
    # Out[19]: [(0, 0), h(1, 2), y(3, 4), c(5, 6), b(7, 8), v(9, 10), (11, 11)]
    # ReUtils.split_with_index(pat, doc, maxsplit=3)
    # Out[20]: [(0, 0), h(1, 2), y(3, 4), c(5, 6)]
