#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: diff_2_word.py
@Description: 对比文本，并将文本的差异输出到doc
@time: 2024/10/22 16:52
"""
from basic_support.comm_funcs.text_utils import compare_texts


class Diff2Word:
    def __init__(self, file_name: str):
        from docx import Document

        self.file_name = file_name
        self.doc = Document()

    def add_texts(self, old_text: str, new_text: str):
        from docx.shared import RGBColor
        from docx.enum.text import WD_COLOR_INDEX

        changes = compare_texts(old_text, new_text)

        # 第一部分：显示旧文本的差异
        paragraph = self.doc.add_paragraph()
        for change in changes:
            if change.change_type in ['equal', 'insert']:
                text = old_text[change.old_start:change.old_end]
                paragraph.add_run(text)
            elif change.change_type == 'delete':
                text = old_text[change.old_start:change.old_end]
                run = paragraph.add_run(text)
                run.font.color.rgb = RGBColor(255, 0, 0)  # 红色表示删除
            elif change.change_type == 'replace':
                text = old_text[change.old_start:change.old_end]
                del_run = paragraph.add_run(text)
                del_run.font.highlight_color = WD_COLOR_INDEX.YELLOW  # 黄色表示修改

        paragraph.add_run('\n\n')

        # 第二部分：显示新文本的差异
        paragraph = self.doc.add_paragraph()
        for change in changes:
            if change.change_type in ['equal', 'delete']:
                text = new_text[change.new_start:change.new_end]
                paragraph.add_run(text)
            elif change.change_type == 'insert':
                text = new_text[change.new_start:change.new_end]
                run = paragraph.add_run(text)
                run.font.color.rgb = RGBColor(0, 255, 0)  # 绿色表示新增
            elif change.change_type == 'replace':
                text = new_text[change.new_start:change.new_end]
                ins_run = paragraph.add_run(text)
                ins_run.font.highlight_color = WD_COLOR_INDEX.YELLOW  # 黄色表示修改

    def __enter__(self):
        # 在进入上下文时执行的代码（如资源分配）
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        # 在退出上下文时执行的代码（如资源释放）
        # 如果需要处理异常，返回 True，否则返回 False 或 None
        self.doc.save(self.file_name)
