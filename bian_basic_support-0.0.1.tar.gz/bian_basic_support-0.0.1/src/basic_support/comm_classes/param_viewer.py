#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: param_viewer.py
@Description: 参数定义打印
@time: 2024/10/18 14:09
"""

from dataclasses import dataclass, fields, MISSING
from dataclasses import field as d_field
from typing import Any, List, Type


@dataclass
class SingleParam:
    field: str = d_field(default=None)
    type: str = d_field(default=None)
    required: bool = d_field(default=None)
    description: str = d_field(default=None)
    min_length: int = d_field(default=None)  # 如果需要包含 min_length 字段
    max_length: int = d_field(default=None)  # 如果需要包含 min_length 字段

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        # 格式化字符串
        return (f"{self.field:<15} | {self.type:<10} | {str(self.required):<8} | "
                f"{self.min_length or '':<10} | {self.max_length or '':<10} | {self.description:<30}")


@dataclass
class ParamUdf:
    params: List[SingleParam] = d_field(default_factory=list)

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        # 表头
        header = f"{'Field':<15} | {'Type':<10} | {'Required':<8} | {'Min Length':<10} | {'Max Length':<10} | {'Description':<30}"
        separator = '-' * len(header)
        # 表内容
        body = "\n".join(str(param) for param in self.params)
        return f"{header}\n{separator}\n{body}"


def generate_param_udf(model: Type[Any]) -> ParamUdf:
    params = []

    if hasattr(model, '__dataclass_fields__'):
        # 处理 dataclass
        for field_info in fields(model):
            field_name = field_info.name
            field_type = str(field_info.type)
            required = field_info.default is MISSING and field_info.default_factory is MISSING
            description = field_info.metadata.get('help', '') if field_info.metadata else ''
            min_length = field_info.metadata.get('min_length', None) if field_info.metadata else None
            max_length = field_info.metadata.get('max_length', None) if field_info.metadata else None

            params.append(SingleParam(
                field=field_name,
                type=field_type,
                required=required,
                description=description,
                min_length=min_length,
                max_length=max_length
            ))
    else:
        # 处理 Pydantic 模型
        schema = model.schema()
        properties = schema.get("properties", {})

        for field, info in properties.items():
            required = field in schema.get("required", [])
            description = info.get("description", "")
            if not description:
                description = info.get("metadata", dict()).get('help', '')

            params.append(SingleParam(
                field=field,
                type=info.get("type", ""),
                required=required,
                description=description,
                min_length=info.get("minLength", None),
                max_length=info.get("max_length", None)
            ))

    return ParamUdf(params=params)
