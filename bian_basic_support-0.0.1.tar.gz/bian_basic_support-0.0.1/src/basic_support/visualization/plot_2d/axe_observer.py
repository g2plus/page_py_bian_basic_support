# -*- encoding: utf-8 -*-
"""
@File    : axe_observer.py
@Time    : 2022/10/9 14:18
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from typing import Optional
from matplotlib import pyplot as plt

from basic_support.visualization.abs_observer import AbsObserver
from basic_support.visualization.plot_2d.context import Plot2dContext
from basic_support.visualization.plot_2d.msg import Plot2dMsg

plt.rcParams["font.sans-serif"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False


class AxeObserver(AbsObserver[Plot2dMsg, Plot2dContext]):  # 区域分组设置
    def __init__(self, name: str, context: Optional[Plot2dContext] = None):
        super().__init__(name, context)
        self._collect_x_info = self._update_x_tick_info()
        self._ax_idx_set = set()

    def _update_x_tick_info(self):
        x_input_set = set()

        def _(x_input: list = None):
            nonlocal x_input_set
            if x_input is None:
                assert self.context is not None
                assert self.context.axe_context is not None
                x_input_set = sorted(x_input_set)
                context = self.context.axe_context
                context.x_lim = (0, len(x_input_set))
                context.x_tick_label_map = {_: i for i, _ in enumerate(x_input_set)}
                context.x_tick_range = list(context.x_tick_label_map.values())
                context.x_tick_label = list(context.x_tick_label_map.keys())
            else:
                x_input_set = {*x_input, *x_input_set}
            return

        return _

    def _global_setting_(self):  # 暂时全局，无法分组设置
        ax_context = self.context.axe_context
        ax = self.context.figure_context.ax
        for _ in self._ax_idx_set:
            if ax_context.grid:
                ax[_].grid()
            x_tick_range = ax_context.x_tick_range[::ax_context.x_tick_interval]
            x_tick_label = ax_context.x_tick_label[::ax_context.x_tick_interval]
            ax[_].set_xticks(
                x_tick_range if len(x_tick_range) != 0 else None,
                x_tick_label if len(x_tick_label) != 0 else None, rotation=45
            )
            y_tick_range = ax_context.y_tick_range[::ax_context.y_tick_interval]
            y_tick_label = ax_context.y_tick_label[::ax_context.y_tick_interval]
            ax[_].set_yticks(
                y_tick_range if len(y_tick_range) != 0 else None,
                y_tick_label if len(y_tick_label) != 0 else None
            )
            ax[_].set_xlim(*ax_context.x_lim)
            ax[_].set_ylim(*ax_context.y_lim)

    def _set_ax(self, msg: Plot2dMsg):
        ax = self.context.figure_context.ax
        ax[msg.ax_idx].legend(loc=msg.legend_loc)
        ax[msg.ax_idx].set_title(msg.ax_title, fontsize=msg.axe_title_fontsize)

    def process(self, msg: Plot2dMsg = None):
        if msg is None:
            self._collect_x_info()
            self._global_setting_()
        elif msg.legend_loc and msg.ax_title:
            self._set_ax(msg)
        else:
            self._ax_idx_set.add(msg.ax_idx)
            self._collect_x_info(msg.x)
