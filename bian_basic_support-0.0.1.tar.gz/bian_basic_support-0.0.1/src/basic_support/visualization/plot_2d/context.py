# -*- encoding: utf-8 -*-
"""
@File    : context.py
@Time    : 2022/10/9 13:58
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from pydantic.dataclasses import dataclass

from pydantic import validator

from basic_support.visualization.context_base import ContextBase


@dataclass
class FigureContext(ContextBase):
    figure = None
    ax = None
    n_rows: int = None
    n_cols: int = None
    size: tuple = None
    sup_title: str = None
    sup_title_fontsize: int = None


@dataclass
class AxeContext(ContextBase):
    # ax_group_id: tuple = None
    x_tick_range: list = None
    x_tick_label: list = None
    x_lim: tuple = None
    x_tick_interval: int = None
    grid: bool = False
    y_tick_range: list = None
    y_tick_label: list = None
    y_tick_interval: int = None
    sub_y_tick_range: list = None
    sub_y_tick_label: list = None
    y_lim: tuple = None
    sub_y_lim: tuple = None

    def __post_init_post_parse__(self):
        self.x_tick_label_map = dict(zip(self.x_tick_label, self.x_tick_range))

    @validator(
        'x_tick_range', 'x_tick_label', 'y_tick_range', 'y_tick_label', 'sub_y_tick_range', 'sub_y_tick_label',
        'x_lim', 'y_lim', 'sub_y_lim'
    )
    def set_optional_list(cls, v):
        return [] if v is None else v


@dataclass
class Plot2dContext(ContextBase):
    figure_context: FigureContext
    # axe_context: List[AxeContext]
    axe_context: AxeContext
