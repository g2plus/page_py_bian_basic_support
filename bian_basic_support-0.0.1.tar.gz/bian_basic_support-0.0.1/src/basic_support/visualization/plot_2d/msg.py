# -*- encoding: utf-8 -*-
"""
@File    : msg.py
@Time    : 2022/10/9 13:57
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from enum import Enum
from typing import Union

from pydantic.dataclasses import dataclass, Field

from basic_support.visualization.msg_base import MsgBase


class PlotMethodType(Enum):
    line = 'plot'
    bar = 'bar'


@dataclass
class Plot2dMsg(MsgBase):
    ax_idx: tuple = None
    x: list = None
    y: Union[list, float] = None
    plot_method: PlotMethodType = None
    plot_method_arg: tuple = ()
    plot_method_kwarg: dict = Field(default_factory=dict)
    twinx: bool = False
    legend_loc: str = None
    ax_title: str = None
    axe_title_fontsize: int = None
