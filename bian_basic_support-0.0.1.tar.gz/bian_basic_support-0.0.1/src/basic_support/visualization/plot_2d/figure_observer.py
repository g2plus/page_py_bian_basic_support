# -*- encoding: utf-8 -*-
"""
@File    : figure_observer.py
@Time    : 2022/10/9 14:18
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from typing import Optional

from matplotlib import pyplot as plt

from basic_support.visualization.abs_observer import AbsObserver
from basic_support.visualization.plot_2d.context import Plot2dContext
from basic_support.visualization.plot_2d.msg import Plot2dMsg

plt.rcParams["font.sans-serif"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False


class FigureObserver(AbsObserver[Plot2dMsg, Plot2dContext]):
    def __init__(self, name: str, context: Optional[Plot2dContext] = None):
        super().__init__(name, context)

    def _create_figure(self):
        figure_conf = self.context.figure_context
        figure_conf.figure, figure_conf.ax = plt.subplots(
            *(figure_conf.n_rows, figure_conf.n_cols), figsize=figure_conf.size
        )
        figure_conf.figure.suptitle(figure_conf.sup_title, fontsize=figure_conf.sup_title_fontsize)

    def process(self, msg: Plot2dMsg = None):
        if msg is None:
            assert self.context is not None
            assert self.context.figure_context is not None
            self._create_figure()
        else:
            ...
