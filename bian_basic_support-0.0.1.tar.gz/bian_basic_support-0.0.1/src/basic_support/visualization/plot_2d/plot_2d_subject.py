# -*- encoding: utf-8 -*-
"""
@File    : plot_2d_subject.py
@Time    : 2022/10/9 14:15
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from typing import List, Optional

from basic_support.visualization.abs_observer import AbsObserver
from basic_support.visualization.abs_subject import AbsSubject
from basic_support.visualization.plot_2d.artist_observer import ArtistObserver
from basic_support.visualization.plot_2d.axe_observer import AxeObserver
from basic_support.visualization.plot_2d.context import Plot2dContext
from basic_support.visualization.plot_2d.figure_observer import FigureObserver
from basic_support.visualization.plot_2d.msg import Plot2dMsg


class Plot2dSubject(AbsSubject[Plot2dMsg, Plot2dContext]):
    def __init__(self, name: str, context: Optional[Plot2dContext] = None, observers: List[AbsObserver] = None):
        super().__init__(name, context, observers)

    @property
    def figure_observer(self) -> FigureObserver:
        _, = self.find_observers(observer_cls=FigureObserver)
        return _

    @property
    def axe_observers(self) -> List[AxeObserver]:
        return self.find_observers(observer_cls=AxeObserver)

    @property
    def artist_observers(self) -> List[ArtistObserver]:
        return self.find_observers(observer_cls=ArtistObserver)

    def sort_observers(self):
        (figure_observer_idx, figure_observer), = filter(
            lambda x: isinstance(x[1], FigureObserver), enumerate(self.observers)
        )
        (axe_observer_idx, axe_observer), = filter(lambda x: isinstance(x[1], AxeObserver), enumerate(self.observers))
        self.observers.pop(figure_observer_idx)
        self.observers.pop(axe_observer_idx)
        self.observers.insert(0, figure_observer)
        self.observers.insert(1, axe_observer)
        return self

    def notify(self, msg: Plot2dMsg = None):
        if msg is None:
            self.figure_observer.process(msg)
        for _ in self.axe_observers + self.artist_observers:
            _.process(msg)
