# -*- encoding: utf-8 -*-
"""
@File    : artist_observer.py
@Time    : 2022/10/9 14:18
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from typing import Optional, Dict, List
from collections import defaultdict
from operator import methodcaller

from basic_support.visualization.abs_observer import AbsObserver
from basic_support.visualization.plot_2d.context import Plot2dContext
from basic_support.visualization.plot_2d.msg import Plot2dMsg


class ArtistObserver(AbsObserver[Plot2dMsg, Plot2dContext]):
    def __init__(self, name: str, context: Optional[Plot2dContext] = None):
        super().__init__(name, context)
        self._param_dict: Dict[tuple, List[Plot2dMsg]] = defaultdict(list)

    def process(self, msg: Plot2dMsg = None):
        if msg is None:
            x_tick_label_map = self.context.axe_context.x_tick_label_map
            sub_y_lim = self.context.axe_context.sub_y_lim
            for ax_idx, param_set in self._param_dict.items():
                param_set = sorted(param_set, key=lambda x: x.twinx)
                for param in param_set:
                    ax = self.context.figure_context.ax[ax_idx]
                    param.x = [x_tick_label_map[_] for _ in param.x]
                    if param.twinx:
                        ax = ax.twinx()
                        ax.set_ylim(*sub_y_lim)
                    methodcaller(
                        param.plot_method.value, param.x, param.y, *param.plot_method_arg, **param.plot_method_kwarg
                    )(ax)
                    self.context.figure_context.ax[ax_idx] = ax
        else:
            if msg.x is not None:
                self._param_dict[msg.ax_idx].append(msg)
