# -*- encoding: utf-8 -*-
"""
@File    : context_base.py
@Time    : 2022/10/9 13:49
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from pydantic.dataclasses import dataclass


@dataclass
class ContextBase:
    ...
