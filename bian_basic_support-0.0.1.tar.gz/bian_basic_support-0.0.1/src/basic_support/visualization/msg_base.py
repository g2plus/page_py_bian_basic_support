# -*- encoding: utf-8 -*-
"""
@File    : msg_base.py
@Time    : 2022/10/9 11:00
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from pydantic.dataclasses import dataclass


@dataclass
class MsgBase:
    ...
