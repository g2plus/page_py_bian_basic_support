# -*- encoding: utf-8 -*-
"""
@File    : abs_observer.py
@Time    : 2022/10/9 11:00
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from abc import ABCMeta, abstractmethod
from typing import Optional, Generic, TypeVar

from basic_support.visualization.context_base import ContextBase
from basic_support.visualization.msg_base import MsgBase

Context = TypeVar('Context', ContextBase, ContextBase)
Msg = TypeVar('Msg', MsgBase, MsgBase)


class AbsObserver(Generic[Msg, Context], metaclass=ABCMeta):
    def __init__(self, name: str, context: Optional[Context] = None):
        self.name = name
        self.context = context

    @abstractmethod
    def process(self, msg: Msg = None):
        ...
