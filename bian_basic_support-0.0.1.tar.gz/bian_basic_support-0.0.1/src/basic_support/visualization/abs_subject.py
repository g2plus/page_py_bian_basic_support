# -*- encoding: utf-8 -*-
"""
@File    : abs_subject.py
@Time    : 2022/10/9 11:00
@Author  : chenfan
@Software: PyCharm
@Description: 
"""

from abc import ABCMeta, abstractmethod
from typing import List, Optional, TypeVar, Generic

from basic_support.visualization.abs_observer import AbsObserver
from basic_support.visualization.context_base import ContextBase
from basic_support.visualization.msg_base import MsgBase

Context = TypeVar('Context', ContextBase, ContextBase)
Msg = TypeVar('Msg', MsgBase, MsgBase)


class AbsSubject(Generic[Msg, Context], metaclass=ABCMeta):
    def __init__(self, name: str, context: Optional[Context] = None, observers: List[AbsObserver] = None):
        self.context = context
        self.observers = observers if observers is not None else []
        self.name = name

        self._set_observer_context()

    def _set_observer_context(self):
        for _ in self.observers:
            if _.context is None:
                _.context = self.context

    def add_observer(self, observer: AbsObserver):
        self.observers.append(observer)
        self._set_observer_context()
        return self

    def add_observers(self, observers: List[AbsObserver]):
        self.observers += observers
        self._set_observer_context()
        return self

    def remove_observer(self, name: str):
        self.observers = list(filter(lambda x: x.name != name, self.observers))
        return self

    def remove_observers(self, names: List[str]):
        self.observers = list(filter(lambda x: x.name not in names, self.observers))
        return self

    def pop_observer(self, name: str) -> AbsObserver:
        idx, _ = filter(lambda x: x[1].name == name, enumerate(self.observers))
        observer = self.observers.pop(idx)
        return observer

    def find_observers(self, name: str = None, observer_cls=None):
        ret = list(filter(lambda x: x.name == name, self.observers))
        if observer_cls is not None:
            ret += filter(lambda x: isinstance(x, observer_cls), self.observers)
        return ret

    @abstractmethod
    def notify(self, msg: Msg = None):
        ...
