#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: ordinary_node.py
@Description: 
@time: 2023/12/27 20:15
"""

import sys
import weakref
from collections import OrderedDict
from itertools import count
from typing import Any, Callable, Iterator, Dict

from basic_support.comm_classes.mixin_class import EasyEqMixin
from basic_support.comm_struct.tree.abs_tree_node import AbsTreeNode

sys.setrecursionlimit(1000000)


class OrdinaryNode(EasyEqMixin, AbsTreeNode):
    def __init__(self, id: Any, properties: Dict = None):
        super(OrdinaryNode, self).__init__(properties=properties)
        self.id = id
        self._parent = None
        self.children = OrderedDict()

    # property that manages the parent as a weak-reference
    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self, node):
        self._parent = weakref.ref(node) if node else node

    @property
    def level(self):
        """
        实时更新 节点的层次信息
        :return:
        """
        c = count(0)
        parent = self.parent
        while parent:
            parent = parent().parent
            next(c)
        return next(c)

    @property
    def is_leaf(self):
        """
        判断是否叶子节点
        """
        return len(self.children.keys()) == 0

    def add_child(self, child):
        """
        添加子节点
        :param child: 需要添加的子节点
        """
        self.children[child.id] = child
        child.parent = self

    def add_childs(self, childs: Iterator):
        """
        批量添加子节点
        :param childs: 子节点列表
        """
        for child in childs:
            self.add_child(child=child)

    def add_children(self, children: Iterator):
        """
        批量添加子节点
        :param children: 子节点列表
        """
        for child in children:
            self.add_child(child=child)

    def remove_child(self, child: 'OrdinaryNode'):
        """
        移除子节点
        :param child: 需要移除的子节点
        """
        if child.id in self.children:
            self.children.pop(child.id)
            child.parent = None

    def find_parent(self, limit: int = 3) -> 'OrdinaryNode':
        """
        查找祖先节点
        :param limit: 限制往上找几代的父节点
        :return: 祖先节点
        """
        c = count()
        node = self
        while node.parent and next(c) < limit:
            node = node.parent()
        return node

    def merge_node(self, other: 'OrdinaryNode', merge_func: Callable = None) -> 'OrdinaryNode':
        """
        将其他节点合并到当前节点
        :param other: 其他节点
        :param merge_func: 节点合并函数
        :return: 合并后的节点
        """
        if merge_func:
            merge_func(self, other)
        return self
