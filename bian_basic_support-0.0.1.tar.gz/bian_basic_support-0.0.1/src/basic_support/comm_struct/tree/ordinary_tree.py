#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: ordinary_tree.py
@Description: 
@time: 2023/12/27 20:16
"""
import copy
import queue
from abc import ABCMeta, ABC
from functools import partial
from operator import attrgetter
from typing import List, Tuple, Dict, Any, Callable, Set
from collections import defaultdict
from basic_support.comm_classes.utils_class import Stack
from basic_support.comm_struct.tree.impl.ordinary_node import OrdinaryNode
from basic_support.logger.logger_config import logger


class OrdinaryTree(ABC, metaclass=ABCMeta):
    def __init__(self, root: OrdinaryNode):
        """
        构建树
        :param root: 根节点
        """
        self.root = root

    def id_order(self, start_node: OrdinaryNode = None) -> List[OrdinaryNode]:
        """
        id顺序遍历
        @param start_node: 指定节点及子树遍历，默认从根节点开始遍历
        @return: 遍历结果列表
        """
        start_node = self.root if start_node is None else start_node
        return sorted(self.pre_order(start_node=start_node), key=lambda word: word.id)

    def level_order(self, start_node: OrdinaryNode = None, level_limit: int = None) -> List[OrdinaryNode]:
        """
        层次遍历
        @param start_node: 遍历开始的节点，默认从根节点开始遍历
        @param level_limit: 限制需要遍历几层，默认None表示不做限制
        @return: 遍历结果列表
        """
        start_node = self.root if start_node is None else start_node
        level_limit = level_limit + start_node.level if level_limit else 10000

        level_queue = queue.Queue()
        level_queue.put(start_node)

        level_order_lst = []
        while not level_queue.empty():
            node: OrdinaryNode = level_queue.get()
            level_order_lst.append(node)
            [level_queue.put(c_node) for c_node in list(node.children.values()) if c_node.level < level_limit]
        return level_order_lst

    def pre_order(self, start_node: OrdinaryNode = None) -> List[OrdinaryNode]:
        """
        先序遍历
        @param start_node: 遍历开始的节点，默认从根节点开始遍历
        @return: 遍历结果列表
        """
        start_node = self.root if start_node is None else start_node
        pre_order_lst = []
        pre_stack = Stack()
        pre_stack.push(start_node)
        while not pre_stack.empty():
            node: OrdinaryNode = pre_stack.pop()
            pre_order_lst.append(node)
            [pre_stack.push(c_node) for c_node in list(node.children.values())[::-1]]
        return pre_order_lst

    def add_child_by_id(self, parent_id: Any, new_node: OrdinaryNode):
        """
        添加子节点到指定id的父节点
        @param parent_id: 父节点id
        @param new_node: 新增子节点
        """
        all_nodes = self._all_nodes()
        if parent_id in all_nodes:
            all_nodes[parent_id].add_child(new_node)
        else:
            raise Exception(f'父节点{parent_id} 不存在，请确保父节点已存在')

    def find_node_by_id(self, node_id: Any) -> OrdinaryNode:
        """
        根据节点id找节点
        :param node_id: 节点id
        :return:
        """
        all_nodes = self._all_nodes()
        return all_nodes.get(node_id, None)

    def find_node_by_property(self, key: str, value: str) -> List[OrdinaryNode]:
        """
        根据节点属性找节点
        :param key: 属性名
        :param value: 属性值
        :return:
        """
        all_nodes = self._all_nodes()
        nodes: List[OrdinaryNode] = []

        for node in all_nodes.values():
            if hasattr(node, key) and getattr(node, key) == value:
                nodes.append(node)
                continue
            if key in node.properties and node.properties.get(key) == value:
                nodes.append(node)
                continue
        return nodes

    # TODO tag过滤+深度+移除子树+添加(合并)子树

    def _all_nodes(self) -> Dict:
        """
        获取所有节点信息，以{id: node, ... }字典形式返回
        """
        return {node.id: node for node in self.id_order()}

    def remove_node_by_id(self, node_id):
        """
        删除指定节点id的节点
        :param node_id: 节点id
        """
        all_nodes = self._all_nodes()
        if node_id in all_nodes:
            # 获取当前节点
            cur_node = all_nodes[node_id]
            if cur_node == self.root:
                # self.root = None
                raise Exception("root节点 不支持删除操作")
            else:
                # 获取父节点
                parent = cur_node.parent()
                # 子节点 添加到 父节点
                parent.add_childs(childs=cur_node.children.values())
                # 父节点 删除 当前子节点
                parent.remove_child(cur_node)

    def remove_children_by_id(self, node_id):
        """
        删除指定节点id和其子树
        :param node_id: 节点id
        """
        all_nodes = self._all_nodes()
        if node_id in all_nodes:
            # 获取当前节点
            cur_node = all_nodes[node_id]
            if cur_node == self.root:
                self.root = None
            else:
                # 获取父节点
                parent = cur_node.parent()
                # 父节点 删除 当前子节点
                parent.remove_child(cur_node)

    def merge_node_by_id(self, node_id, other_id, merge_func: Callable = None):
        """
        合并两个节点
        :param node_id: 源节点id
        :param other_id: 需要合并的节点id
        :param merge_func: 节点合并函数
        """
        all_nodes = self._all_nodes()
        if node_id in all_nodes and other_id in all_nodes:
            node, other = all_nodes[node_id], all_nodes[other_id]

            assert other.id in node.children or node.id in other.children, f"节点【{node}】和节点【{other}】为非相邻节点，无法合并"
            # 保证父节点在前，子节点在后
            node, other = (node, other) if other.id in node.children else (other, node)

            other_parent, other_children = other.parent, other.children
            node.remove_child(other)
            new_node = node.merge_node(other=other, merge_func=merge_func)

            new_node.add_childs(childs=other_children.values())

    def default_merge_nodes(self, node_set: Set[OrdinaryNode]):
        """
        默认节点合并策略
        :param node_set: 节点集合
        """
        level_order_ids = {node.id: idx for idx, node in enumerate(self.level_order())}
        nodes = sorted(list(node_set), key=lambda k: level_order_ids[k.id], reverse=True)
        for node in nodes[:-1]:
            if node.parent:
                self.merge_node_by_id(node_id=node.parent().id, other_id=node.id, merge_func=None)

    def merge_helper(self,
                     nodes_lst: List[Set],
                     merge_func: Callable[['OrdinaryTree', Set[OrdinaryNode], ], OrdinaryNode] = None):
        """
        合并节点操作助手
        :param nodes_lst: 节点id列表
        :param merge_func: 合并策略
        """
        # 按连通整合分组id
        group_node_ids: List[Set] = []
        for node_ids in nodes_lst:
            for idx, group_node_id in enumerate(group_node_ids):
                if set(node_ids) & group_node_id:
                    group_node_ids[idx] = (group_node_id | node_ids)
                    break
            else:
                group_node_ids.append(set(node_ids))

        all_nodes = self._all_nodes()
        merge_impl = partial(merge_func, self=self) if merge_func else self.default_merge_nodes
        for node_ids in group_node_ids:
            node_set = {all_nodes[id] for id in node_ids}
            if OrdinaryTree.check_connected_subtree(node_set):
                merge_impl(node_set)
            else:
                raise Exception('非连通子树不支持节点合并操作，请确保节点相互连通')

        # if merge_func:
        #     for ids in group_nodes:
        #         node_set = {all_nodes[id] for id in ids}
        #         if OrdinaryTree.check_connected_subtree(node_set):
        #             merge_func(self, node_set)
        #         else:
        #             raise Exception('非连通子树不支持节点合并操作，请确保节点相互连通')
        # else:
        #     for ids in group_nodes:
        #         node_set = {all_nodes[id] for id in ids}
        #         if OrdinaryTree.check_connected_subtree(node_set):
        #             self.default_merge_nodes(node_set=node_set)
        #         else:
        #             raise Exception('非连通子树不支持节点合并操作，请确保节点相互连通')

    def remove_helper(self, nodes: List):
        """
        删除节点操作助手
        :param nodes: 节点列表 或 节点id列表
        """
        for node in nodes:
            try:
                self.remove_node_by_id(node_id=node)
            except Exception as e:
                raise e

    @staticmethod
    def check_connected_subtree(nodes: List[OrdinaryNode] or Set[OrdinaryNode]) -> bool:
        """
        连通子树验证
        :param nodes: 节点列表 或 节点集合
        """
        if len(nodes) == 1:
            return True
        nodes = sorted(list(nodes), key=attrgetter('level'))
        root_node, parents_set = nodes[0], []
        for node in nodes[1:]:
            parent = node.parent
            parent_set = set()
            while parent:
                parent_set.add(parent())
                if parent().id == root_node.id:
                    break
                parent = parent.parent
            parents_set.append(parent_set)

        return all([root_node in p_set for p_set in parents_set])

    def _find_start_node(self, node_parent_tuple: List[Tuple[OrdinaryNode, Any]]):
        """
        查找根节点的id
        :param node_parent_tuple:
        :return:
        """
        enter_counter = defaultdict(int)
        id_to_idxs = dict()
        start_ids = set(p_id for (node, p_id) in node_parent_tuple)
        end_ids = set(node.id for (node, p_id) in node_parent_tuple)

        start_id = start_ids - end_ids
        if len(start_id) != 1:
            logger.warning(f"查找树起始节点失败, records为: {node_parent_tuple}")
            return None
        return start_id.pop()

    def print_tree_info(self, start_node: OrdinaryNode = None):
        """
        打印树的结构信息
        :param start_node:
        :return:
        """
        for node in self.pre_order(start_node):
            print(f"{'----' * node.level}  {node}")

    @classmethod
    def build_from_nodes(cls, node_parent_tuple: List[Tuple[OrdinaryNode, Any]]):
        """
        从节点列表构建树
        @param node_parent_tuple: 节点列表
        @return: OrdinaryTree树实例
        """
        # 构建树的根节点
        # nodes = sorted(node_parent_tuple, key=lambda word: word[1])
        # if len(nodes) == 0:
        #     return None
        # root_node = nodes.pop(0)[0]

        nodes = copy.deepcopy(node_parent_tuple)
        start_id = cls._find_start_node(cls, node_parent_tuple=node_parent_tuple)
        if start_id is None:
            return None
        for idx, (node, p_id) in enumerate(node_parent_tuple):
            if p_id == start_id:
                break
        root_node = nodes.pop(idx)[0]

        # root_node.level = 0
        root_tree = cls(root_node)
        dependency_queue = queue.Queue()
        dependency_queue.put(root_tree.root)

        # 构建树的剩余部分
        while not dependency_queue.empty():
            dp_node: OrdinaryNode = dependency_queue.get()
            idxs = []
            for idx, node in enumerate(nodes):
                if node[1] == dp_node.id:
                    # node[0].level = dp_node.level + 1
                    dp_node.add_child(node[0])
                    dependency_queue.put(node[0])
                    idxs.append(idx)
            [nodes.remove(nodes[r]) for r in idxs[::-1]]
        if len(node_parent_tuple) != len(root_tree.pre_order()):
            return None
        return root_tree

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return repr(self.root)
