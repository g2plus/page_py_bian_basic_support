#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_tree_node.py
@Description: 树节点抽象类
@time: 2023/12/27 20:13
"""
from collections import defaultdict
from typing import Dict


class AbsTreeNode:

    def __init__(self, properties: Dict = None):
        """
        抽象树节点
        :param properties: 属性
        """
        # self.children = defaultdict(lambda: eval("{}()".format(self.__class__.__name__)))
        self.children = defaultdict(lambda: self.__class__())
        self.properties = properties or dict()

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return str({"properties": self.properties})
