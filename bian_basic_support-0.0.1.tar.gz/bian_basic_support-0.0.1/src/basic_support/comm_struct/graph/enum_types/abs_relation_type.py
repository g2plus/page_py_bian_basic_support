#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_relation_type.py
@Description: 
@time: 2024/9/27 11:24
"""
from enum import Enum


class AbsRelationType(Enum):

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return self.value
