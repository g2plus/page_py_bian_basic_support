#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_node_type.py
@Description: 
@time: 2024/9/27 11:25
"""
from enum import Enum


class AbsNodeType(Enum):

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return self.value
