#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_operator.py
@Description: 
@time: 2024/9/27 13:23
"""
from basic_support.comm_struct.graph.abs_node import AbsNode
from basic_support.comm_struct.graph.abs_relation import AbsRelation


class AbsOperator:
    def __init__(self):
        pass

    def __call__(self, start_node: AbsNode, start_relation: AbsRelation, graph: AbsNode):
        pass
