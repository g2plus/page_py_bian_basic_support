#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: universal_relation.py
@Description: 通用关系
@time: 2024/9/27 11:22
"""
from typing import Dict

from basic_support.comm_struct.graph.abs_node import AbsNode
from basic_support.comm_struct.graph.abs_relation import AbsRelation
from basic_support.comm_struct.graph.enum_types.abs_relation_type import AbsRelationType


class UniversalDirectedRelation(AbsRelation):
    def __init__(self, start_node: AbsNode, end_node: AbsNode, relation_type: AbsRelationType, properties: Dict = None):
        """

        :param start_node:
        :param end_node:
        :param properties:
        """
        super(UniversalDirectedRelation, self).__init__(start_node=start_node, end_node=end_node,
                                                        relation_type=relation_type, properties=properties, )

    def _post_init(self):
        self.start_node.add_out_neighbor_relations(self)
        self.end_node.add_in_neighbor_relations(self)


class UniversalUndirectedRelation(AbsRelation):
    def __init__(self, start_node: AbsNode, end_node: AbsNode, relation_type: AbsRelationType, properties: Dict = None):
        """

        :param start_node:
        :param end_node:
        :param properties:
        """
        super(UniversalUndirectedRelation, self).__init__(start_node=start_node, end_node=end_node,
                                                          relation_type=relation_type, properties=properties, )

    def _post_init(self):
        self.start_node.add_in_neighbor_relations(self)
        self.start_node.add_out_neighbor_relations(self)

        self.end_node.add_in_neighbor_relations(self)
        self.end_node.add_out_neighbor_relations(self)
