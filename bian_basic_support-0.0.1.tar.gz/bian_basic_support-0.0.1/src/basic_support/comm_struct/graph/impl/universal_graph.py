#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: universal_graph.py
@Description: 
@time: 2024/9/27 11:32
"""
from collections import OrderedDict
from typing import Dict, List, Callable, Iterable, Set, Type

from basic_support.comm_classes.utils_class import Queue
from basic_support.comm_struct.graph.abs_node import AbsNode
from basic_support.comm_struct.graph.abs_relation import AbsRelation
from basic_support.logger.logger_config import logger


class UniversalGraph(AbsNode):
    def __init__(self, relation_cls: Type[AbsRelation], content: str = None, properties: Dict = None):
        super(UniversalGraph, self).__init__(n_id=None, node_type=None, content=content, properties=properties)
        self.relation_cls = relation_cls

        self.children_nodes = OrderedDict()
        self.children_relations: List[AbsRelation] = []

    def add_children_node(self, node):
        self.children_nodes[node.n_id] = node

    def add_children_relation(self, relation):
        self.children_relations.append(relation)

    def traverse_bfs_and_op(self, start_node, relation_types: Set[AbsRelation] = None,
                            operator: Callable = None) -> Iterable[AbsNode]:
        yield from self._traverse_and_op(traverse_func=self._traverse_bfs, start_node=start_node,
                                         relation_types=relation_types, operator=operator)

    def _traverse_bfs(self, start_node, relation_types: Set[AbsRelation]) -> Iterable[AbsNode]:
        """
        图广度优先遍历
        :param start_node: 开始节点
        :param relation_types: 关系类型集合
        :return:
        """
        visited = set()
        queue = Queue()

        if start_node.in_neighbor_relations:
            for relation in start_node.in_neighbor_relations:
                if relation.relation_type in relation_types:
                    queue.push((relation.start_node, relation, start_node))
                    break
            else:
                queue.push((None, None, start_node))
        else:
            queue.push((None, None, start_node))

        while not queue.empty():
            start_node, start_relation, node = queue.pop()
            yield start_node, start_relation, node

            if node.n_id not in visited:
                visited.add(node.n_id)

                for relation in node.out_neighbor_relations:
                    end_node = relation.end_node
                    if not relation_types and end_node.n_id not in visited:
                        queue.push((node, relation, end_node))
                    elif relation.relation_type in relation_types and end_node.n_id not in visited:
                        queue.push((node, relation, end_node))

    def _traverse_and_op(self, traverse_func, start_node, relation_types: Set[AbsRelation] = None,
                         operator: Callable = None) -> Iterable[AbsNode]:
        operator = operator if operator else lambda k: k
        relation_types = relation_types if relation_types else set()
        # for _start_node, _start_relation, node in traverse_func(start_node, relation_types):
        for _start_node, _start_relation, node, _ in start_node.find_all_descendant(relation_types=relation_types):
            operator(_start_node, _start_relation, node)
            yield node

    @classmethod
    def build_graph_from_records(cls, nodes: List[Dict], relations: List[Dict], node_cls: Type[AbsNode],
                                 relation_cls: Type[AbsRelation]):
        graph = cls(relation_cls=relation_cls)

        for node in nodes:
            graph_node = node_cls.build_node_from_records(node=node)
            graph.add_children_node(node=graph_node)

        for relation in relations:
            start_node_id = str(relation['start_node_id'])
            end_node_id = str(relation['end_node_id'])
            relation_type = relation['relation_type']
            properties = relation['properties']

            start_node = graph.children_nodes[start_node_id]
            end_node = graph.children_nodes[end_node_id]

            graph_relation = relation_cls(start_node=start_node, end_node=end_node, relation_type=relation_type,
                                          properties=properties)
            graph.add_children_relation(graph_relation)

        return graph

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"{self.children_nodes}"
