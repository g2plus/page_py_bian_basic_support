#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: universal_tree.py
@Description: 
@time: 2024/9/27 15:37
"""

from typing import Dict, List, Callable, Iterable, Set, Type

from basic_support.comm_struct.graph.abs_node import AbsNode
from basic_support.comm_struct.graph.abs_relation import AbsRelation
from basic_support.comm_struct.graph.impl.universal_graph import UniversalGraph


class UniversalTree(UniversalGraph):
    def __init__(self, root: AbsNode or None, relation_cls: Type[AbsRelation], properties: Dict = None):
        super().__init__(relation_cls=relation_cls, properties=properties)
        self.root = root

    def traverse_pre_and_op(self, start_node, relation_types: Set[AbsRelation] = None,
                            operator: Callable = None) -> Iterable[AbsNode]:
        yield from self._traverse_and_op(traverse_func=self._traverse_pre_order, start_node=start_node,
                                         relation_types=relation_types, operator=operator)

    def _traverse_pre_order(self, start_node, relation_types: Set[AbsRelation]) -> Iterable[AbsNode]:
        """
        树先序遍历
        :param start_node: 开始节点
        :param relation_types: 关系类型集合
        :return:
        """
        pass

    @classmethod
    def build_tree_from_records(cls, root_id: str, nodes: List[Dict], relations: List[Dict],
                                relation_cls: Type[AbsRelation]):
        tree = cls(relation_cls=relation_cls, root=None)
        for node in nodes:
            tree_node = AbsNode.build_node_from_records(node=node)
            if tree_node.n_id == root_id:
                tree.root = tree_node
            tree.add_children_node(node=tree_node)

        for relation in relations:
            tree_relation = relation_cls(*relation)
            tree.add_children_relation(tree_relation)

        return tree
