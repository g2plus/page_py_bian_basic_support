#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_node.py
@Description: 
@time: 2024/9/27 10:59
"""

from typing import Dict, List, Set, Callable, Any

from basic_support.comm_classes.utils_class import Queue
from basic_support.comm_funcs.comm_utils import gen_uuid32
from basic_support.comm_struct.graph.enum_types.abs_node_type import AbsNodeType
from basic_support.comm_struct.graph.enum_types.abs_relation_type import AbsRelationType


class AbsNode:
    def __init__(self, n_id: str or None, content: str, node_type: AbsNodeType or None, properties: Dict = None):
        """
        抽象树节点
        :param n_id:
        :param node_type:
        :param properties:
        """
        self.n_id = n_id or gen_uuid32()
        self.node_type = node_type
        self.content = content

        self.properties = properties or dict()

        # 邻居节点
        self._in_neighbor_relations: List = []
        self._out_neighbor_relations: List = []

    def add_in_neighbor_relations(self, relation):
        self._in_neighbor_relations.append(relation)

    def add_out_neighbor_relations(self, relation):
        self._out_neighbor_relations.append(relation)

    @property
    def in_neighbor_relations(self):
        return self._in_neighbor_relations

    @property
    def out_neighbor_relations(self):
        return self._out_neighbor_relations

    @classmethod
    def build_node_from_records(cls, node: Dict):
        obj = cls(**node)
        return obj

    def find_all_ancestors(self, relation_types: Set[AbsRelationType] = None, max_depth: int = None,
                           filter_op: Callable[[Any, Any], bool] = None):
        """
        层次遍历所有祖先(倒序)
        :param relation_types: 关系约束
        :param max_depth: 最大深度
        :return:
        """
        relation_types = None if relation_types and len(relation_types) == 0 else relation_types
        visited = set()
        queue = Queue()
        filter_op = filter_op if filter_op else lambda *args, **kwargs: True

        queue.push((None, None, self, 0))

        while not queue.empty():
            start_node, start_relation, node, level = queue.pop()
            yield start_node, start_relation, node, level

            if node.n_id not in visited:
                visited.add(node.n_id)

                if max_depth is None or level + 1 < max_depth:
                    for relation in node.in_neighbor_relations:
                        end_node = relation.end_node

                        if not filter_op(node, relation):
                            continue

                        if relation_types is None:
                            if end_node.n_id not in visited:
                                queue.push((node, relation, end_node, level + 1))
                        else:
                            if relation.relation_type in relation_types and end_node.n_id not in visited:
                                queue.push((node, relation, end_node, level + 1))

    def find_all_descendant(self, relation_types: Set[AbsRelationType] = None, max_depth: int = None,
                            filter_op: Callable[[Any, Any], bool] = None):
        """
        层次遍历所有子孙
        :param relation_types: 关系约束
        :param max_depth: 最大深度
        :param filter_op: 过滤条件定制
        :return:
        """
        relation_types = None if relation_types and len(relation_types) == 0 else relation_types
        visited = set()
        queue = Queue()
        filter_op = filter_op if filter_op else lambda *args, **kwargs: True

        if self.in_neighbor_relations:
            for relation in self.in_neighbor_relations:
                if relation_types is None or relation.relation_type in relation_types:
                    queue.push((relation.start_node, relation, self, 0))
                    break
            else:
                queue.push((None, None, self, 0))
        else:
            queue.push((None, None, self, 0))

        while not queue.empty():
            start_node, start_relation, node, level = queue.pop()
            yield start_node, start_relation, node, level

            if node.n_id not in visited:
                visited.add(node.n_id)

                if max_depth is None or level + 1 < max_depth:
                    for relation in node.out_neighbor_relations:
                        end_node = relation.end_node

                        if not filter_op(node, relation):
                            continue

                        if relation_types is None:
                            if end_node.n_id not in visited:
                                queue.push((node, relation, end_node, level + 1))
                        else:
                            if relation.relation_type in relation_types and end_node.n_id not in visited:
                                queue.push((node, relation, end_node, level + 1))

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"[{self.n_id}] {self.node_type}: {self.content}"
