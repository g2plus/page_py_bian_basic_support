#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_ref.py
@Description: 
@time: 2024/9/27 11:03
"""
from typing import Dict

from basic_support.comm_struct.graph.abs_node import AbsNode
from basic_support.comm_struct.graph.enum_types.abs_relation_type import AbsRelationType


class AbsRelation:
    def __init__(self, start_node: AbsNode, end_node: AbsNode, relation_type: AbsRelationType, properties: Dict = None):
        """

        :param start_node:
        :param end_node:
        :param properties:
        """
        self.start_node = start_node
        self.end_node = end_node
        self.relation_type = relation_type
        self.properties = properties or dict()

        self._post_init()

    def _post_init(self):
        pass

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"[{self.relation_type}] {self.start_node}: {self.end_node}"
