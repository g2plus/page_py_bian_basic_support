# @Time    : 2020/5/8 16:22
# @Author  : YuQL
# @FileName: MultiLabelsStratifiedSampling.py
# @Software: PyCharm

import sys
import numpy as np
from basic_support.sampling.multi_label_sample_item import MultiLabelSampleItem
from basic_support.sampling.weight_random_sampling import WeightRandomSampling
from basic_support.comm_funcs.comm_utils import shuffle_to_head_sub_lst
from basic_support.logger.logger_config import logger



from typing import Dict, List, Tuple
import collections
import time


class MultiLabelsStratifiedSampling(object):
    """
    多标签(无放回)分层抽样器
    """

    def __init__(
            self,
            sample_num_per_loop=20,
            max_sample_rate_per_loop=0.005,
            tmp_sampling_num=2000
    ):
        """

        :param sample_num_per_loop: 每次循环抽样的数量（越大会越快越不精确,不能太大）
        :param max_sample_rate_per_loop: 每次循环抽样的数量占剩余样本数量的最大比例限制
        :param tmp_sampling_num: 抽样时用于抽样的临时列表的大小
                                （因为分层抽样性能跟列表长度相关，
                                所以先随机抽出一个控制长度的临时列表用于分层抽样，避免数据量过大时的性能问题）
        """
        self.sample_set_weight_dict: Dict[str, float] = dict()
        self.sample_num_per_loop = sample_num_per_loop
        self.max_sample_rate_per_loop = max_sample_rate_per_loop
        self.tmp_sampling_num = tmp_sampling_num

    def add_sample_set(self, tag: str, weight: float):
        assert weight > 0, "weight必须大于零!"
        self.sample_set_weight_dict[tag] = weight
        return self

    @staticmethod
    def _stat_overall_label_count(all_sample_lst: List[MultiLabelSampleItem]) -> Dict[str, int]:
        overall_label_count_dict = collections.defaultdict(int)
        for sample_item in all_sample_lst:
            for label, count in sample_item.label_count_dict.items():
                overall_label_count_dict[label] += count
        return dict(overall_label_count_dict)

    @staticmethod
    def _calc_sample_set_need_label_counts(
            sample_set_weight_items: List[Tuple[str, float]],
            overall_label_count_dict: Dict[str, int]
    ) -> Dict[str, Dict[str, int]]:
        sample_set_need_label_counts = dict()
        added_label_count = collections.defaultdict(int)
        for tag, weight in sample_set_weight_items[:-1]:
            need_label_count_dict = dict()
            for label, count in overall_label_count_dict.items():
                need_count = round(count * weight)
                need_label_count_dict[label] = need_count
                added_label_count[label] += need_count
            sample_set_need_label_counts[tag] = need_label_count_dict
        last_tag, _ = sample_set_weight_items[-1]
        need_label_count_dict = dict()
        for label, count in overall_label_count_dict.items():
            need_label_count_dict[label] = max(0, count - added_label_count[label])
        sample_set_need_label_counts[last_tag] = need_label_count_dict
        return sample_set_need_label_counts

    def sample(
        self, 
        all_sample_lst: List[MultiLabelSampleItem],
        total_sample_num:int=-1
    ) -> Dict[str, List[MultiLabelSampleItem]]:
        rst_dict = collections.defaultdict(list)
        total_weight = sum(self.sample_set_weight_dict.values())
        sample_set_weight_items = [(tag, weight / total_weight) for tag, weight in self.sample_set_weight_dict.items()]
        weight_sampling = WeightRandomSampling(sample_set_weight_items)
        overall_label_count_dict = MultiLabelsStratifiedSampling._stat_overall_label_count(all_sample_lst)
        sample_set_need_label_counts = MultiLabelsStratifiedSampling._calc_sample_set_need_label_counts(
            sample_set_weight_items,
            overall_label_count_dict
        )
        last_sample_lst = all_sample_lst.copy()
        last_time = time.time()
        cur_total = 0
        while len(last_sample_lst) > 0:
            if total_sample_num > 0 and cur_total >= total_sample_num:
                break
            _, sample_set_code = weight_sampling()
            sample_set_need_labels = sample_set_need_label_counts[sample_set_code]
            min_cou = min(sample_set_need_labels.values())
            relative_label_count = {label: cou - min_cou + 1 for label, cou in sample_set_need_labels.items()}

            # random.shuffle(last_sample_lst)
            shuffle_to_head_sub_lst(last_sample_lst, self.tmp_sampling_num)

            sample_weight_lst = [
                (
                    idx,
                    sum([
                        np.power(relative_label_count.get(label) * cou, 2)
                        if label in relative_label_count else 0  # -cou / len(sample_item.label_count_dict)
                        for label, cou in sample_item.label_count_dict.items()
                    ]) + 1
                )
                for idx, sample_item in enumerate(last_sample_lst[:self.tmp_sampling_num])
            ]
            sample_num = max(
                1,
                min(
                    int(len(sample_weight_lst) * self.max_sample_rate_per_loop),
                    self.sample_num_per_loop
                )
            )
            
            for _ in range(sample_num):
                _, sample_idx = WeightRandomSampling(sample_weight_lst)()
                sample_item = last_sample_lst[sample_idx]
                rst_dict[sample_set_code].append(sample_item)
                cur_total += 1
                if total_sample_num > 0 and cur_total >= total_sample_num:
                    break
                for label, cou in sample_item.label_count_dict.items():
                    if label in sample_set_need_labels:
                        sample_set_need_labels[label] = sample_set_need_labels[label] - cou
                last_sample_lst.remove(sample_item)
                sample_weight_lst.pop(len(sample_weight_lst) - 1)

                last_num = len(last_sample_lst)
                if last_num == 0:
                    break
                if last_num % 5000 == 0:
                    cur_time = time.time()
                    logger.info("剩余待抽样数量:{}, 该batch耗时:{}".format(str(last_num), str(cur_time - last_time)))
                    last_time = time.time()
        return dict(rst_dict)


if __name__ == "__main__":
    import random
    import time

    labels = ['a', 'b', 'c', 'd']
    samples = [
        MultiLabelSampleItem(
            None,
            {
                lb: c + 2 if lb == 'a' else c
                for lb, c in
                {
                    lb: random.randint(0, 5)
                    for lb in labels
                }.items()
                if c > 3
            }
        )
        for _ in range(10000)
    ]
    for sample_item in samples:
        sample_item.raw_sample_item = sample_item.label_count_dict

    sampling = MultiLabelsStratifiedSampling().add_sample_set(
        "train",
        7
    ).add_sample_set(
        "dev",
        1.5
    ).add_sample_set(
        "test",
        1.5
    )
    print("开始抽样")
    bg_time = time.time()
    sample_rst = sampling.sample(samples)
    end_time = time.time()
    print("抽样耗时:{}".format(str(end_time - bg_time)))
    print({tag: len(item_lst) for tag, item_lst in sample_rst.items()})


    def stat_label_rate(sample_item_lst: List[MultiLabelSampleItem]) -> Dict[str, float]:
        total = 0
        label_rate_dict = collections.defaultdict(float)
        for sample_item in sample_item_lst:
            for lb, cou in sample_item.label_count_dict.items():
                label_rate_dict[lb] += cou
                total += cou
        for lb in label_rate_dict:
            label_rate_dict[lb] = label_rate_dict[lb] / total
        label_rate_lst = [(lb, rate) for lb, rate in label_rate_dict.items()]
        label_rate_lst.sort(key=lambda item: item[0])
        return label_rate_lst


    label_rate_stat_dict = {
        lb: stat_label_rate(sample_item_lst)
        for lb, sample_item_lst in sample_rst.items()
    }
    print(label_rate_stat_dict)
