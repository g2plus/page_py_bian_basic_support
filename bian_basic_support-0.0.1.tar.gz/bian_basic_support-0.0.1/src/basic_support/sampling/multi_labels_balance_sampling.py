# @Time    : 2020/8/19 17:31
# @Author  : YuQL
# @FileName: multi_labels_balance_sampling.py
# @Software: PyCharm

from typing import Generator, Dict, List, Tuple, Callable, Generic, TypeVar
from collections import defaultdict
import math
from basic_support.sampling.multi_label_sample_item import MultiLabelSampleItem
from basic_support.sampling.weight_random_sampling import WeightRandomSampling
from basic_support.comm_funcs.comm_utils import shuffle_to_head_sub_lst

RawDataItem = TypeVar("RawDataItem", )


class MultiLabelsBalanceSampling(Generic[RawDataItem]):

    def __init__(self,
                 result_num: int,
                 sample_enhance_func: Callable[[RawDataItem], RawDataItem],
                 sample_num_per_loop: int = 6,
                 tmp_sampling_num: int = 1500,

                 ):
        """
        多标签样本的均衡抽样（过多的欠采样，不足的过采样）
        :param result_num: 结果总数
        :param sample_enhance_func: 样本增强函数，通过给定一个样本，生成新样本
        :param sample_num_per_loop: 每次循环抽样的数量（越大会越快越不精确,不能太大）
        :param tmp_sampling_num:抽样时用于抽样的临时列表的大小
                                （因为抽样性能跟列表长度相关，
                                所以先随机抽出一个控制长度的临时列表用于抽样，避免数据量过大时的性能问题）
        """
        self.result_num = result_num
        self.sample_num_per_loop = sample_num_per_loop
        self.tmp_sampling_num = tmp_sampling_num
        self.sample_enhance_func = sample_enhance_func

    @staticmethod
    def stat_label_count(all_samples: Generator[MultiLabelSampleItem, None, None]) -> Tuple[Dict[str, int], int]:
        raw_label_count_dict = defaultdict(int)
        all_label_num = 0
        for sample_item in all_samples:
            all_label_num += 1
            for label, count in sample_item.label_count_dict.items():
                raw_label_count_dict[label] += count
        return raw_label_count_dict, all_label_num

    @staticmethod
    def cal_part_factor(
            overall_label_count: Dict[str, int],
            part_label_count: Dict[str, int]
    ) -> Dict[str, float]:
        """
        通过比较分区数据计数字典与总体计数字典，计算分区数据对应的因子字典
        :param overall_label_count:
        :param part_label_count:
        :return:
        """
        overall_max_count = max(overall_label_count.values())
        overall_factor_dict = {
            lb: overall_max_count - cou + 1
            for lb, cou
            in overall_label_count.items()
        }
        part_count_rate = {
            lb: part_cou / overall_label_count[lb]
            for lb, part_cou
            in part_label_count.items()
        }
        part_factor_dict = {
            lb: overall_factor_dict[lb] * part_rate
            for lb, part_rate
            in part_count_rate.items()
        }
        sum_part_factor = sum(part_factor_dict.values())
        part_factor_dict = {
            lb: factor / sum_part_factor for lb, factor in part_factor_dict.items()
        }
        return part_factor_dict

    @staticmethod
    def _calc_factor_dict(label_count_dict: Dict[str, int]) -> Dict[str, float]:
        """
        通过标签计数字典计算对应的标签因子字典
        :param label_count_dict:
        :return:
        """
        max_count = max(label_count_dict.values())
        return {
            lb: max_count - cou + 1
            for lb, cou
            in label_count_dict.items()
        }

    def _make_no_deal_sample_ahead(self, sample_info_lst: List[Tuple[object, bool]]):
        head_size = min(self.tmp_sampling_num // 3, len(sample_info_lst))
        check_idx = 0
        find_idx = min(self.tmp_sampling_num, len(sample_info_lst))
        while check_idx < head_size:
            if sample_info_lst[check_idx][1]:
                has_found = False
                while find_idx < len(sample_info_lst):
                    if not sample_info_lst[find_idx][1]:
                        sample_info_lst[check_idx], sample_info_lst[find_idx] = sample_info_lst[find_idx], \
                                                                                sample_info_lst[check_idx]
                        find_idx += 1
                        has_found = True
                        break
                    find_idx += 1
                if not has_found:
                    return
            check_idx += 1

    def sample(self,
               raw_sample_lst: List[MultiLabelSampleItem],
               label_factor_dict: Dict[str, float] = None
               ) -> Generator[Tuple[RawDataItem, bool], None, None]:
        """
        进行抽样
        :param raw_sample_lst: 原始样本的列表
        :param label_factor_dict: 指定标签因子字典，若为None则内部会根据样本计算因子
        :return: 返回generator，元素为(样本，是否原始样本)格式的元组
        """
        label_count_dict, _ = self.stat_label_count((v for v in raw_sample_lst))
        factor_dict = label_factor_dict if label_factor_dict is not None else self._calc_factor_dict(label_count_dict)
        sample_count = sum(label_count_dict.values())
        sample_rate = self.result_num / sample_count
        factor_dict = {k: v * sample_rate for k, v in factor_dict.items()}
        factor_sum = sum(factor_dict.values())
        factor_dict = {k: v / factor_sum for k, v in factor_dict.items()}
        real_count_dict = {k: 1 for k in factor_dict.keys()}
        result_count = 0
        sample_info_lst = [
            (sample_item, False)
            for sample_item
            in raw_sample_lst
        ]
        while result_count < self.result_num:
            shuffle_to_head_sub_lst(sample_info_lst, self.tmp_sampling_num)
            self._make_no_deal_sample_ahead(sample_info_lst)
            sum_real_count = sum(real_count_dict.values())
            real_rate_dict = {k: v / sum_real_count for k, v in real_count_dict.items()}
            diff_factor_dict = {
                lb: math.exp(5 * (factor - real_rate_dict[lb]))
                for lb, factor
                in factor_dict.items()
            }
            sample_weight_lst = [
                (
                    idx,
                    sum([diff_factor_dict[lb] * cou for lb, cou in sample_info[0].label_count_dict.items()])
                )
                for idx, sample_info in enumerate(sample_info_lst[:self.tmp_sampling_num])
            ]
            sample_num = min(self.sample_num_per_loop, self.result_num - result_count)
            for _ in range(sample_num):
                _, sample_idx = WeightRandomSampling(sample_weight_lst)()
                sample_item, has_deal = sample_info_lst[sample_idx]
                if not has_deal:
                    yield sample_item.raw_sample_item, True
                    sample_info_lst[sample_idx] = (sample_item, True)
                else:
                    yield self.sample_enhance_func(sample_item.raw_sample_item), False
                result_count += 1
                for lb, cou in sample_item.label_count_dict.items():
                    real_count_dict[lb] += cou


if __name__ == "__main__":
    import random
    import time


    def sample_enhance_func(raw_sample: object):
        print("增强样本:{}".format(str(raw_sample)))
        return raw_sample


    labels = ['a', 'b', 'c', 'd']
    samples = [
        MultiLabelSampleItem(
            None,
            {
                lb: c + 3 if lb == 'a' else c
                for lb, c in
                {
                    lb: random.randint(0, 6)
                    for lb in labels
                }.items()
                if c > 4
            }
        )
        for _ in range(3000)
    ]
    for idx, sample_item in enumerate(samples):
        sample_item.raw_sample_item = sample_item.label_count_dict

    raw_stat_dict = defaultdict(int)
    for sample_item in samples:
        for k, v in sample_item.raw_sample_item.items():
            raw_stat_dict[k] += v
    print("raw_stat_dict: {}".format(str(raw_stat_dict)))

    part_samples_lst = [samples[:1000], samples[1000: 2000], samples[2000: 3000]]

    overall_stat_dict = defaultdict(int)
    stat_dicts = []
    for part_samples in part_samples_lst:
        sampling = MultiLabelsBalanceSampling(
            result_num=1000,
            sample_enhance_func=sample_enhance_func
        )
        overall_label_count, _ = MultiLabelsBalanceSampling.stat_label_count((v for v in samples))
        part_label_count, _ = MultiLabelsBalanceSampling.stat_label_count((v for v in part_samples))
        part_label_factor_dict = MultiLabelsBalanceSampling.cal_part_factor(overall_label_count, part_label_count)
        g = sampling.sample(
            part_samples,
            label_factor_dict=part_label_factor_dict
        )
        rst = [v[0] for v in g]
        # print("rst:{}".format(str([str(v) for v in rst])))
        stat_dict = defaultdict(int)
        for v in rst:
            for k, val in v.items():
                stat_dict[k] += val
                overall_stat_dict[k] += val
        stat_dicts.append(stat_dict)

    sum_overall = sum(overall_stat_dict.values())
    sum_raw = sum(raw_stat_dict.values())
    overall_stat_rate_dict = {k: v / sum_overall for k, v in overall_stat_dict.items()}
    raw_stat_rate_dict = {k: v / sum_raw for k, v in raw_stat_dict.items()}
    print("overall_stat_dict: {}".format(str(overall_stat_dict)))
    print("stat_dicts: {}".format(str(stat_dicts)))
    print("raw_stat_dict: {}".format(str(raw_stat_dict)))
