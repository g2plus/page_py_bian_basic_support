

from dataclasses import dataclass
from typing import Dict, List

from src.basic_support.sampling.multi_label_sample_item import MultiLabelSampleItem


class FieldValuesCount:
    """字段的各个值的数量信息"""
    def __init__(self) -> None:
        self.value_count_dict:Dict[str,int] = dict()
    
    def set_count(self, value:str, count:int)->"FieldValuesCount":
        self.value_count_dict[value] = count
    
    def sub(self, value_cous:"FieldValuesCount"):
        if value_cous is None:
            return
        for v,cou in value_cous:
            if v in self.value_count_dict:
                self.value_count_dict = max(0, self.value_count_dict - cou)



class MultiFieldBalanceWithoutPeplaceSampling:
    """不放回多字段均衡抽样
    """
    def __init__(
        self,
        sample_num_per_loop=20,
        max_sample_rate_per_loop=0.005,
    ) -> None:
        """
        :param Dict[str,FieldValuesCount] fields_val_cous: 各个需要均衡的字段需要的数量信息
        :param int sample_num_per_loop: _description_, defaults to 20
        :param float max_sample_rate_per_loop: _description_, defaults to 0.005
        """
        pass
    
    def sample(
        self, 
        all_sample_lst: List[MultiLabelSampleItem],
        fields_val_cous:Dict[str,FieldValuesCount],
        total_sample_num:int
    ):
        pass








