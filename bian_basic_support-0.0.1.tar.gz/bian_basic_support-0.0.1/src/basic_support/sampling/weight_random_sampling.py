# @Time    : 2020/5/8 17:26
# @Author  : YuQL
# @FileName: WeightRandom.py
# @Software: PyCharm

import bisect
import random


class WeightRandomSampling:
    """
    带权（有放回）随机抽样
    """

    def __init__(self, items):
        weights = [w for _, w in items]
        self.goods = [x for x, _ in items]
        self.total = sum(weights)
        self.acc = list(WeightRandomSampling._accumulate(weights))

    @staticmethod
    def _accumulate(weights):
        cur = 0
        for w in weights:
            cur = cur + w
            yield cur

    def __call__(self):
        idx = bisect.bisect_right(self.acc, random.uniform(0, self.total), hi=len(self.acc) - 1)
        return idx, self.goods[idx]


if __name__ == "__main__":
    items = [('a', 0.1), ('b', 0.2), ('c', 0.3)]
    sampling = WeightRandomSampling(items)
    rsts = [sampling() for _ in range(100)]
    print(rsts)
