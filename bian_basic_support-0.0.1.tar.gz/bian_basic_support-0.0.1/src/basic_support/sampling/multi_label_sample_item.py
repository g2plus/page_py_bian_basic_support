# @Time    : 2020/5/10 17:25
# @Author  : YuQL
# @FileName: MultiLabelSampleItem.py
# @Software: PyCharm

from typing import Dict


class MultiLabelSampleItem:
    """
    多标签样本项
    """

    def __init__(self, raw_sample_item: object, label_count_dict: Dict[str, int]):
        """

        :param raw_sample_item: 原始样本对象
        :param label_count_dict: 记录 样本对象的各个标签的个数 的dict，key为label, value为对应的个数
        """
        self.raw_sample_item = raw_sample_item
        self.label_count_dict = label_count_dict

    def __hash__(self):
        return hash(
            (self.raw_sample_item, self.label_count_dict)
        )


