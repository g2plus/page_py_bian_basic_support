#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_sort.py
@Description: 排序抽象类
@time: 2023/1/30 14:46
"""

from abc import abstractmethod
from typing import List, Callable, Any


class AbsSort:
    def __init__(self, compare: Callable[[Any, Any], bool] = None, key_func: Callable = None):
        """
        @param compare: 比较器, a<b?
        """
        self._compare = compare or AbsSort.default_compare
        self._key_func = key_func or AbsSort.default_key_func

    @staticmethod
    def default_compare(item_a: Any, item_b: Any) -> bool:
        return item_a <= item_b

    def set_compare(self, compare: Callable[[Any, Any], bool]):
        """
        设置比较器 a<b?
        @param compare: 比较器
        """
        self._compare = compare

    def compare(self, item_a: Any, item_b: Any, descending: bool = False) -> bool:
        return descending ^ self._compare(item_a=self._key_func(item_a), item_b=self._key_func(item_b))

    @staticmethod
    def default_key_func(item: Any) -> Any:
        return item

    @abstractmethod
    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        """
        排序
        @param array: 需要排序的列表
        @param in_place: 是否本地排序
        @param descending: 是否降序
        """
        pass
