#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_comparing.py
@Description: 
@time: 2023/1/30 14:52
"""
from abc import abstractmethod
from typing import List

from basic_support.sort_algorithms.abs_sort import AbsSort


class AbsComparing(AbsSort):
    def __init__(self):
        super(AbsComparing, self).__init__()

    @abstractmethod
    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        """
        排序
        @param array: 需要排序的列表
        @param in_place: 是否本地排序
        @param descending: 是否降序
        """
        pass
