#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: merge_sort.py
@Description: 合并排序
@time: 2023/1/30 16:10
"""
import math
from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_comparing import AbsComparing


class MergeSort(AbsComparing):
    def __init__(self):
        super(MergeSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        assert not in_place, "不支持本地排序"
        arr = array if in_place else deepcopy(array)
        if len(arr) < 2:
            return arr
        middle = math.floor(len(arr) / 2)
        left, right = arr[0:middle], arr[middle:]
        return self.merge(self.sort(left, in_place, descending), self.sort(right, in_place, descending),
                          descending=descending)

    def merge(self, left, right, descending: bool = False):
        result = []
        while left and right:
            if self.compare(left[0], right[0], descending=descending):
                result.append(left.pop(0))
            else:
                result.append(right.pop(0))
        while left:
            result.append(left.pop(0))
        while right:
            result.append(right.pop(0))
        return result


if __name__ == '__main__':
    merge_sort = MergeSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = merge_sort.sort(array=array)
    print(array)
    print(res)

    res = merge_sort.sort(array=array, descending=True)
    print(array)
    print(res)
