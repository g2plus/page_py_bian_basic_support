#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: selection_sort.py
@Description: 选择排序
@time: 2023/1/30 14:55
"""
from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_comparing import AbsComparing


class SelectionSort(AbsComparing):
    def __init__(self):
        super(SelectionSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        arr = array if in_place else deepcopy(array)
        for i in range(len(arr) - 1):
            # 记录最小数的索引
            min_index = i
            for j in range(i + 1, len(arr)):
                if self.compare(arr[j], arr[min_index], descending=descending):
                    min_index = j
            # i不是最小数时, 将i和最小数进行交换
            if i ^ min_index:
                arr[i], arr[min_index] = arr[min_index], arr[i]
        return arr


if __name__ == '__main__':
    selection_sort = SelectionSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = selection_sort.sort(array=array)
    print(array)
    print(res)

    res = selection_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
