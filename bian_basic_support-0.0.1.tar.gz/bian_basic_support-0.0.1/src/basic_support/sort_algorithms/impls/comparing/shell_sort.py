#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: shell_sort.py
@Description: 希尔排序
@time: 2023/1/30 16:04
"""
import math
from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_comparing import AbsComparing


class ShellSort(AbsComparing):
    def __init__(self):
        super(ShellSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        arr = array if in_place else deepcopy(array)
        gap = 1
        increase = 3
        while gap < len(arr) / increase:
            gap = gap * increase + 1
        while gap > 0:
            for i in range(gap, len(arr)):
                current = arr[i]
                j = i - gap
                while j >= 0 and self.compare(current, arr[j], descending=descending):
                    arr[j + gap] = arr[j]
                    j -= gap
                arr[j + gap] = current
            gap = math.floor(gap / increase)
        return arr


if __name__ == '__main__':
    shell_sort = ShellSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = shell_sort.sort(array=array)
    print(array)
    print(res)

    res = shell_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
