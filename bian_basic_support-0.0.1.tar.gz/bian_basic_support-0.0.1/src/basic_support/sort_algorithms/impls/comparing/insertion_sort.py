#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: insertion_sort.py
@Description: 简单插入排序
@time: 2023/1/30 15:55
"""
from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_comparing import AbsComparing


class InsertionSort(AbsComparing):
    def __init__(self):
        super(InsertionSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        arr = array if in_place else deepcopy(array)
        for i in range(1, len(arr)):
            pre_index = i - 1
            current = arr[i]
            # 往前查找位置, 直到找到小于(降序时是大于)当前值的位置
            while pre_index >= 0 and self.compare(current, arr[pre_index], descending=descending):
                arr[pre_index + 1] = arr[pre_index]
                pre_index -= 1
            arr[pre_index + 1] = current
        return arr


if __name__ == '__main__':
    insertion_sort = InsertionSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = insertion_sort.sort(array=array)
    print(array)
    print(res)

    res = insertion_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
