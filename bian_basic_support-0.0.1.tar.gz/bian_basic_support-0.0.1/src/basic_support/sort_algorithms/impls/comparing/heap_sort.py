#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: heap_sort.py
@Description: 堆排序
@time: 2023/1/30 16:37
"""
import math
from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_comparing import AbsComparing


class HeapSort(AbsComparing):
    def __init__(self):
        super(HeapSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        arr = array if in_place else deepcopy(array)
        self.arr_len = len(arr)
        self.build_max_heap(arr, descending)
        for i in range(len(arr) - 1, 0, -1):
            self.swap(arr, 0, i)
            self.arr_len -= 1
            self.heapify(arr, 0, descending=descending)
        return arr

    def build_max_heap(self, arr, descending):
        for i in range(math.floor(len(arr) / 2), -1, -1):
            self.heapify(arr, i, descending=descending)

    def heapify(self, arr, i, descending):
        left = 2 * i + 1
        right = 2 * i + 2
        largest = i
        if left < self.arr_len and self.compare(arr[largest], arr[left], descending):
            largest = left
        if right < self.arr_len and self.compare(arr[largest], arr[right], descending):
            largest = right

        if largest != i:
            self.swap(arr, i, largest)
            self.heapify(arr, largest, descending=descending)

    def swap(self, arr, i, j):
        arr[i], arr[j] = arr[j], arr[i]


if __name__ == '__main__':
    heap_sort = HeapSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = heap_sort.sort(array=array)
    print(array)
    print(res)

    res = heap_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
