#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: bubble_sort.py
@Description: 冒泡排序
@time: 2023/1/30 14:54
"""
from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_comparing import AbsComparing


class BubbleSort(AbsComparing):
    def __init__(self):
        super(BubbleSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        arr = array if in_place else deepcopy(array)
        # 大数沉底
        # for i in range(1, len(arr)):
        #     for j in range(0, len(arr) - i):
        #         if not self.compare(arr[j], arr[j + 1], descending=descending):
        #             arr[j], arr[j + 1] = arr[j + 1], arr[j]

        # 小数冒泡
        for i in range(1, len(arr)):
            for j in reversed(range(i, len(arr))):
                if self.compare(arr[j], arr[j - 1], descending=descending):
                    arr[j], arr[j - 1] = arr[j - 1], arr[j]
        return arr


if __name__ == '__main__':
    bubble_sort = BubbleSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = bubble_sort.sort(array=array)
    print(array)
    print(res)

    res = bubble_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
