#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: quick_sort.py
@Description: 
@time: 2023/1/30 16:25
"""
from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_comparing import AbsComparing


def swap(arr, i, j):
    arr[i], arr[j] = arr[j], arr[i]


class QuickSort(AbsComparing):
    def __init__(self):
        super(QuickSort, self).__init__()

    def sort(self, array: List, left=None, right=None, in_place: bool = False, descending: bool = False) -> List:
        assert in_place, "仅支持本地排序"
        arr = array if in_place else deepcopy(array)
        left = 0 if not isinstance(left, (int, float)) else left
        right = len(arr) - 1 if not isinstance(right, (int, float)) else right
        if left < right:
            partition_index = self.partition(arr, left, right, descending)
            self.sort(arr, left, partition_index - 1, in_place=in_place, descending=descending)
            self.sort(arr, partition_index + 1, right, in_place=in_place, descending=descending)
        return arr

    def partition(self, arr, left, right, descending: bool = False):
        pivot = left
        index = pivot + 1
        i = index
        while i <= right:
            if self.compare(arr[i], arr[pivot], descending):
                swap(arr, i, index)
                index += 1
            i += 1
        swap(arr, pivot, index - 1)
        return index - 1


if __name__ == '__main__':
    quick_sort = QuickSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = quick_sort.sort(array=array, in_place=True)
    print(array)
    print(res)

    res = quick_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
