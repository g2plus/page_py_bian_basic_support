#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: bucket_sort.py
@Description: 桶排序
@time: 2023/1/30 16:59
"""

from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_non_comparing import AbsNonComparing


class BucketSort(AbsNonComparing):
    def __init__(self):
        super(BucketSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        assert not in_place, "不支持本地排序"
        arr = array if in_place else deepcopy(array)
        min_num, max_num = min(arr), max(arr)
        bucket_num = (max_num - min_num) // 3 + 1
        buckets = [[] for _ in range(int(bucket_num))]
        for num in arr:
            buckets[int((num - min_num) // 3)].append(num)
        new_array = list()
        for i in buckets:
            for j in sorted(i, key=self._key_func):
                new_array.append(j)
        return new_array[::-1] if descending else new_array


if __name__ == '__main__':
    bucket_sort = BucketSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = bucket_sort.sort(array=array)
    print(array)
    print(res)

    res = bucket_sort.sort(array=array, descending=True)
    print(array)
    print(res)
