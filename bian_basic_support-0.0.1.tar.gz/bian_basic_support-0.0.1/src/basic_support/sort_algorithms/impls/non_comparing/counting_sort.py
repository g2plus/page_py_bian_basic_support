#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: counting_sort.py
@Description: 计数排序
@time: 2023/1/30 16:51
"""

from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_non_comparing import AbsNonComparing


class CountingSort(AbsNonComparing):
    def __init__(self):
        super(CountingSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        arr = array if in_place else deepcopy(array)
        max_value = max(arr)
        bucket_len = max_value + 1
        bucket = [0] * bucket_len
        sorted_index = 0
        arr_len = len(arr)
        for i in range(arr_len):
            if not bucket[arr[i]]:
                bucket[arr[i]] = 0
            bucket[arr[i]] += 1

        arrange = reversed(range(bucket_len)) if descending else range(bucket_len)
        for j in arrange:
            while bucket[j] > 0:
                arr[sorted_index] = j
                sorted_index += 1
                bucket[j] -= 1

        return arr


if __name__ == '__main__':
    counting_sort = CountingSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = counting_sort.sort(array=array)
    print(array)
    print(res)

    res = counting_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
