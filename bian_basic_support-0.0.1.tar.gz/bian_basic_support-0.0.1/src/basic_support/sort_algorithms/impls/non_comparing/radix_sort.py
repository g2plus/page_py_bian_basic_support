#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: radix_sort.py
@Description: 基数排序
@time: 2023/1/30 17:16
"""

from copy import deepcopy
from typing import List

from basic_support.sort_algorithms.impls.abs_non_comparing import AbsNonComparing


class RadixSort(AbsNonComparing):
    def __init__(self):
        super(RadixSort, self).__init__()

    def sort(self, array: List, in_place: bool = False, descending: bool = False) -> List:
        arr = array if in_place else deepcopy(array)
        max_num = max(arr)
        place = 1
        while max_num >= 10 ** place:
            place += 1
        for i in range(place):
            buckets = [[] for _ in range(10)]
            for num in arr:
                radix = int(num / (10 ** i) % 10)
                buckets[radix].append(num)
            j = 0
            for k in range(10):
                for num in buckets[k]:
                    arr[j] = num
                    j += 1

        return arr[::-1] if descending else arr


if __name__ == '__main__':
    radix_sort = RadixSort()
    array = [25, 17, 33, 17, 22, 13, 32, 15, 9, 25, 27, 18]
    res = radix_sort.sort(array=array)
    print(array)
    print(res)

    res = radix_sort.sort(array=array, in_place=True, descending=True)
    print(array)
    print(res)
