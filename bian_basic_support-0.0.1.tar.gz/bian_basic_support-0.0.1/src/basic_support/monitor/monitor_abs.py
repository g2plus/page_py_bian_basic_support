#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: monitor_abs.py
@Description: 监控抽象类
@time: 2021/2/25 14:09
"""
import threading
from abc import ABC, ABCMeta, abstractmethod
from enum import Enum, unique

from typing import Any, Callable, List, Tuple


class FileCommand:
    def __init__(self, target_dir: str, time_interval: float = 0.5):
        """
        文件指令配置类
        :param target_dir: 监控目标目录
        :param time_interval: 监控间隔，不宜太小或太大
        """
        self.target_dir = target_dir
        self.time_interval = time_interval
        self.commands: List[Tuple] = []

    def add_command(self, operator_type: Any, do_something: Callable = None):
        """
        新增 事件类型和事件回调
        :param operator_type: 事件类型
        :param do_something: 事件回调
        """
        self.commands.append((operator_type, do_something))


@unique
class FileOperatorType(Enum):
    """
    文件操作枚举类
    """
    CREATED = 0
    MOVED = 1
    MODIFIED = 2
    DELETED = 3


class MonitorAbs(ABC, metaclass=ABCMeta):
    def __init__(self):
        """
        监控类
        """
        pass

    @abstractmethod
    def monitor(self, *args, **kwargs):
        """
        监控方法
        :param args:
        :param kwargs:
        """
        pass

    def start_monitor(self, *args, **kwargs):
        """
        启动一个线程去实现异步监控
        :param args:
        :param kwargs:
        :return:
        """
        thread = threading.Thread(target=self.monitor, args=(args, kwargs))
        thread.start()
        return thread
