#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: file_event_handler.py
@Description: 文件监控handler类，真正监控的类
@time: 2021/2/25 16:24
"""

import threading

from watchdog.events import *
from watchdog.utils.dirsnapshot import DirectorySnapshot, DirectorySnapshotDiff

from basic_support.monitor.monitor_abs import FileOperatorType, FileCommand


class FileEventHandler(FileSystemEventHandler):
    def __init__(self, file_command: FileCommand):
        """
        :param file_command: 文件指令配置
        """
        FileSystemEventHandler.__init__(self)
        self.file_command = file_command
        self.timer = None
        self.snapshot = DirectorySnapshot(self.file_command.target_dir)

    def on_any_event(self, event):
        if self.timer:
            self.timer.cancel()
        # TODO 监控的时间间隔
        self.timer = threading.Timer(self.file_command.time_interval, self.check_snapshot)
        self.timer.start()

    def check_snapshot(self):
        """
        文件快照检查
        """
        snapshot = DirectorySnapshot(self.file_command.target_dir)
        diff = DirectorySnapshotDiff(self.snapshot, snapshot)
        self.snapshot = snapshot
        self.timer = None

        dic = {
            FileOperatorType.CREATED.name: diff.files_created + diff.dirs_created,
            FileOperatorType.MOVED.name: diff.files_moved + diff.dirs_moved,
            FileOperatorType.MODIFIED.name: diff.files_modified + diff.dirs_modified,
            FileOperatorType.DELETED.name: diff.files_deleted + diff.dirs_deleted
        }

        # 下面是应处理的各种事项
        for operator_type, do_something in self.file_command.commands:
            if dic[operator_type.name]:
                do_something(op_type=operator_type, files=dic[operator_type.name])
