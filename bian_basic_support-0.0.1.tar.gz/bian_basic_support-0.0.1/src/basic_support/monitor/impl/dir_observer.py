#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: dir_observer.py
@Description: 文件监控类
@time: 2021/2/25 16:24
"""

from watchdog.observers import Observer

from basic_support.monitor.impl.file_event_handler import FileEventHandler
from basic_support.monitor.monitor_abs import FileCommand


class DirObserver:
    """文件夹监视类"""

    def __init__(self, file_command: FileCommand):
        """构造函数"""
        self.observer = Observer()
        self.file_command = file_command

    def start(self):
        """启动"""
        event_handler = FileEventHandler(self.file_command)
        self.observer.schedule(event_handler, self.file_command.target_dir, True)
        self.observer.start()
        self.observer.join()

    def stop(self):
        """停止"""
        self.observer.stop()
