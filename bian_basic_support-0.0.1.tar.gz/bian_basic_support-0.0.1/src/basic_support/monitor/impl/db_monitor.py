#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: db_monitor.py
@Description: 数据库监控类
@time: 2021/2/25 14:10
"""
from basic_support.monitor.monitor_abs import MonitorAbs


class DbMonitor(MonitorAbs):
    def __init__(self):
        super(DbMonitor, self).__init__()

    def monitor(self, *args, **kwargs):
        pass
