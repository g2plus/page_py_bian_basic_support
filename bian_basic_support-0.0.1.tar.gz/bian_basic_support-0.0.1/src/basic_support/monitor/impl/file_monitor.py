#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: file_monitor.py
@Description: 文件监控类
                https://blog.csdn.net/chdhust/article/details/50514391
@time: 2021/2/25 14:09
"""

from basic_support.monitor.impl.dir_observer import DirObserver
from basic_support.monitor.monitor_abs import MonitorAbs, FileCommand


class FileMonitor(MonitorAbs):
    def __init__(self, file_command: FileCommand):
        super(FileMonitor, self).__init__()
        self.file_command = file_command

    def monitor(self, *args, **kwargs):
        monitor = DirObserver(self.file_command)
        monitor.start()
