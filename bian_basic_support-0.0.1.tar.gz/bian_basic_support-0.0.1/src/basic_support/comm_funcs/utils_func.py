#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: utils_func.py
@Description: 常用的工具类或方法[好用]
@time: 2020/4/27 10:23
"""

import configparser
import datetime
import hashlib
import inspect
import json
import random
import re
import time
import traceback
import typing
from collections import namedtuple
from functools import wraps

import pandas as pd
from decorator import decorator

from basic_support.comm_classes.mail_tool import Message, AbsMailTool
from basic_support.logger.logger_config import logger


def time_this_function(func):
    """
    通用计时装饰器，支持同步、异步、staticmethod、classmethod 任意嵌套顺序。
    """

    is_static = isinstance(func, staticmethod)
    is_class = isinstance(func, classmethod)

    # 提取原始函数
    raw_func = func.__func__ if (is_static or is_class) else func

    if inspect.iscoroutinefunction(raw_func):
        @wraps(raw_func)
        async def async_wrapper(*args, **kwargs):
            logger.info(f"[{raw_func.__name__}] 开始执行（异步）...")
            start = time.time()
            result = await raw_func(*args, **kwargs)
            end = time.time()
            logger.info(f"[{raw_func.__name__}] 执行结束（异步），耗时 {round(end - start, 4)}s")
            return result

        # 还原 staticmethod 或 classmethod
        if is_static:
            return staticmethod(async_wrapper)
        elif is_class:
            return classmethod(async_wrapper)
        else:
            return async_wrapper

    else:
        @wraps(raw_func)
        def sync_wrapper(*args, **kwargs):
            logger.info(f"[{raw_func.__name__}] 开始执行...")
            start = time.time()
            result = raw_func(*args, **kwargs)
            end = time.time()
            logger.info(f"[{raw_func.__name__}] 执行结束，耗时 {round(end - start, 4)}s")
            return result

        if is_static:
            return staticmethod(sync_wrapper)
        elif is_class:
            return classmethod(sync_wrapper)
        else:
            return sync_wrapper


def send_mail_function(mail_tool: AbsMailTool, message: Message):
    """
    发送邮件的装饰器
    :param mail_tool: 邮箱管理工具
    :param message: 邮件消息
    :return:
    """

    def write_func(func):
        @wraps(func)
        def inner(*args, **kwargs):
            start = time.time()
            res = func(*args, **kwargs)
            end = time.time()

            msg_content = message.content if message.content else ''
            content = f"[{func.__name__}]执行结束, 耗时{round(end - start, 4)}s\n\n{msg_content}"
            message.content = content
            resp = mail_tool.send(message=message)
            logger.info(f"[{func.__name__}]发送{'成功' if resp else '失败'}")

            return res

        return inner

    return write_func


def wrap_to_object(obj_cls_name: str):
    """
    将数据包装成namedtuple对象
    :param obj_cls_name:
    :return:
    """

    def inner_func(func: typing.Callable):

        @wraps(func)
        def inner(*args, **kwargs):
            Object: type = None
            data_iter = func(*args, **kwargs)
            for record in data_iter:
                if Object is None:
                    Object = namedtuple(obj_cls_name, record.keys())
                yield Object(*record.values())

        return inner

    return inner_func


def weighted_random(items):
    """
    带权随机采样: https://blog.csdn.net/handsomekang/article/details/40542817?d=1588946866607
    """
    total = sum(w for _, w in items)
    random_n = random.uniform(0, total)  # 在饼图扔骰子
    idx = None
    for idx, value in items:  # 遍历找出骰子所在的区间
        if random_n < value:
            break
        random_n -= value
    return idx


def gen_md5(text: str, encoding='UTF-8') -> str:
    """
    将字符串转为md5编码
    """
    m2 = hashlib.md5()
    m2.update(text.encode(encoding=encoding))
    return m2.hexdigest()


def clean_file_name(filename: str):
    """
    去除文件名中的非法字符
    """
    invalid_chars = r'[\\\/:*?"<>|]'
    replace_char = '-'
    return re.sub(invalid_chars, replace_char, filename)


def get_fixed_hash(text: str):
    m = hashlib.md5(text.encode("utf8")).hexdigest()
    map_key = str(m)[-2:]
    val = int(map_key, 16)
    return val


def repr_mixin(cls):
    """
    类装饰器
    类表示的混入类，结合__init__的参数列表，返回符合初始化函数的repr表示
    """

    @wraps(cls)
    def __repr__(self):
        """
        __repr__() 生成的文本字符串标准做法是需要让 eval(repr(x)) == x 为真。
        如果实在不能这样子做，应该创建一个有用的文本表示，并使用 < 和 > 括起来。
        """
        if not hasattr(self, '__init_args__'):
            import inspect
            self.__init_args__ = inspect.getfullargspec(self.__init__)[1:]
        return f"{self.__class__.__name__}({', '.join(['%s=%r' % (k, type(self.__dict__[k])(self.__dict__[k])) for k in self.__init_args__ if k in self.__dict__.keys()])})"

    cls.__repr__ = __repr__
    return cls


def typing_check(func):
    """
    函数参数类型校验 装饰器
    https://www.cnblogs.com/duanming/p/11830287.html
    """
    params = inspect.signature(func).parameters
    annotation_dict = {str(idx): value.annotation for idx, value in enumerate(params.values())}
    POSITIONAL_OR_KEYWORD = 1
    VAR_POSITIONAL = 2
    VAR_KEYWORD = 4

    @wraps(func)
    def inner_func(*args, **kwargs):
        for idx, value in enumerate(args):
            if idx < len(params) and annotation_dict[f'{idx}'] is not inspect._empty:
                if not isinstance(type(annotation_dict[f'{idx}']), typing._GenericAlias) and \
                        type(value) is not annotation_dict[f'{idx}']:
                    TypeError("TypeError: value 【%r】 Can’t convert ‘%s’ object to %s implicitl" %
                              (value, type(value), annotation_dict[f'{idx}']))
                if isinstance(type(annotation_dict[f'{idx}']), typing._GenericAlias) and \
                        type(value) is not annotation_dict[f'{idx}'].__origin__:
                    TypeError("TypeError: value 【%r】 Can’t convert ‘%s’ object to %s implicitl" %
                              (value, type(value), annotation_dict[f'{idx}']))

        for key, value in kwargs.items():
            if key in params.keys() and params[key].kind.value == POSITIONAL_OR_KEYWORD and params[
                key].annotation is not inspect._empty:
                if not isinstance(type(params[key]), typing._GenericAlias) and type(value) is not params[
                    key].annotation:
                    raise TypeError("TypeError: value 【%r】 Can’t convert ‘%s’ object to %s implicitl" %
                                    (value, type(value), annotation_dict[f'{idx}']))
                if isinstance(type(params[key]), typing._GenericAlias) and \
                        type(value) is not params[key].annotation.__origin__:
                    raise TypeError("TypeError: value 【%r】 Can’t convert ‘%s’ object to %s implicitl" %
                                    (value, type(value), annotation_dict[f'{idx}']))
        return func(*args, **kwargs)

    return inner_func


def dict_print(dict_: dict):
    return json.dumps(dict_, indent=4, ensure_ascii=False, sort_keys=False, separators=(',', ':'))


def get_month_range(start_day, months):
    """
    两个月份中间的所有月份
    :param start_day:
    :param end_day:
    :return:
    """
    start_day = datetime.datetime.strptime(start_day, '%Y%m')
    if months >= 0:
        month_range = ['%s%s' % (start_day.year + mon // 12, "{0:0=2d}".format(mon % 12 + 1))
                       for mon in range(start_day.month - 1, start_day.month + months)]
    else:
        month_range = ['%s%s' % (start_day.year + mon // 12, "{0:0=2d}".format(mon % 12 + 1))
                       for mon in range(start_day.month + months - 1, start_day.month)]
    return month_range


def label_encoder(data: typing.List):
    from sklearn import preprocessing
    column = pd.Series(data)
    set_data = list(set(data))
    le = preprocessing.LabelEncoder()
    le = le.fit(set_data)
    return le.transform(column), {list(le.classes_).index(i): i for i in list(le.classes_)}


def get_last_month(date, date_range):
    # 获取当前时间
    today = datetime.datetime.strptime(date, '%Y%m')
    # 获取当前月份的第一天
    first = today.replace(day=1)
    # 获取前一个月的最后一天
    if date_range == 1:
        lastMonth = first - datetime.timedelta(days=date_range)
    if date_range == 2:
        lastMonth = first - datetime.timedelta(days=32)
    # 前一个月的月份
    return lastMonth.strftime("%Y%m")


def load_ini_config(ini_path):
    config = configparser.ConfigParser()
    config.read(ini_path)
    sections = config.sections()
    cfg = {section: {k: eval(v) for k, v in config.items(section)} for section in sections}
    return cfg


def load_sqlalchenmy_conn(ini_path, db_type):
    cfg = load_ini_config(ini_path)[db_type]
    conn = f'{db_type}://{cfg["user"]}:{cfg["password"]}@{cfg["host"]}:{cfg["port"]}/{cfg["db"]}'
    return conn


@decorator
def run_daily(
        func: typing.Callable[['last_rksj'], 'last_rksj'], time_delta: str = '1d', is_test=False,
        *last_rksj,
):
    last_rksj_ = None
    fixed_run_time = pd.to_datetime(datetime.datetime.now().date())
    fixed_run_time = fixed_run_time + pd.Timedelta(time_delta) if not is_test else fixed_run_time
    cnt = 1
    while True:
        cur_time = datetime.datetime.now()
        if cur_time >= fixed_run_time:
            try:
                if cnt != 1:
                    last_rksj = tuple([last_rksj_])
                last_rksj_ = func(*last_rksj)
                cnt += 1
            except:
                err_msg = traceback.format_exc()
                logger.error(err_msg)
            fixed_run_time = fixed_run_time + pd.Timedelta(time_delta)
            if is_test:
                break


def get_tcp_port():
    import socket
    # 获取可用端口号
    tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp.bind(("", 0))
    _, port = tcp.getsockname()
    tcp.close()
    return port


def get_localhost():
    import socket
    hostname = socket.gethostname()
    localhost = socket.gethostbyname(hostname)
    return localhost
