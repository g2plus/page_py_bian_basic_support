#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: text_utils.py
@Description: 
@time: 2020/8/7 上午11:01
"""
import copy
import difflib
import json
import random
import re
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from math import log as math_log
from typing import Any, List, Mapping, Dict, Set, Tuple, Union


def find_sub_parts_idx(sub_parts: List[str], full_text: str) -> List[Tuple[str, int]]:
    """
    找出字符串列表sub_parts在字符串中的起始索引号
    """
    ret = []
    cur_txt = full_text
    cur_idx = 0
    for sub in sub_parts:
        idx = cur_txt.find(sub)
        ret.append((sub, cur_idx + idx))
        if idx >= 0:
            cur_txt = cur_txt[idx + len(sub):]
            cur_idx += idx + len(sub)
    return ret


class TireObj:
    def __init__(
            self,
            separator="/",
            is_list_val: bool = False
    ) -> None:
        """
        :param str separator: _description_, defaults to "/"
        :param bool is_list_val: 添加的值是否已list的方式合并累加, defaults to False
        """
        import pygtrie
        self.separator = separator
        self.tire = pygtrie.StringTrie(separator=self.separator)
        self.is_list_val = is_list_val

    def add(
            self,
            key: Union[str, Tuple[str, ...]],
            val: any
    ) -> "TireObj":
        """添加kv
        :param Union[str,Tuple[str,...]] key: 
        :param any val: 
        :return TireObj: self
        """
        tp_key = type(key)
        assert tp_key is str or tp_key is tuple, f"<TireObj>: key的类型只能是str或tuple，实际类型为:{tp_key.__name__}"
        s = self.separator.join(key)
        if self.is_list_val:
            lst = self.tire[s][1] if self.tire.has_key(s) else []
            lst.append(val)
            self.tire[s] = (tp_key, lst)
        else:
            self.tire[s] = (tp_key, val)
        return self

    def search(
            self,
            text: Union[str, List[str], Tuple[str, ...]],
            sep_by_ch: bool = False
    ) -> Dict[Union[str, Tuple[str, ...]], Any]:
        """从text中查找所有的包含于tire的子串(或分词列表)
        :param Union[str,Tuple[str,...]] text: 待查找的文本(或分词列表)
        :param bool sep_by_ch: 是否强制按字符切分
        :return Dict[Union[str,Tuple[str,...]], Any]: {子串(或分词列表): 子串(或分词列表)对应的value}
        """
        i = 0
        ret = dict()
        while i < len(text):
            if sep_by_ch:
                sub_txt = self.separator.join("".join(text[i:]))
            else:
                sub_txt = self.separator.join(text[i:])
            r = self.tire.longest_prefix(sub_txt)
            if r.key is not None:
                tp_key, val = r.value
                # assert tp_key is str or tp_key is tuple, f"<TireObj>: key的类型只能是str或tuple，实际类型为:{tp_key.__name__}"
                if tp_key is str:
                    key = r.key.replace(self.separator, "")
                else:
                    key = tuple([v for v in r.key.split(self.separator) if len(v) > 0])
                ret[key] = val
                l = len(key)
                while l > 0:
                    l -= len(text[i])
                    i += 1
            else:
                i += 1
        return ret


default_word_dict = {
    "时间": ["1995年", "2020", "2012"],
    "网名": ["刘德华", "梦桥 花开 て", "雨下听风", "浠旪落埖〆"],
    "详址": ["中山路", "镇北路", "卢沟桥"],
    "行政区划": ["厦门市", "台北市", "东京"],
    "群名": ["黑桃", "家族群", "二逼俱乐部"],
    "微信": ["周杰伦", "梁朝伟", "毛泽东"],
    "群ID": ["9274", "18320", "18950"],
    "群成员数": ["73", "102", "95"],
    "人名": ["刘德华", "梁朝伟", "周恩来", "毛泽东"],
    "身份证": ["350125199810103210", "350125199810103211", "350125199810103212"],
    "手机号": ["13505981112", "13599229999", "17759559999"],
    "群分类": ["亲友群", "家族群", "同学群", "工作群", "红包群"],
    "QQ": ["郭富城", "183200423", "15463562"],
    "ID": ["张学友", "100235", "142235"],
    "车牌号": ["88888", "鲁VM0093", "鲁G9167S"],
    "群创建人": ["蔡依林", "刘德华", "周恩来", "毛泽东"],
    "链接": ["kkkkk", "www.baidu.com", "www.google.com"],
    "固定电话": ["110", "010-88711138", "010-68865199"],
    "学校": ["清华大学", "师范大学", "华侨大学", "厦门大学"],
    "标注": ["可视化", '专业性'],
    "专业": ["软件工程", "信息通信", "蓝领", "教师", "白领"],
    "公司": ["百度", "阿里巴巴"],
    "n_phrase": ["它", ],
}

special_token = "!#@#!"


def replace_by_dic(text: str, reg_lst: List[str], word_dict: Mapping[str, List] = None):
    """
    依据传入字典更新text和reg_lst
    @param text:　原句子
    @param reg_lst:　标注列表，如：['学校　2　福州大学',]
    @param word_dict: 替换策略词典
    @return: 新句子+新标注列表
    """
    if not word_dict:
        word_dict = default_word_dict
    new_reg_lst = sorted(reg_lst, key=lambda k: int(k.split(' ', 2)[1]))
    for idx, reg in enumerate(new_reg_lst):
        tag, start_index, value = reg.split(' ', 2)
        start_index = int(start_index)
        new_value = word_dict.get(tag, [tag])[random.randint(0, len(word_dict.get(tag, [tag])) - 1)]
        text = f'{text[:start_index]}{new_value}{text[start_index + len(value):]}'
        new_reg_lst[idx] = f"{tag} {start_index} {new_value}"
        distance = len(new_value) - len(value)
        for reg_idx in range(idx + 1, len(new_reg_lst)):
            tmp_tag, tmp_start_index, tmp_value = new_reg_lst[reg_idx].split(' ', 2)
            new_reg_lst[reg_idx] = f"{tmp_tag} {int(tmp_start_index) + distance} {tmp_value}"
    return text, new_reg_lst


def find_new_reg_lst(texts: List[str], old_reg_lsts: List[List[str]], word_dict: Mapping[str, List] = None):
    """
    为样本添加指定的词 的reg_lst
    @param texts:　原句子列表
    @param old_reg_lsts: 标注列表，如：[['学校　2　福州大学',]]
    @param word_dict: 策略词典
    @return: 新标注列表
    """
    reg_lsts = copy.deepcopy(old_reg_lsts)
    for text, reg_lst in zip(texts, reg_lsts):
        # 已知实体下标集合
        reg_idx_set = set()
        for reg in reg_lst:
            _, start_index, value = reg.split(' ', 2)
            reg_idx_set.update([int(start_index) + k for k, v in enumerate(value)])

        for key in word_dict.keys():
            for mch in re.finditer(key, text):
                start_index = mch.start()
                # 不能和已知实体 重叠
                if not reg_idx_set & set([start_index + k for k, v in enumerate(key)]):
                    reg_lst.append(f'{key} {start_index} {key}')
    return [sorted(reg_lst, key=lambda k: int(k.split(' ', 2)[1])) for reg_lst in reg_lsts]


def chinese_sentences_split(sample: str, spliter=None, length_control: int = 20):
    """
    中文分句
    :param sample: 单条样本
    :param spliter: 分句的依据
    :param length_control: 句子长度限制
    :return: 分好的句子列表
    """
    spliter = spliter if spliter else '\n|。|！|？|\t'
    return (d for d in re.split(spliter, sample) if len(d) >= length_control)


def check_reg_lst(text: str, reg_lst: List[str]) -> bool:
    """
    reg_lst正确性检查
    :param text:
    :param reg_lst:
    :return:
    """
    for reg in reg_lst:
        tag, start_idx, value = reg.split(' ', 2)
        start_idx = int(start_idx)
        if text[start_idx:start_idx + len(value)] != value:
            return False
    return True


datetime_pattern_list = ['%Y-%m-%d %H:%M:%S', '%Y%m%d']


def datetime_string_to_value(datetime_string: str):
    result = []
    for p in datetime_pattern_list:
        try:
            result.append(datetime.strptime(datetime_string, p))
        except:
            result += []
    # date, time = datetime_string.split()
    # year, month, day = re.split('[/-]', date)
    # hour, minute, second = time.split(':')
    # return datetime(int(year), int(month), int(day), int(hour), int(minute), int(second))
    if not result:
        raise Exception(f'时间字符串{datetime_string}格式错误，无法解析！')
    return result[0]  # 一定仅有一个


def log(x):
    return -100 if x == 0 else math_log(x)


def merge_word_lst(word_lst: List[str], merge_words: Union[Set[str], None]) -> List[str]:
    """将词列表word_lst的词按merge_words进行合并

    :param List[str] word_lst: _description_
    :param Set[str] merge_words: _description_
    """
    if merge_words is None or len(merge_words) == 0:
        return word_lst
    merge_word_lst = [w.strip() for w in merge_words if len(w) > 0]
    merge_word_lst = [w for w in merge_word_lst if len(w) > 0]
    if len(merge_word_lst) == 0:
        return word_lst
    merge_word_lst.sort(
        key=lambda i: len(i),
        reverse=True
    )
    for mw in merge_word_lst:
        word_lst = merge_word_lst_single(word_lst, mw)
    return word_lst


def merge_word_lst_single(word_lst: List[str], merge_word: str) -> List[str]:
    cur_w_st_idx = 0
    word_lst = word_lst.copy()
    while cur_w_st_idx < len(word_lst):
        cur_w_ed_idx = cur_w_st_idx + 1
        while cur_w_ed_idx <= len(word_lst):
            cur_text = "".join(word_lst[cur_w_st_idx: cur_w_ed_idx])
            if cur_text not in merge_word and merge_word not in cur_text:
                break
            cur_w_ed_idx += 1
            if len(cur_text) >= len(merge_word):
                break
        cur_w_ed_idx -= 1
        if cur_w_ed_idx > cur_w_st_idx:
            w_text = "".join(word_lst[cur_w_st_idx: cur_w_ed_idx])
            if merge_word in w_text:  # 当前索引匹配上了
                word_lst = word_lst[:cur_w_st_idx] + [w_text, ] + word_lst[cur_w_ed_idx:]
        cur_w_st_idx += 1
    return word_lst


def find_all_substrings(string, substring):
    """查找字符串内指定子串的所有位置
    :param _type_ string: _description_
    :param _type_ substring: _description_
    :return _type_: _description_
    """
    start_index_number = 0
    end_index_number = len(string)
    indices = []
    while True:
        index = string.find(substring, start_index_number, end_index_number)
        if index == -1:
            break
        indices.append(index)
        start_index_number = index + 1
    return indices


def cal_occr(a, b, g=0.0) -> bool:
    for idx in range(len(a) - 1):
        if b.startswith(a[idx:]):
            if (len(a) - idx) / len(a) >= g:
                return True

    for idx in range(len(b) - 1):
        if a.startswith(b[idx:]):
            if idx / len(b) >= g:
                return True
    return False


def common_pmi(chars: Dict, pairs: Dict, min_pmi: float = 1e-7) -> Dict:
    log_total_chars = log(sum(chars.values()))
    log_total_pairs = log(sum(pairs.values()))
    chars = {i: log(j) - log_total_chars for i, j in chars.items()}
    pairs = {i: log(j) - log_total_pairs for i, j in pairs.items()}

    pmi_dict = {}
    for k, pair in pairs.items():
        a, b = k
        pmi = pair - chars[a] - chars[b]
        if pmi >= min_pmi:
            pmi_dict[k] = pmi

    return pmi_dict


def cal_two_words_pmi(chars: Dict, pairs: Dict, min_pmi: float = 1e-7, pass_similar: bool = False):
    """
    计算pmi, pairs里的key 会尝试所有切分组合，找到最小的pmi切分
    :param chars: {"年后":15, "今年":36, ...}
    :param pairs: {"今年年后":9, ...}
    :param min_pmi: 最小pmi阈值
    :return:
    """
    filter_ori_pairs = copy.deepcopy(pairs)
    log_total_chars = log(sum(chars.values()))
    log_total_pairs = log(sum(pairs.values()))
    chars = {i: log(j) - log_total_chars for i, j in chars.items()}
    pairs = {i: log(j) - log_total_pairs for i, j in pairs.items()}

    n_pairs, filter_pairs = {}, {}
    for word, value in pairs.items():
        pair_mpi = 1e9
        # 查找使pmi最小的单词 组合
        cut_word_idx = 0
        for idx in range(1, len(word)):
            if word[:idx] in chars and word[idx:] in chars:
                if pair_mpi > value - chars[word[:idx]] - chars[word[idx:]]:
                    pair_mpi = value - chars[word[:idx]] - chars[word[idx:]]
                    cut_word_idx = idx
        if pair_mpi > min_pmi and cut_word_idx != 0:
            if (not pass_similar) or \
                    (pass_similar and word[:cut_word_idx] not in word[cut_word_idx:] \
                     and word[cut_word_idx:] not in word[:cut_word_idx] and \
                     not cal_occr(word[:cut_word_idx], word[cut_word_idx:])):
                n_pairs[f"{word[:cut_word_idx]}#{word[cut_word_idx:]}"] = pair_mpi
                filter_pairs[f"{word[:cut_word_idx]}#{word[cut_word_idx:]}"] = filter_ori_pairs[word]
                # filter_pairs[word] = filter_ori_pairs[word]
    return n_pairs, filter_pairs


class DictionaryLoader:
    @staticmethod
    def get_core_words(core_word_path: str = None, only_num: bool = False) -> Dict:
        """
        读取核心词词典
        :param core_word_path: 核心词典路径，文件格式 : w 1\n ± w 1 n 6\n ...
        :param only_num: 是否仅需要各个词与词频信息
        :return:
        """
        if core_word_path is None:
            core_word_path = r"G:\Anaconda4\envs\hyc_py36\Lib\site-packages\pyhanlp\static\data\dictionary\CoreNatureDictionary.txt"
        core_words = defaultdict(dict)
        with open(core_word_path, 'r', encoding='utf-8') as f:
            for line in f.readlines():
                infos = line.strip().split('\t')
                word = infos[0]
                for a, b in zip(infos[1::2], infos[2::2]):
                    core_words.setdefault(word, dict())[a] = int(b)
        if only_num:
            new_only_dic = defaultdict(int)
            for k, v in core_words.items():
                new_only_dic[k] = sum(v.values())
            return new_only_dic
        return core_words

    @staticmethod
    def get_stop_words(stop_words_path: str = None) -> List:
        """
        读取停用词列表
        :param stop_words_path:
        :return:
        """
        if stop_words_path is None:
            stop_words_path = r"G:\Anaconda4\envs\hyc_py36\Lib\site-packages\pyhanlp\static\data\dictionary\stopwords.txt"
        with open(stop_words_path, 'r', encoding='utf-8') as f:
            stop_words = [line.strip() for line in f.readlines()]
        return stop_words


def def_tfidf(cls_info_lst: Dict):
    """
    tf-idf普通实现
    [06_TF-IDF算法代码示例](https://blog.csdn.net/u012990179/article/details/90338906)
    :param cls_info_lst: {"A":{"a":15,"b":18,...}, "B":{"c":48,...},...}
    :return:
    """
    tf_dic = {}
    idf_res = defaultdict(int)
    for cls, cls_info in cls_info_lst.items():
        total = sum(cls_info.values())
        hy = {k: v / total for k, v in cls_info.items()}
        tf_dic[cls] = hy
        for k in set(cls_info.keys()):
            idf_res[k] += 1
    total_doc = len(cls_info_lst)
    idf_res = {k: log(total_doc / (v + 1)) for k, v in idf_res.items()}

    cls_word_weights = []
    for cls, tf_info in tf_dic.items():
        t_lst = []
        for k, v in tf_info.items():
            t_lst.append([k, v * idf_res.get(k, 1)])
        cls_word_weights.append((cls, t_lst))

    return cls_word_weights


def key_phrase_tfidf(cls_info_lst: Dict):
    """
    关键词挖掘计算使用的tf-idf实现
    :param cls_info_lst:
    :return:
    """
    tf_dic = {}
    idf_res = defaultdict(int)
    for cls, cls_info in cls_info_lst.items():
        total = sum(cls_info.values())
        hy = {k: v / total for k, v in cls_info.items()}
        tf_dic[cls] = hy
        for k in set(cls_info.keys()):
            idf_res[k] += 1
    total_doc = len(cls_info_lst)
    # idf_res = {k: math.pow((total_doc + 1) / v, 2) for k, v in idf_res.items()}
    idf_res = {k: log(total_doc / (v + 1)) for k, v in idf_res.items()}

    cls_word_weights = []
    for cls, tf_info in tf_dic.items():
        t_lst = []
        for k, v in tf_info.items():
            t_lst.append([k, v * idf_res.get(k, 1)])
        cls_word_weights.append((cls, t_lst))
    return cls_word_weights


def json_dump_op(file_name, file: Dict, encoding: str = 'utf-8', ensure_ascii: bool = False, indent: int = 4):
    """
    json文件保存
    :param file_name:
    :param file:
    :param encoding:
    :param ensure_ascii:
    :param indent:
    """
    with open(file_name, 'w', encoding=encoding) as f:
        f.write(json.dumps(file, ensure_ascii=ensure_ascii, indent=indent))


def json_load_op(file_name, encoding: str = 'utf-8') -> Dict:
    """
    json文件加载
    :param file_name:
    :param encoding:
    :return:
    """
    with open(file_name, "r", encoding=encoding) as f:
        return json.load(f)


def to_str(bytes_or_str):
    """
    字节转字符串
    :param bytes_or_str:
    :return:
    """
    return bytes_or_str.decode('utf-8') if isinstance(bytes_or_str, bytes) else bytes_or_str


def to_bytes(bytes_or_str):
    """
    字符串转字节
    :param bytes_or_str:
    :return:
    """
    return bytes_or_str.encode('utf-8') if isinstance(bytes_or_str, str) else bytes_or_str


@dataclass
class TextChange:
    change_type: str  # 类型：equal, insert, delete, replace
    old_start: int  # 旧文本开始索引
    old_end: int  # 旧文本结束索引
    new_start: int  # 新文本开始索引
    new_end: int  # 新文本结束索引


def compare_texts(old_text: str, new_text: str) -> List[TextChange]:
    """
    使用difflib.SequenceMatcher比较两个文本，并生成差异标记列表。
    """
    matcher = difflib.SequenceMatcher(None, old_text, new_text)
    return [TextChange(change_type, old_start, old_end, new_start, new_end)
            for change_type, old_start, old_end, new_start, new_end in matcher.get_opcodes()]


def create_diff_word(old_text: str, new_text: str, output_filename: str):
    """
    创建一个Word文档，显示old_text与new_text的差异。
    新增：绿色；删除：红色；修改：黄色。
    """
    from docx import Document
    from docx.shared import RGBColor
    from docx.enum.text import WD_COLOR_INDEX

    doc = Document()
    changes = compare_texts(old_text, new_text)

    # 第一部分：显示旧文本的差异
    paragraph = doc.add_paragraph()
    for change in changes:
        if change.change_type in ['equal', 'insert']:
            text = old_text[change.old_start:change.old_end]
            paragraph.add_run(text)
        elif change.change_type == 'delete':
            text = old_text[change.old_start:change.old_end]
            run = paragraph.add_run(text)
            run.font.color.rgb = RGBColor(255, 0, 0)  # 红色表示删除
        elif change.change_type == 'replace':
            text = old_text[change.old_start:change.old_end]
            del_run = paragraph.add_run(text)
            del_run.font.highlight_color = WD_COLOR_INDEX.YELLOW  # 黄色表示修改

    paragraph.add_run('\n\n')

    # 第二部分：显示新文本的差异
    paragraph = doc.add_paragraph()
    for change in changes:
        if change.change_type in ['equal', 'delete']:
            text = new_text[change.new_start:change.new_end]
            paragraph.add_run(text)
        elif change.change_type == 'insert':
            text = new_text[change.new_start:change.new_end]
            run = paragraph.add_run(text)
            run.font.color.rgb = RGBColor(0, 255, 0)  # 绿色表示新增
        elif change.change_type == 'replace':
            text = new_text[change.new_start:change.new_end]
            ins_run = paragraph.add_run(text)
            ins_run.font.highlight_color = WD_COLOR_INDEX.YELLOW  # 黄色表示修改

    doc.save(output_filename)


if __name__ == "__main__":
    mg_lst = merge_word_lst(
        word_lst=["20", "23", "刑法第", "3", "条", "和", "第3", "条"],
        merge_words={"2023", "刑法", "第3条"}
    )
    print(mg_lst)
