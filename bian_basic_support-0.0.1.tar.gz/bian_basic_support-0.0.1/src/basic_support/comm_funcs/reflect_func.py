# @Time    : 2020/8/6 13:48
# @Author  : YuQL
# @FileName: reflect_func.py
# @Software: PyCharm
"""
反射相关公共函数
"""
from importlib import import_module
from typing import Generic, Any, get_args


def load_package_class_types(pkg_obj, cls_filter_func=None):
    """
    加载指定包下的所有指定类
    :param pkg_obj: 包对象
    :param cls_filter_func: 过滤函数,入参为对应class的type，返回false的类会被过滤掉
    :return:
    """
    import pkgutil
    import importlib
    from inspect import getmembers, isclass
    type_list = []
    for importer, name, ispkg in pkgutil.walk_packages(pkg_obj.__path__, "%s." % pkg_obj.__name__):
        if not ispkg:
            module = importlib.import_module(name)
            type_list.extend(
                [
                    value
                    for (_, value) in getmembers(module)
                    if isclass(value) and (cls_filter_func is None or cls_filter_func(value))
                ])
    return type_list


def get_generic_args_types(generic_obj: Generic):
    """
    获取泛型类型对象的泛型参数类型信息列表
    :param generic_obj: 泛型类型对象
    :return:
    """
    return generic_obj.__orig_class__.__args__


def load_object(path):
    """
    Load an object given its absolute object path, and return it.
    object can be a class, function, variable or an instance.
    """
    try:
        dot = path.rindex('.')
    except ValueError:
        raise ValueError("Error loading object '%s': not a full path" % path)
    module, name = path[:dot], path[dot + 1:]
    mod = import_module(module)
    try:
        obj = getattr(mod, name)
    except AttributeError:
        raise NameError("Module '%s' doesn't define any object named '%s'" % (module, name))
    return obj

# def get_func_args_spec(func: Callable) -> Dict[str, Type]:
#     return inspect.getfullargspec(func.__func__)


def get_generic_types(obj:Any):
    return get_args(obj.__orig_bases__)