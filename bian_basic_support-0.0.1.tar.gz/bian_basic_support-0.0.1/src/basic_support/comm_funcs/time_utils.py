#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: time_utils.py
@Description: 和时间日期类有关的通用函数
@time: 2021/1/11 9:21
"""

import calendar
import datetime
import time
from enum import Enum
from typing import Tuple, Iterable, List, Dict, Any

import pandas as pd
from dateutil.relativedelta import relativedelta


class TimeCycleUnit(Enum):
    YEAR = 'year'
    QUARTER = 'quarter'
    MONTH = 'month'
    WEEK = 'week'
    DAY = 'day'
    HOUR = 'hour'
    MINUTE = 'minute'
    SECOND = 'second'

    @staticmethod
    def get_enum(val):
        for k, v in TimeCycleUnit.__members__.items():
            if k == val:
                return v
        return None

    @staticmethod
    def values():
        return [v.value for k, v in TimeCycleUnit.__members__.items()]


def get_cycle_unit_dict() -> Dict[str, TimeCycleUnit]:
    """
    获取value对应的枚举
    :return: {'年': <CycleUnit.YEAR: '年'>, '季': <CycleUnit.QUARTER: '季'>, ...}
    """
    return {member.value: member for name, member in TimeCycleUnit.__members__.items()}


def get_previous_date_by_cycle(cycle: str, factor_date: datetime.datetime,
                               previous_cycle: int = 3) -> datetime.datetime:
    """
    根据周期将业务时间往前推n个周期(用于增量查询)
    :param cycle:
    :param factor_date:
    :param previous_cycle:
    :return:
    """
    previous_cycle = previous_cycle * 1.0

    if cycle == 'year':
        return factor_date - relativedelta(years=previous_cycle)
    elif cycle == 'quarter':
        return factor_date - relativedelta(months=3 * previous_cycle)
    elif cycle == 'month':
        return factor_date - relativedelta(months=previous_cycle)
    elif cycle == 'week':
        return factor_date - datetime.timedelta(weeks=previous_cycle)
    elif cycle == 'day':
        return factor_date - datetime.timedelta(days=previous_cycle)
    elif cycle == 'hour':
        return factor_date - datetime.timedelta(hours=previous_cycle)
    elif cycle == 'minute':
        return factor_date - datetime.timedelta(minutes=previous_cycle)
    elif cycle == 'second':
        return factor_date - datetime.timedelta(seconds=previous_cycle)
    else:
        raise ValueError("不支持的周期: {}".format(cycle))


cycle_unit_dict = get_cycle_unit_dict()


class DateTimeGen:
    """ 日期时间获取的工具类 """

    @staticmethod
    def time_stamp_10() -> int:
        # 获取10位的时间戳 精度是秒(s)
        return int(time.time())

    @staticmethod
    def time_stamp_13() -> int:
        # 获取13位的时间戳 精度是毫秒(ms)
        return int(round(time.time() * 1000))

    @staticmethod
    def day_stamp_13() -> int:
        # 获取以天为单位的时间戳
        return int(str(int(time.mktime(time.strptime(str(datetime.date.today()), '%Y-%m-%d'))))) * 10000

    @staticmethod
    def get_now(formation: str = None) -> str:
        formation = formation if formation else '%Y-%m-%d %H:%M:%S'
        return time.strftime(formation)

    @staticmethod
    def get_datetime_now() -> datetime.datetime:
        return datetime.datetime.now()

    @staticmethod
    def get_now_str(formation: str = None) -> str:
        formation = formation if formation else '%Y-%m-%d %H:%M:%S'
        return time.strftime(formation)

    @staticmethod
    def get_month_first_and_last_day(year=None, month=None,
                                     month_interval: int = 0) -> Tuple[datetime.date, datetime.date]:
        """
        获取指定某年某月的第一天和最后一天
        :param year: 年份，默认是本年，可传int或str类型
        :param month: 月份，默认是本月，可传int或str类型
        :param interval_month: 月份间隔，默认0是本月，<0是往前几个月，>0是往后几个月
        :return: firstDay: 当月的第一天，datetime.date类型
                  lastDay: 当月的最后一天，datetime.date类型
        """
        year = int(year) if year else datetime.date.today().year
        month = int(month) if month else datetime.date.today().month

        # 获取当月第一天的星期和当月的总天数
        first_day_week_day, month_range = calendar.monthrange(year, month)
        month_interval = month_interval + 1
        month_interval_func = relativedelta(months=month_interval)

        # 获取当月的第一天
        first_day = datetime.date(year=year, month=month, day=1)
        last_day = datetime.date(year=year, month=month, day=month_range)

        if month_interval < 0:
            first_day += month_interval_func
        elif month_interval > 0:
            last_day += month_interval_func
            _, month_range = calendar.monthrange(last_day.year, last_day.month)
            last_day = datetime.date(year=last_day.year, month=last_day.month, day=month_range)

        return first_day, last_day

    @staticmethod
    def timedelta(time: datetime, time_cycle_unit, size):
        if time_cycle_unit == TimeCycleUnit.MONTH:
            return time + relativedelta(months=size) \
                if size > 0 else time - relativedelta(months=abs(size))
        elif time_cycle_unit == TimeCycleUnit.WEEK:
            return time + relativedelta(weeks=size) \
                if size > 0 else time - relativedelta(weeks=abs(size))
        elif time_cycle_unit == TimeCycleUnit.DAY:
            return time + datetime.timedelta(days=size) \
                if size > 0 else time - datetime.timedelta(days=abs(size))
        else:
            assert f"无法计算间隔[{time}],TimeInterval[{time_cycle_unit},{size}]"

    @staticmethod
    def get_last_day(date, n: int) -> str:
        """
        本日期的上几天或下几天
        :param date:
        :param n: 正数为后几天，负数为上几天
        :return:
        """
        date_time = datetime.datetime.strptime(date, '%Y%m%d')
        last_time = date_time + datetime.timedelta(days=n)
        return last_time.strftime('%Y%m%d')

    @staticmethod
    def gen_dates(start: str, end: str) -> Iterable:
        """
        产生指定范围日期内的 日期信息、年月日、星期等信息
        :param start: 开始日期字符串
        :param end: 结束日期字符串
        """

        def fn(value: int):
            return f"0{value}" if value < 10 else f"{value}"

        dates = pd.DataFrame(pd.date_range(start=start, end=end))[0]
        for date in dates:
            # 年月日 2021 5 1
            year, month, day = date.year, date.month, date.day
            # 日期编码 20210501
            rq_id = f"{year}{fn(month)}{fn(day)}"
            # 星期 星期五
            day_of_week = date.dayofweek + 1
            yield rq_id, year, month, day, day_of_week

    @staticmethod
    def gen_time_combinations() -> Iterable:
        """
        产生一天的时间组合
        """

        def fn(value: int):
            return f"0{value}" if value < 10 else f"{value}"

        hours, minutes, seconds = 24, 60, 60
        for hour in range(hours):
            for minute in range(minutes):
                for second in range(seconds):
                    yield f"{fn(hours)}:{fn(minutes)}:{fn(seconds)}", hour, minute, second

    @staticmethod
    def get_every_day(begin_date, dates) -> List[str]:
        """
        begin_date在dates内的所有日期
        :param begin_date:
        :param dates:
        :return:
        """
        date_list = [begin_date]
        begin_date = datetime.datetime.strptime(begin_date, "%Y%m%d")
        for date in range(abs(dates)):
            if dates > 0:
                begin_date += datetime.timedelta(days=1)
                date_str = begin_date.strftime("%Y%m%d")
                date_list.append(date_str)
            else:
                begin_date -= datetime.timedelta(days=1)
                date_str = begin_date.strftime("%Y%m%d")
                date_list.append(date_str)
        return date_list

    @staticmethod
    def get_next_day(date, day) -> str:
        time = datetime.datetime.strptime(date, '%Y%m%d')
        res_day = time + datetime.timedelta(days=day)
        res = datetime.datetime.strftime(res_day, '%Y%m%d')
        return res

    @staticmethod
    def get_next_month(date) -> str:
        time = datetime.date(int(date[:4]), int(date[-2:]), 1)
        nex_month = time + datetime.timedelta(days=31)
        res = str(nex_month.year) + "{0:0=2d}".format(nex_month.month)
        return res


class DateTimeTrans:
    """ 日期时间格式转换工具类"""

    @staticmethod
    def date_format2(content: str) -> datetime.datetime:
        return datetime.datetime.strptime(content, "%Y-%m-%d")

    @staticmethod
    def date_format(content: str) -> datetime.datetime:
        """
        日期字符串转换为datetime格式
        :param content: 日期字符串 20210315
        :return: datetime对象

        >>> DateTimeTrans.date_format("20210214")
        Out[0]: datetime(2021, 2, 14, 0, 0)
        """
        try:
            year, month, day = int(content[:4]), int(content[4:6]), int(content[6:])
            return datetime.datetime.strptime(f"{year}-{month}-{day} 00:00:00", "%Y-%m-%d %H:%M:%S")
        except ValueError as e:
            # 处理无法解析日期字符串的情况
            print(f"Error parsing date: {e}")
            return None
        except AttributeError as e:
            # 处理无法进行切片操作的情况
            print(f"Error accessing content: {e}")
            return None
        except Exception as e:
            return datetime.datetime.today()

    @staticmethod
    def date_2_timestamp(date: datetime) -> int:
        """ datetime类型转时间戳

        >>> date = DateTimeTrans.date_format("20210214")
        >>> DateTimeTrans.date_2_timestamp(date)
        Out[0]: 1613232000
        """
        return int(time.mktime(date.timetuple()))

    @staticmethod
    def timestamp_2_date(timestamp: int) -> datetime.datetime:
        """ 时间戳转datetime类型
        >>> time_stamp = 1613232000
        >>> DateTimeTrans.timestamp_2_date(time_stamp)
        Out[0]: datetime(2021, 2, 14, 0, 0)
        """
        return datetime.datetime.fromtimestamp(timestamp)

    @staticmethod
    def to_date_time(time:Any):
        if type(time) == datetime.date:
            return datetime.datetime.combine(time, datetime.datetime.min.time())
        return time
