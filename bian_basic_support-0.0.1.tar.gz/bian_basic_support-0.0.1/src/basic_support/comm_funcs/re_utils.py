


import re
from typing import Tuple, List

def re_search_all(reg_str:str, text:str, max_match_times:int=-1)->List[Tuple[str,int,int]]:
    """正则搜索字符串获得所有结果，包含结果的文本和起止索引号
    Args:
        reg_str (str): 正则表达式文本
        text (str): 待搜索的文本
        max_match_times (int): 最大匹配次数，None或小于等于0表示不限次数
    Returns:
        List[Tuple[str,int,int]]: 结果列表，tuple格式：(匹配文本, 起始索引号，截止索引号)
    """
    l=[]
    base_idx = 0
    ret = re.search(reg_str, text)
    while ret is not None:
        match_str = ret.group()
        start_idx, end_idx = ret.span()
        if end_idx <= start_idx:
            break
        l.append((match_str, start_idx+base_idx, end_idx+base_idx))
        base_idx += end_idx
        text = text[end_idx:]
        ret = re.search(reg_str, text)
        if max_match_times is not None and max_match_times > 0:
            max_match_times -= 1
            if max_match_times == 0:
                break
    return l



re_escape_chars = [
    ".","^","$","*","+","?","[","]","|","{","}","(",")"
]
def str_re_escape(raw_str:str)->str:
    """将字符串中的正则转义字符进行转义
    Args:
        raw_str (str): 原始字符串

    Returns:
        str: 转义后的字符串
    """
    for esc_ch in re_escape_chars:
        s = f"\\{esc_ch}"
        raw_str = re.sub(s, s, raw_str)
    return raw_str

