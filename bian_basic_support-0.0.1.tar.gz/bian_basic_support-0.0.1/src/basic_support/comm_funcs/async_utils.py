#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: async_utils.py
@Description: 异步相关工具
@time: 2023/7/27 20:24
"""
from functools import wraps
from json import JSONDecodeError
from typing import Dict, Callable, OrderedDict

import aiohttp


async def _get_next(ait):
    try:
        asy_obj = await ait.__anext__()
        return False, asy_obj
    except StopAsyncIteration:
        return True, None


def iter_over_async(ait, loop):
    """
    异步转yield
    @param ait: 异步函数
    @param loop: 事件循环
    @return:
    """
    ait = ait.__aiter__()

    while True:
        done, asy_obj = loop.run_until_complete(_get_next(ait))
        if done:
            break
        yield asy_obj


async def asy_http_post(url: str, param_dic: Dict, encoding=None, call_back: Callable = None):
    """
    异步调用post请求
    @param url: url地址
    @param param_dic: 参数字典
    @param encoding: 编码
    @param call_back: 回调函数，对结果的处理
    """
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=param_dic) as response:
            if response.status == 200:
                async for data in response.content.iter_any():  # 每次接收已有的全部数据
                    # 处理流式数据
                    try:
                        end_data = data.decode(encoding) if encoding else data.decode()
                        yield call_back(end_data) if call_back else end_data
                    except JSONDecodeError as e:
                        # 在解码过程中出现异常，处理错误情况
                        print(f"JSON decode error: {e}")
                    except UnicodeDecodeError as e:
                        # 在解码数据时出现编码错误
                        print(f"Unicode decode error: {e}")
                    except Exception as e:
                        # 其他异常
                        print(f"Error: {e}")
            else:
                print("请求失败，状态码:", response.status)


def async_lru_cache(maxsize=32):
    """
    用于异步函数的 LRU 缓存装饰器
    """

    def decorator(func):
        cache = OrderedDict()

        def make_key(args, kwargs):
            return str(args) + str(sorted(kwargs.items()))

        @wraps(func)
        async def wrapper(*args, **kwargs):
            key = make_key(args, kwargs)
            if key in cache:
                cache.move_to_end(key)
                return cache[key]
            result = await func(*args, **kwargs)
            cache[key] = result
            if len(cache) > maxsize:
                cache.popitem(last=False)
            return result

        return wrapper

    return decorator
