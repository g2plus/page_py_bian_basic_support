#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: io_utils.py
@Description: io相关的工具
@time: 2023/10/31 8:59
"""
import contextlib
import os
import sys
from typing import List, Dict, Union
from dataclasses import dataclass, field
import pandas as pd


@dataclass
class RemoteConfig:
    hostname: str = field(default='127.0.0.1', metadata={"help": "url地址"})
    port: int = field(default=22, metadata={"help": "端口号"})
    username: str = field(default='root', metadata={"help": "用户名"})
    password: str = field(default='pwd', metadata={"help": "密码"})


class RemoteIoUtils:
    @contextlib.contextmanager
    @staticmethod
    def write_to_file(file: str, remote_cfg: RemoteConfig, mode: str = 'w'):
        import paramiko
        try:
            # 创建SSH客户端
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            # 连接到远程服务器
            client.connect(hostname=remote_cfg.hostname, port=remote_cfg.port, username=remote_cfg.username,
                           password=remote_cfg.password)

            # 使用SFTP协议获取文件内容
            sftp = client.open_sftp()
            remote_file = sftp.open(file, mode=mode)
            yield remote_file

            # 关闭SFTP会话和SSH客户端
            sftp.close()
            client.close()
        except Exception as e:
            print(f"Error: {e}")

    @contextlib.contextmanager
    @staticmethod
    def read_from_file(file: str, remote_cfg: RemoteConfig, mode: str = 'r'):
        import paramiko
        try:
            # 创建SSH客户端
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            # 连接到远程服务器
            client.connect(hostname=remote_cfg.hostname, port=remote_cfg.port, username=remote_cfg.username,
                           password=remote_cfg.password)

            # 使用SFTP协议获取文件内容
            sftp = client.open_sftp()
            remote_file = sftp.open(file, mode=mode)
            yield remote_file
            # 关闭SFTP会话和SSH客户端
            sftp.close()
            client.close()
        except Exception as e:
            print(f"Error: {e}")


@contextlib.contextmanager
def print_to_file(file: str, mode: str = 'w', encoding='utf-8', errors=None, newline=None, closefd=True):
    """
    将print重定向输出到文件
    :param file: 文件名
    :param mode: 读写模式
    :param encoding: 文件编码
    :param errors:
    :param newline:
    :param closefd:
    :return:
    """
    prefix, _ = os.path.split(file)
    if prefix and os.path.isdir(prefix) and not os.path.exists(prefix):
        os.makedirs(prefix)

    f = open(file=file, mode=mode, encoding=encoding, errors=errors, newline=newline, closefd=closefd)
    # 保存原来的sys.stdout
    original_stdout = sys.stdout

    # 将sys.stdout重定向到文件流
    sys.stdout = f
    yield

    # 恢复原来的sys.stdout
    sys.stdout = original_stdout
    f.close()


@contextlib.contextmanager
def write_to_file(file: str, mode: str = 'w', encoding='utf-8', errors=None, newline=None, closefd=True):
    f = open(file=file, mode=mode, encoding=encoding, errors=errors, newline=newline,
             closefd=closefd)
    yield f
    f.close()


@contextlib.contextmanager
def read_from_file(file: str, encoding='utf-8', errors=None, newline=None, closefd=True):
    f = open(file=file, mode='r', encoding=encoding, errors=errors, newline=newline,
             closefd=closefd)
    yield f
    f.close()


def dict_write_to_excel(datas: Union[List[Dict], Dict[str, List]], file_name: str):
    """
    将数据输出到excel
    :param datas:
    :param file_name:
    :return:
    """
    # 将JSON数据转换为DataFrame
    df = pd.DataFrame(datas)
    # 将DataFrame保存为XLS文件
    df.to_excel(file_name, index=False)


def reverse_readline(file_name: str, buf_size=8192, encoding='utf-8'):
    """
    反向读取txt文件
    A generator that returns the lines of a file in reverse order
    :param file_name: 文件路径
    :param buf_size: 缓存大小
    :param encoding: 文件编码
    """
    with open(file_name, 'r', encoding=encoding) as fh:
        # 定义文件片段
        segment = None
        offset = 0

        # 定位到文件末尾
        fh.seek(0, os.SEEK_END)
        # 获取文件大小
        file_size = remaining_size = fh.tell()

        while remaining_size > 0:
            offset = min(file_size, offset + buf_size)
            fh.seek(file_size - offset)
            buffer = fh.read(min(remaining_size, buf_size))
            remaining_size -= buf_size
            lines = buffer.split('\n')
            # The first line of the buffer is probably not a complete line so we'll save it and
            # append it to the last line of the next buffer we read
            if segment:
                # If the previous chunk starts right from the beginning of line do not concat the
                # segment to the last line of new chunk. Instead, yield the segment first
                if buffer[-1] != '\n':
                    lines[-1] += segment
                else:
                    yield segment
            segment = lines[0]
            yield from lines[1:][::-1]

        # Don't yield None if the file was empty
        if segment:
            yield segment


if __name__ == '__main__':
    remote_cfg = RemoteConfig(hostname='192.168.123.xx', password='xxx')

    import json

    file = r"/home/huangyc/huggingface/dataset/bge-m3-data/bge-m3-data/chinese/zh_NLI_data/hyc_test.jsonl"
    with RemoteIoUtils.write_to_file(file=file, remote_cfg=remote_cfg, mode='a') as out_f:
        for line in range(100):
            data = json.dumps({"key": line, "name": '黄'}, ensure_ascii=False)
            out_f.write(f"{data}\n")

    # file = r"/home/huangyc/huggingface/dataset/bge-m3-data/bge-m3-data/chinese/zh_NLI_data/ATEC_len-0-500.jsonl"
    with RemoteIoUtils.read_from_file(file=file, remote_cfg=remote_cfg) as in_f:
        for line in in_f:
            print(line)
