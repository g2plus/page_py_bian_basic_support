#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: data_utils.py
@Description: 数据处理常用工具
@time: 2022/12/13 10:42
"""
from typing import Iterable, Dict, List

import numpy as np
import pandas as pd
from basic_support.comm_classes.utils_class import Queue
from sklearn.metrics import confusion_matrix

pd.set_option('mode.chained_assignment', None)


def three_sigma(ser: pd.Series):
    """
    定义3σ法则识别异常值函数, 并用上下界填充异常值
    https://blog.csdn.net/master_hunter/article/details/124384870
        MAD异常值识别
        百分位异常值识别
        3sigma异常值识别
        Z-Score异常值识别
    """
    # 上界
    up_value = ser.mean() + 3 * ser.std()
    up_index = np.arange(ser.shape[0])[up_value < ser]
    # 下界
    down_value = ser.mean() - 3 * ser.std()
    down_index = np.arange(ser.shape[0])[down_value > ser]

    up_out_range, down_out_range = ser.iloc[up_index].index, ser.iloc[down_index].index

    ser.loc[up_out_range] = up_value
    ser.loc[down_out_range] = down_value
    return up_index, up_value, down_index, down_value


def cal_confusion_matrix(y_true, y_pred, label_lst=None):
    """
    计算混淆矩阵
    :param y_true:
    :param y_pred:
    :param label_lst:
    :return:
    """
    cm = confusion_matrix(y_true, y_pred, labels=label_lst)
    FP = cm.sum(axis=0) - np.diag(cm)
    FN = cm.sum(axis=1) - np.diag(cm)
    TP = np.diag(cm)
    TN = cm.sum() - (FP + FN + TP)

    # # Sensitivity, hit rate, recall, or true positive rate
    # TPR = TP / (TP + FN)
    # # Specificity or true negative rate
    # TNR = TN / (TN + FP)
    # # Precision or positive predictive value
    # PPV = TP / (TP + FP)
    # # Negative predictive value
    # NPV = TN / (TN + FN)
    # # Fall out or false positive rate
    # FPR = FP / (FP + TN)
    # # False negative rate
    # FNR = FN / (TP + FN)
    # # False discovery rate
    # FDR = FP / (TP + FP)

    precision = TP / (TP + FP)  # 查准率
    recall = TP / (TP + FN)  # 查全率
    f1_score = 2 * precision * recall / (precision + recall)
    precision[np.isnan(precision)] = 0.0
    recall[np.isnan(recall)] = 0.0
    f1_score[np.isnan(f1_score)] = 0.0
    return precision, recall, f1_score, cm


def split_samples(samples: Iterable, radio_cfg: Dict[str, int], shuffle: bool = False):
    # TODO 数据集划分
    pass


def get_max_partitions(arr: List[int], repeated_num: int = 0, limit: int = 100) -> List[List[int]]:
    """
    获取限定值下的索引列表
    :param arr: 长度列表
    :param repeated_num: 重复的窗口
    :param limit: 最大值限制
    :return:
    example:
        arr = [8, 8, 6, 3, 6, 5, 4, 5, 3, 2, 5, 7, 8, 34, 5, 33, 4, 5]
        limit = 20
        get_max_partitions(arr=arr, repeated_num=2, limit=20)
    [[0, 3], [1, 5], [3, 8], [6, 12], [10, 13], [11, 14], [12, 15], [13, 16], [14, 17], [15, 18]]
    """
    max_idx = len(arr)
    start_idx, end_idx = 0, 1
    res_idxs = []

    while end_idx < max_idx:
        range_sum = sum(arr[start_idx:end_idx])
        if range_sum >= limit:
            res_idxs.append([start_idx, end_idx])
            start_idx = max(end_idx - repeated_num, start_idx + 1)
        end_idx += 1
    if start_idx != end_idx:
        res_idxs.append([start_idx, end_idx])
    return res_idxs


def allocate_samples(categories: Dict[str, int], total_samples: int) -> Dict[str, int]:
    """
    理想的平衡分配策略，它首先尽可能地分配最少数量类别的样本，然后平均分配剩余的样本直到达到总样本数。这样可以保证样本分配尽可能均衡，同时考虑了每个类别的限制
    :param categories:
    :param total_samples:
    :return:
    example:
        # 类别和各自的数量
        categories = {'a': 7, 'b': 8, 'c': 11, 'd': 60}
        # 需要分配的总样本数
        total_samples = 40

        # 调用函数计算各类别的样本分配情况
        samples_allocation = allocate_samples(categories, total_samples)
        # 打印分配结果
        print(samples_allocation)
        >>> {'a': 7, 'b': 8, 'c': 11, 'd': 14}
    """
    # 获取每个类别的名称和数量
    category_names = list(categories.keys())
    category_counts = list(categories.values())
    # 排序，按数量从小到大排列，以便先分配数量小的类别
    sorted_indices = sorted(range(len(category_counts)), key=lambda x: category_counts[x])
    # 初始化每个类别的样本分配为0
    samples_per_category = [0] * len(categories)
    # 分配样本，先确保不超过各自类别的上限
    remaining_samples = total_samples
    max_up = total_samples // len(categories)
    for i in sorted_indices:
        # 计算能分配给当前类别的最大样本数
        max_allocatable = min(min(category_counts[i], remaining_samples), max_up)
        samples_per_category[i] = max_allocatable
        remaining_samples -= max_allocatable
    # 如果还有剩余样本，则从剩下的样本中均匀分配
    before_num = sum(samples_per_category)
    while remaining_samples > 0 and before_num < total_samples:
        before_num = sum(samples_per_category)
        for i in range(len(samples_per_category)):
            if remaining_samples > 0 and samples_per_category[i] < category_counts[i]:
                samples_per_category[i] += 1
                remaining_samples -= 1

    # 创建结果字典
    result = {category_names[i]: samples_per_category[i] for i in range(len(category_names))}
    assert sum(result.values())
    return result


if __name__ == '__main__':
    # 类别和各自的数量
    categories = {'a': 77, 'b': 78, 'c': 7, 'd': 60}
    # 需要分配的总样本数
    total_samples = 40

    # 调用函数计算各类别的样本分配情况
    samples_allocation = allocate_samples(categories, total_samples)
    # 打印分配结果
    print(samples_allocation)
