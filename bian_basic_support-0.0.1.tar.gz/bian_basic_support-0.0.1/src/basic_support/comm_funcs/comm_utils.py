# @Time    : 2020/7/30 15:24
# @Author  : YuQL
# @FileName: comm_utils.py
# @Software: PyCharm
"""
公共工具函数
"""

import base64
import hashlib
import itertools
import logging
import math
import operator
import os
import pickle as pk
import queue
import random
import re
import subprocess
import sys
import uuid
from bisect import bisect
from collections import Counter, deque
from itertools import accumulate, product
from itertools import groupby, count, islice
from itertools import tee
from pathlib import Path
from threading import Lock
from typing import List, Tuple, Dict, Any, Iterable, Callable, Iterator
from typing import Optional, Generator
from itertools import combinations

import dill
import yaml
from multiprocessing import cpu_count, Pool
import numpy as np
from basic_support.comm_classes.utils_class import ThreadingTee
import Levenshtein


def simple_cut_sent(para):
    para = re.sub('([。！;；？\?])([^”’])', r"\1\n\2", para)  # 单字符断句符
    para = re.sub('(\.{6})([^”’])', r"\1\n\2", para)  # 英文省略号
    para = re.sub('(\…{2})([^”’])', r"\1\n\2", para)  # 中文省略号
    para = re.sub('([。！;；？\?][”’])([^，。！;；？\?])', r'\1\n\2', para)
    # 如果双引号前有终止符，那么双引号才是句子的终点，把分句符\n放到双引号后，注意前面的几句都小心保留了双引号
    para = para.rstrip()  # 段尾如果有多余的\n就去掉它
    # 这里破折号、英文双引号等忽略，需要的再做些简单调整即可。
    return para.split("\n")


def find_min_edit_distance(a, b):
    """查找较长字符串(a)的所有子串中，与另一字符串(b)编辑距离最小的子串
    :param _type_ a: 较长字符串
    :param _type_ b: 待比较的另一字符串
    :return _type_: (距离最小子串,最小编辑距离,距离最小子串在a中的起始索引, 距离最小子串在a中的截止索引)
    """
    # 生成字符串a的所有子串  
    substrings = [
        (a[i:j], i, j)
        for i, j in combinations(range(len(a) + 1), 2)
        if abs(j - i - len(b)) < min(8, len(b) / 4)
    ]
    substrings.sort(key=lambda t: len(t[0]), reverse=True)  # 按长度降序排序

    min_edit_distance = float('inf')  # 初始化最小编辑距离为无穷大  
    min_substring = ''  # 初始化最小编辑距离的子串为空  

    sub_bg, sub_ed = 0, 0
    for substring, bg, ed in substrings:
        if abs(len(substring) - len(b)) >= min_edit_distance:
            continue
        edit_distance = Levenshtein.distance(substring, b)  # 计算编辑距离  
        if edit_distance < min_edit_distance:  # 如果找到更小的编辑距离  
            min_edit_distance = edit_distance  # 更新最小编辑距离  
            min_substring = substring  # 更新最小编辑距离的子串  
            sub_bg = bg
            sub_ed = ed

    return min_substring, min_edit_distance, sub_bg, sub_ed


def parall_process_data(data, func, degree=None):
    """
    多核并行处理数据
    :param data: 数据列表
    :param func: 处理函数
    :param degree: 并行度，默认为None表示cpu核数
    """
    if degree is None:
        degree = cpu_count()
    # 数据切分
    data_split = np.array_split(data, degree)  # 这里把数据按照核心数N，分成N份
    # 进程池
    pool = Pool(degree)
    # 数据分发 合并
    data = pool.map(func, data_split)  # 把数据，和要处理数据的函数，分别导入对应的进程池
    # 关闭进程池
    pool.close()
    # 执行完close后不会有新的进程加入到pool,join函数等待所有子进程结束
    pool.join()
    return data


def full2half(s):
    from six import unichr
    n = []
    # s = s.decode('utf-8')
    for char in s:
        num = ord(char)
        if num == 0x3000:
            num = 32
        elif 0xFF01 <= num <= 0xFF5E:
            num -= 0xfee0
        num = unichr(num)
        n.append(num)
    return ''.join(n)


def hash_text_by_content(text: str) -> int:
    return sum([ord(c) for c in text])


def detect_word_chaos_num(word: str) -> int:
    """检测给定文本中，乱码字符的个数
    Args:
        word (str): 待检测文本
    Returns:
        int: 乱码字符个数
    """
    cou = 0
    for ch in word:
        try:
            ch.encode("gb2312")
        except UnicodeEncodeError:
            cou += 1
    return cou


def del_chaos_chars(s: str) -> str:
    """删除字符串的中文乱码字符
    :param str s: _description_
    :return str: _description_
    """
    ch_lst = []
    for ch in s:
        try:
            ch.encode("gb2312")
            ch_lst.append(ch)
        except UnicodeEncodeError:
            pass
    return "".join(ch_lst)


def if_contain_chaos(word: str) -> bool:
    """判断指定文本是否包含乱码字符
    Args:
        word (str): 待检测的文本
    Returns:
        bool: 包含乱码则返回True，否则返回False
    """
    try:
        word.encode("gb2312")
    except UnicodeEncodeError:
        return True
    return False


def calc_chaos_ch_cou(s: str) -> int:
    """计算字符串中包含的乱码字符数量
    :param str s: _description_
    :return int: _description_
    """
    cou = 0
    for ch in s:
        if if_contain_chaos(ch):
            cou += 1
    return cou


def detect_chinese_ch_cou(word: str) -> int:
    """
    检测文本包含的中文字符数量
    """
    cou = 0
    for ch in word:
        if '\u4e00' <= ch <= '\u9fff':
            cou += 1
    return cou


def calc_chinese_rate(content: str) -> float:
    """计算一段文本中的中文非标点符号字符占比"""
    chinese_cou = detect_chinese_ch_cou(content)
    return float(chinese_cou) / float(len(content))


def obj_to_dict(obj):
    """
    生成python对象对应的字典
    :param obj:
    :return:
    """
    obj_dict = {}
    for name in dir(obj):
        value = getattr(obj, name)
        if not name.startswith('__') and not callable(value):
            obj_dict[name] = value
    return obj_dict


def obj_to_dict_dataclasses(obj, dict_factory=dict):
    from dataclasses import _asdict_inner
    return _asdict_inner(obj, dict_factory=dict_factory)


def copy_obj_attrs(from_obj, to_obj, attr_filter_func=None):
    """
    拷贝对象的属性
    :param from_obj: 来源对象
    :param to_obj: 目标对象
    :param attr_filter_func: 属性过滤函数，入参为属性名，如果输出False则对应的属性会被过滤掉
    :return:
    """
    d_attr = {
        k: v
        for k, v in vars(from_obj).items()
        if attr_filter_func is None or attr_filter_func(k)
    }
    for k, v in d_attr.items():
        setattr(to_obj, k, v)
    return to_obj


def shuffle_to_head_sub_lst(all_lst, head_size):
    """
    对头部子列表洗牌（在整个列表范围内洗，洗到头部子列表中）
    :param all_lst:
    :param head_size:
    :return:
    """
    real_head_size = min(head_size, len(all_lst))
    max_idx = len(all_lst) - 1
    for i in range(real_head_size):
        exchange_idx = random.randint(0, max_idx)
        all_lst[i], all_lst[exchange_idx] = all_lst[exchange_idx], all_lst[i]


def uniform_n_split_lst(lst: List, n: int = None, batch_size: int = None):
    """
    将指定列表均匀分割为n个小列表
    :param lst: 待分割的大列表
    :param n: 指定份数n
    :param batch_size: 指定每份数量(n和batch_size有且只能有一个None)
    :return:
    """
    if n is not None and batch_size is None:
        step = math.ceil(len(lst) / n)
    elif batch_size is not None and n is None:
        step = batch_size
    else:
        raise Exception("均匀分割异常: n和batch_size参数有且只能有一个None")
    return [lst[i:i + step] for i in range(0, len(lst), step)]


def dumps_obj(obj):
    bts = dill.dumps(obj)
    b64_bts = base64.b64encode(bts)
    return str(b64_bts, encoding="utf8")


def dump_obj(obj, file_path):
    """
    保存对象为 pkl文件
    """
    with open(file_path, "wb") as f:
        dill.dump(obj, f)


def load_obj(file_path):
    """
    加载 pkl对象
    """
    with open(file_path, "rb") as f:
        try:
            return dill.load(f)
        except Exception:
            return pk.load(f)


def loads_obj(obj_str):
    db_bts = base64.b64decode(obj_str)
    try:
        return dill.loads(db_bts)
    except Exception:
        return pk.loads(db_bts)


def is_overlap(begin_1, length_1, begin_2, length_2):
    return (begin_1 <= begin_2 <= begin_1 + length_1 - 1) or (begin_2 <= begin_1 <= begin_2 + length_2 - 1)


def simple_topological_order(node_parent_tuple: List[Tuple[any, any]]):
    """
    简化版的拓扑排序
    @param node_parent_tuple:　边列表（[<id,pid>,<id,pid>...]）　例子: [(7, 0), (2, 7), (3, 7), (4, 2), (5, 7), (6, 4)]
    @return: 排好序的原始索引列表　例子: [0, 1, 2, 4, 3, 5]
    """
    node_parent_tuple_cp = [(v[0], v[1], idx) for idx, v in enumerate(node_parent_tuple)]
    # 先排序，保证相同输入出来的结果一致
    node_parent_tuple_cp.sort(key=lambda v: (v[0], v[1]))

    # 初始化状态
    nodes_queue = queue.Queue()
    tmp_node_lst = []
    for _, node_tup in enumerate(node_parent_tuple_cp):
        for _, s_node in enumerate(node_parent_tuple_cp):
            if s_node[0] == node_tup[1] and not s_node is node_tup:
                break
        else:
            nodes_queue.put(node_tup)
            tmp_node_lst.append(node_tup)
    [node_parent_tuple_cp.remove(node) for node in tmp_node_lst]

    # 遍历查找
    sorted_index_lst = []
    while not nodes_queue.empty():
        # logger.debug(f'当前队列: {nodes_queue.queue}')
        dp_node = nodes_queue.get()
        # logger.debug(f'出队元素: {dp_node}')
        sorted_index_lst.append(dp_node[2])
        tmp_node_lst = []
        for _, node_tup in enumerate(node_parent_tuple_cp):
            for _, s_node in enumerate(node_parent_tuple_cp):
                if s_node[0] == node_tup[1] and not s_node is node_tup:
                    break
            else:
                nodes_queue.put(node_tup)
                tmp_node_lst.append(node_tup)
        # logger.debug(f'选中元素: {tmp_node_lst}')
        [node_parent_tuple_cp.remove(r) for r in tmp_node_lst[::-1]]
        # logger.debug(f'剩余元素: {node_parent_tuple_cp}\n')

    assert len(sorted_index_lst) == len(node_parent_tuple), '存在回路'
    print(sorted_index_lst)
    return sorted_index_lst


def check_cut_right(ori_lst: List, other_lst: List):
    """
    检查切词结果正确性
    """
    res = list(accumulate(map(len, other_lst), operator.add))
    res.pop()
    res.insert(0, 0)
    dic = dict(zip(res, other_lst))
    fs = all(int(ori.split(' ', 2)[1]) in res for ori in ori_lst)
    return fs and all(dic[int(ori.split(' ', 2)[1])] == ori.split(' ', 2)[2] for ori in ori_lst)


def check_proper_subset(ori_lst: List, other_lst: List):
    """
    判断两个列表是不是只是顺序不一样
    """
    return Counter(other_lst) == Counter(ori_lst)


# 获取32位uuid
def gen_uuid32(): return str(uuid.uuid4()).replace('-', '')


def gen_uuid32_name_space(*names):
    """
    带业务的uuid
    :param names: 业务词列表
    """
    # return str(uuid.uuid5(uuid.NAMESPACE_DNS, ''.join(map(str, names)))).replace('-', '')
    return name_uuid_from_bytes(*names)


def name_uuid_from_bytes(*names):
    """
    基于字节的带业务uuid
    :param names:业务词列表
    """
    name = bytes(''.join(map(str, names)), 'utf-8')
    md5_hash = hashlib.md5(name).digest()
    md5_hash = bytearray(md5_hash)
    md5_hash[6] &= 0x0f  # clear version
    md5_hash[6] |= 0x30  # set to version 3
    md5_hash[8] &= 0x3f  # clear variant
    md5_hash[8] |= 0x80  # set to IETF variant
    return str(uuid.UUID(bytes=bytes(md5_hash))).replace('-', '')


def find_all_file(path: str) -> Generator[str, None, None]:
    for root, dirs, files in os.walk(path):
        for f in files:
            fullname = os.path.join(root, f)
            yield fullname


def str2bool(value): return value if isinstance(value, bool) else value.lower() in ("yes", "true", "t", "1")


def iter_slice_tool(iterator: Iterable, batch_size: int = 5):
    """
    生成器 访问工具方法 支持每次取 n个元素
    :param iterator: 数据生成器
    :param batch_size: 批大小(<0 为不分批 )
    :return:
    """
    if batch_size < 0:
        yield from groupby(iterator, key=lambda _, c=count(): 0)
    else:
        yield from groupby(iterator, key=lambda _, c=count(): next(c) // batch_size)


def iter_uniform_tool(iterator: Iterable, n: int = 2, start: int = 0, stop: int = sys.maxsize):
    """
    生成器 n等均分切片工具方法
    :param iterator: 可迭代对象
    :param n: n等分
    :param start: 可迭代对象起始位置
    :param stop: 可迭代对象结束位置
    """
    yield from (islice(it, start + idx, stop, n) for idx, it in enumerate(threading_tee(iterator, n)))


def gen_split_index(sample_num: int, batch_size: int = None, batch_num: int = None):
    """
    返回列表遍历的索引迭代器
    @param sample_num: 样本总数
    @param batch_size: 每个批次的样本量
    @param batch_num: 多少个批次
    batch_size和batch_num, batch_size优于batch_num, 当且仅当batch_size=None时batch_num才生效
    Example 1:
        list(gen_split_index(sample_num=22, batch_size=5))
        Out[80]: [(0, 5), (5, 10), (10, 15), (15, 20), (20, 25)]
    Example 2:
        list(gen_split_index(sample_num=22, batch_num=4))
        Out[81]: [(0, 6), (6, 12), (12, 18), (18, 24)]
    """
    counter = 0
    if batch_num:
        import math
        batch_size = math.ceil(sample_num / batch_num)
    while True:
        if batch_size * (counter + 1) >= sample_num:
            yield batch_size * counter, batch_size * (counter + 1)
            break
        yield batch_size * counter, batch_size * (counter + 1)
        counter = counter + 1


def jump_iter_tool(iterator: Iterable, jump: int = 1):
    """
    跳跃获取两个值
    例子:
        def fn():
            yield from range(10)
        a = fn()
        list(jump_iter_tool(a, jump=2))

        Out[14]: [(0, 2), (1, 3), (2, 4), (3, 5), (4, 6), (5, 7), (6, 8), (7, 9)]

    @param iterator: 可迭代对象
    @param jump: 跳跃幅度
    @return: 两个值
    """
    iterator = iter(iterator)
    iter_0, iter_1 = tee(iterator, 2)
    while jump > 0:
        try:
            next(iter_1)
            jump = jump - 1
        except:
            return

    while True:
        try:
            b = next(iter_1)
            a = next(iter_0)
            yield a, b
        except:
            return


def list_flat(deep_list, ignore_types=(str, bytes)) -> List:
    """
    列表嵌套展平为一维列表
    @param deep_list: 嵌套列表
    @param ignore_types: 不做展平的类型
    @rtype: 一维列表
    """
    for element in deep_list:
        if isinstance(element, list) and not isinstance(element, ignore_types):
            yield from list_flat(element, ignore_types=ignore_types)
        else:
            yield element


def map_flat(deep_map, full_key: bool = True) -> Dict:
    """
    字典嵌套展平为一维字典
    @param deep_map: 嵌套字典
    @param full_key: 是否使用完整的key
    @rtype: 一维字典
    """
    for key, value in deep_map.items():
        if isinstance(value, dict):
            for k, v in map_flat(value, full_key):
                yield (f'{key}_{k}', v) if full_key else (k, v)
        else:
            yield key, value


def string_to_raw(string_: str):
    raw_ = r"%s" % repr(string_)
    return raw_[1:-1]


def read_batch_data(data_gen, lock, batch_size):
    res = []
    with lock:
        for data in data_gen:
            res.append(data)
            if len(res) >= batch_size:
                return res
    return res


def yield_batch_helper(data_gen, lock, batch_size=2000):
    """
    包装单条迭代器为batch方式
    """

    def yield_batch_kg():
        while 1:
            res = read_batch_data(data_gen, lock, batch_size)
            if len(res) == 0:
                break
            yield res

    return yield_batch_kg


def vertical_slice(data: List[Any]) -> Tuple[Any]:
    return zip(*data)


def list_bins_to_interval(bins: List[int], left_close=True, right_close=False):
    if len(bins) < 2:
        raise Exception("bins列表长度不得少于2！")
    from interval import Interval
    result = []
    for i in range(len(bins) - 1):
        result.append(Interval(bins[i], bins[i + 1], lower_closed=left_close, upper_closed=right_close))
    return result


def parse_string(string: str, parser) -> Optional[Dict]:
    """
    from parse import Parser
    :param string:
    :param parser: Parser实例
    :return:
    """

    result = parser.parse(string)
    if not result:
        return None
    dict_, list_ = result.named, result.fixed
    return list_ if list_ else dict_


def cal_level(score: float, breakpoints: Iterable, name_codes: List):
    """
    二分查找 计算分数等级
    示例：
        obj = cal_level(score=78, breakpoints=(60, 70, 80, 90), name_codes='FDCBA')
    :param score: 得分
    :param breakpoints: 分值区间
    :param name_codes: 各区间对应结果
    :return: 该分值的对应结果
    """
    return name_codes[bisect(breakpoints, score)]


def generate_hyper_parameter(parameters: Dict) -> Generator:
    """
    从字典产生 超参数 组合
    generate hyper parameters from dict
    :param parameters:
    parameters = {
        'parameter1':[1,2, ..., n1],
        ...
        'parameter5':[1,2, ..., n9]
    }
    :yield: parameter = {
        'parameter1': x1,
        ...
        'parameter5': x9
    }
    """
    for parameter in product(*parameters.values()):
        yield {k: v for k, v in zip(parameters.keys(), parameter)}


def split_by_udf(pattern, reserve, text: str) -> Iterable:
    """
    按约束分隔字符串，保留自己不希望被切开的部分
        example: 装修开始后(刘达经常来监工,认真地检查每一处细节),简直到了吹毛求疵的地步,大成苦不堪言
        output: 装修开始后((刘达经常来监工,认真地检查每一处细节))
                简直到了吹毛求疵的地步
                大成苦不堪言
    :param pattern: 分隔的正则
    :param reserve: 保留的正则(保证该部分不会被切开)
    :param text: 文本
    """
    finds = list(re.finditer(reserve, text))
    for find in finds:
        text = text.replace(find.group(), f"@{find.span()[0]}-{find.span()[1]}@")

    for sen in re.split(pattern, text):
        for find in finds:
            sen = re.sub(f"@{find.span()[0]}-{find.span()[1]}@", find.group(), sen)
        yield sen


def threading_tee(iterator: Iterable, n: int = 2):
    """tuple of n independent thread-safe iterators"""
    lock = Lock()
    return tuple(ThreadingTee(tee_obj, lock) for tee_obj in itertools.tee(iterator, n))


def sort_by_group(*args, key_fun: Callable):
    """
    多个列表联合排序
    :param args: 一系列的列表
    :param key_fun: 合并排序规则
    :return:
    example:
        a = [random.randint(0, 10) for _ in range(5)]
        b = [random.randint(10, 20) for _ in range(5)]
        ta, tb = sort_by_group(a, b, key_fun=lambda k: k[0])
        print(a, b)
        print(ta, tb)
    output:
        [5, 6, 7, 7, 3] [17, 13, 11, 11, 19]
        [3, 5, 6, 7, 7] [19, 17, 13, 11, 11]
    """
    return map(list, zip(*sorted(zip(*args), key=key_fun)))


def get_project_root_path(project_name: str) -> str:
    cur_path = os.path.abspath(os.path.dirname(__file__))
    root_path = cur_path[:max(
        cur_path.find(project_name),
        cur_path.find(project_name + "\\"),
        cur_path.find(project_name + "/")
    ) + len(project_name) + 1]
    return root_path


def subprocess_call(*popenargs, timeout=None, **kwargs):
    """Run command with arguments.  Wait for command to complete or
    timeout, then return the returncode attribute.

    The arguments are the same as for the Popen constructor.  Example:

    retcode, process_id = subprocess_call(["ls", "-l"])
    返回状态码和进程号
    """
    with subprocess.Popen(*popenargs, **kwargs) as p:
        try:
            return p.wait(timeout=timeout), p.pid
        except:  # Including KeyboardInterrupt, wait handled that.
            p.kill()
            # We don't call p.wait() again as p.__exit__ does that for us.
            raise


def script_run_helper(command_lst: List[str], shell: bool = True, pass_error: bool = False,
                      kill_history_cmd: bool = True, parallel: bool = False):
    """
    脚本执行器
    :param command_lst: 指令列表
    :param logger:
    :param shell: 如果shell为True，那么指定的命令将通过shell执行。
                  如果我们需要访问某些shell的特性，如管道、文件名通配符、环境变量扩展功能，这将是非常有用的。
                  当然，python本身也提供了许多类似shell的特性的实现
                  如glob、fnmatch、os.walk()、os.path.expandvars()、os.expanduser()和shutil等。
    :param pass_error: 是否跳过异常脚本
    :param kill_history_cmd: 杀死所有command_lst执行中的进程，保证不影响下次执行
    :param parallel: 是否并行执行(暂时没有实现)
    """
    logger = logging.getLogger(__name__)
    command_and_pids = []
    for idx, command in enumerate(command_lst):
        logger.info(f"【{idx}】开始执行, 当前指令为: {command}")
        try:
            if command.strip().startswith('cd '):
                os.chdir(command[3:])
            else:
                # 在基于POSIX的系统中，返回码0表示成功，而1到255表示其他任何东西。这些退出代码由机器脚本解释，以评估成功和失败的事件
                retcode, process_id = subprocess_call(command, shell=shell)
                if retcode == 0 and command.strip().startswith('nohup'):
                    command_and_pids.append((command, retcode, process_id))
                logger.info(f"【{idx}】当前retcode为: {retcode}, 进程号为: {process_id}")
                if retcode != 0 and not pass_error:
                    logger.exception(f"【{idx}】异常终止, 当前指令为: {command}\n")
                    command_and_pids.append((command, retcode, process_id))

                    if kill_history_cmd:
                        logger.info(f"任务中途出现异常, 开始杀死所有后台和失败的进程\n{command_and_pids}")
                        for cmd, retcode, pid in command_and_pids:
                            subprocess.call(f"kill -9 {pid}", shell=True)
                        logger.info(f"任务清除完成")
                    break
        except Exception as e:
            if pass_error:
                logger.exception(f"【{idx}】执行跳过\n")
            else:
                logger.exception(f"【{idx}】异常终止, 当前指令为: {command}\n{e}\n")
                break
        finally:
            logger.info(f"【{idx}】结束执行, 当前指令为: {command}\n")
    logger.info('所有指令执行 结束')


def platform():
    """ 获取当前操作系统类型 """
    import platform
    return platform.system().lower()


def is_linux():
    return platform() == 'linux'


def seq_sliding_window(sequence: Iterable, window_size: int = 7, step: int = 3, keep_last: bool = True) -> List[List]:
    """
    序列划窗函数
    :param sequence: 可迭代对象
    :param window_size: 窗口大小
    :param step: 步长
    :param keep_last: 是否保留最后一批(注意: 最后一批的长度小于window_size)
    :return: 每个窗口的list结果集
    """
    d_queue = deque(maxlen=window_size)
    for seq in sequence:
        d_queue.append(seq)
        if len(d_queue) == window_size:
            yield list(d_queue)
            for _ in range(step):
                if len(d_queue) > 0:
                    d_queue.popleft()
    if keep_last and d_queue:
        yield list(d_queue)


def _get_dict_values(dic: Dict, *field):
    return tuple(dic[f] for f in field)


def remove_duplicates_lst_dict(itr: Iterable, *field_to_check):
    """
    移除list[dict]中 重复的记录
    :param itr:
    :param field_to_check:
    :return:
    """
    seen = set()
    return (it for it in itr if not ((v := _get_dict_values(it, *field_to_check)) in seen or seen.add(v)))


def _walk_to_root(path: str) -> Iterator[str]:
    """
    Yield directories starting from the given directory up to the root
    """
    if not os.path.exists(path):
        raise IOError('Starting path not found')

    if os.path.isfile(path):
        path = os.path.dirname(path)

    last_dir = None
    current_dir = os.path.abspath(path)
    while last_dir != current_dir:
        yield current_dir
        parent_dir = os.path.abspath(os.path.join(current_dir, os.path.pardir))
        last_dir, current_dir = current_dir, parent_dir


def find_file_or_folder(filename: str = '.env', raise_error_if_not_found: bool = False, usecwd: bool = False,
                        is_file: bool = True) -> Path:
    """
    Search in increasingly higher folders for the given file
    :param filename:
    :param raise_error_if_not_found:
    :param usecwd:
    :param is_file: 为True时，搜索的是文件，反之为文件夹
    :return: Returns path to the file or folder if found, or an empty string otherwise
    """

    def _is_interactive():
        """ Decide whether this is running in a REPL or IPython notebook """
        main = __import__('__main__', None, None, fromlist=['__file__'])
        return not hasattr(main, '__file__')

    if usecwd or _is_interactive() or getattr(sys, 'frozen', False):
        # Should work without __file__, e.g. in REPL or IPython notebook.
        path = os.getcwd()
    else:
        # will work for .py files
        frame = sys._getframe()
        current_file = __file__

        while frame.f_code.co_filename == current_file:
            assert frame.f_back is not None
            frame = frame.f_back
        frame_filename = frame.f_code.co_filename
        path = os.path.dirname(os.path.abspath(frame_filename))

    for dirname in _walk_to_root(path):
        check_path = os.path.join(dirname, filename)

        if (is_file and os.path.isfile(check_path)) or (not is_file and os.path.isdir(check_path)):
            return Path(check_path)

    if raise_error_if_not_found:
        raise IOError('File not found')

    return Path('.')


def find_root_path_by_resources() -> Path:
    """ 根据resources文件找项目根目录 """
    return find_file_or_folder(filename='resources', is_file=False, usecwd=True).parent


def _merge_dicts(dict1, dict2):
    for key, value in dict2.items():
        if isinstance(value, dict) and key in dict1 and isinstance(dict1[key], dict):
            _merge_dicts(dict1[key], value)
        else:
            dict1[key] = value


def merge_nested_dicts(*dicts):
    """ 多个字典合并, 后面的覆盖前面的 """
    result = {}
    for d in dicts:
        if d is not None:
            _merge_dicts(result, d)
    return result


def read_yaml(yaml_path: str) -> Dict:
    """ 读取yaml """
    assert os.path.exists(yaml_path), f'yaml文件[{yaml_path}]路径不存在'
    with open(yaml_path, 'r', encoding='utf-8') as f:
        yaml_config = yaml.safe_load(f.read())
    return yaml_config
