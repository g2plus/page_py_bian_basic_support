#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: assert_utils.py
@Description: 
@time: 2024/7/29 14:40
"""
from typing import Dict


class Assert:

    @staticmethod
    def has_text(c: str, message: str = None):
        assert c and len((c.strip())) > 0, message or f"字符内容[{message}]不能为空"

    @staticmethod
    def not_empty(c, message: str = None):
        assert c and len(c) > 0, message or f"集合[{message}]必须有元素"

    @staticmethod
    def include(c: Dict, keys, c_name):
        for k in keys:
            assert k in c, f"集合[{c_name}]没有：[{k}]"

    @staticmethod
    def gt_len(obj, length, message: str = None):
        assert obj and len(obj) > length, message or f"集合[{message}]长度需要 >{length}"
