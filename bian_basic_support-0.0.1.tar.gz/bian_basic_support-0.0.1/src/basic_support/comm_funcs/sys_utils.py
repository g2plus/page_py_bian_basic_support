#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: sys_utils.py
@Description: 
@time: 2025/6/12 14:23
"""

import csv
import io
import os.path
import subprocess
import sys
from dataclasses import dataclass
from typing import List

from basic_support.comm_funcs.comm_utils import is_linux
from basic_support.comm_funcs.io_utils import read_from_file, write_to_file
from basic_support.logger.logger_config import logger


@dataclass
class RunningScript:
    """封装单个运行脚本的信息"""
    image_name: str
    pid: int
    session_name: str
    session_num: int
    mem_usage: str
    command_line: str

    @classmethod
    def from_ps_line(cls, line: str):
        parts = line.split(maxsplit=7)
        return cls(image_name=parts[0], pid=int(parts[1]), session_name=parts[2], session_num=int(parts[3]),
                   mem_usage=parts[4], command_line=parts[7])


class BaseRunningScriptFinder:
    def __init__(self, keyword: str):
        self.keyword = keyword

    def find_running_scripts(self) -> List[RunningScript]:
        raise NotImplementedError

    def display_results(self):
        scripts = self.find_running_scripts()
        if scripts:
            logger.debug(f"发现以下包含关键词 '{self.keyword}' 的正在运行的脚本：")
            for script in scripts:
                logger.debug(script)
        else:
            logger.debug(f"未发现包含关键词 '{self.keyword}' 的正在运行的脚本。")

    def kill_processes(self, pids: List[int]):
        """子类实现：根据进程号终止进程"""
        raise NotImplementedError


# ✅ Linux 子类实现
class LinuxRunningScriptFinder(BaseRunningScriptFinder):
    def find_running_scripts(self) -> List[RunningScript]:
        try:
            result = subprocess.run(
                ['ps', '-ef'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            lines = result.stdout.splitlines()
            matched_lines = [line for line in lines if self.keyword in line and 'grep' not in line]
            return [RunningScript.from_ps_line(line) for line in matched_lines]
        except Exception as e:
            logger.debug(f"[Linux] 查找失败: {e}")
            return []

    def kill_processes(self, pids: List[int]):
        for pid in pids:
            try:
                subprocess.run(['kill', '-9', str(pid)], check=True)
                logger.debug(f"[Linux] 已成功终止进程 PID: {pid}")
            except subprocess.CalledProcessError:
                logger.debug(f"[Linux] 终止进程失败 PID: {pid}")


# ✅ Windows 子类实现
class WindowsRunningScriptFinder(BaseRunningScriptFinder):
    def find_running_scripts(self) -> List[RunningScript]:
        try:
            cmd = [
                'powershell', '-Command',
                'Get-CimInstance Win32_Process | '
                'Select-Object ProcessId,Name,SessionId,CommandLine | '
                'ConvertTo-Csv -NoTypeInformation'
            ]
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            output = result.stdout

            scripts = []
            reader = csv.DictReader(io.StringIO(output))
            for row in reader:
                cmdline = row.get("CommandLine") or ""
                if self.keyword.lower() in cmdline.lower():
                    script = RunningScript(
                        image_name=row.get("Name", ""),
                        pid=int(row.get("ProcessId", 0)),
                        session_name="N/A",
                        session_num=int(row.get("SessionId", 0)),
                        mem_usage="N/A",
                        command_line=cmdline.strip()
                    )
                    scripts.append(script)
            return scripts
        except Exception as e:
            logger.debug(f"[Windows] 查找失败: {e}")
            return []

    def kill_processes(self, pids: List[int]):
        for pid in pids:
            try:
                subprocess.run(['taskkill', '/PID', str(pid), '/F'], check=True)
                logger.debug(f"[Windows] 已成功终止进程 PID: {pid}")
            except subprocess.CalledProcessError:
                logger.debug(f"[Windows] 终止进程失败 PID: {pid}")


# 跨平台选择器
class CrossPlatformRunningScriptFinder:
    def __init__(self, keyword: str):
        self.keyword = keyword
        self.finder = self._select_finder()

    def _select_finder(self) -> BaseRunningScriptFinder:
        if sys.platform.startswith("linux"):
            return LinuxRunningScriptFinder(self.keyword)
        elif sys.platform.startswith("win32"):
            return WindowsRunningScriptFinder(self.keyword)
        else:
            raise NotImplementedError(f"不支持的操作系统：{sys.platform}")

    def find_running_scripts(self) -> List[RunningScript]:
        return self.finder.find_running_scripts()

    def display_results(self):
        self.finder.display_results()


def gen_script(script: str, env_name: str = "gpt310"):
    """
    生成脚本
    :param script:
    :param env_name:
    :return:
    """
    script_name = script.split('.')[0]
    out_file_name = f'run_{script_name}.sh'
    with write_to_file(out_file_name) as out_f:
        with read_from_file(os.path.join('sources', 'run_view.sh')) as in_f:
            file_content = in_f.read()

            file_content = file_content.replace('ENV_NAME="gpt310"', f'ENV_NAME="{env_name}"')
            file_content = file_content.replace('LOG_FILE="log_run.log"', f'LOG_FILE="log_{script_name}.log"')
            file_content = file_content.replace('PYTHON_SCRIPT="run_stock_view.py"', f'PYTHON_SCRIPT="{script}"')
            file_content = file_content.replace('PID_FILE="run_stock_view.pid"', f'PID_FILE="run_{script_name}.pid"')

            out_f.write(file_content)

    if is_linux():
        # 获取当前文件权限
        current_permissions = os.stat(out_file_name).st_mode

        # 添加执行权限
        # 所有者、组用户和其他用户都添加执行权限
        new_permissions = current_permissions | 0o111

        # 修改文件权限
        os.chmod(out_file_name, new_permissions)

    logger.info(f"生成脚本完成: {out_file_name}")


if __name__ == "__main__":
    finder = CrossPlatformRunningScriptFinder("sys_utils")
    res = finder.find_running_scripts()
    logger.debug(res)
