# @Time    : 2020/7/28 17:09
# @Author  : YuQL
# @FileName: __init__.py.py
# @Software: PyCharm
"""
公共函数模块，存放用于复用的功能函数
"""