#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: mail_utils.py
@Description: 邮件相关的工具函数
@time: 2024/7/8 13:50
"""
import copy
import time
import traceback
from functools import wraps

from basic_support.comm_classes.mail_tool import QQMailTool, Message
from basic_support.logger.logger_config import logger


def mail_to_function(mail_tool: QQMailTool, message: Message):
    """
    邮件发送的装饰器
    :param mail_tool: 邮件发送实例对象
    :param message: 消息
    :return:
    """

    def inner(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()

            try:
                result = func(*args, **kwargs)
                end = time.time()

                # 消息装饰，添加执行时间和主题带标识
                inner_message = copy.deepcopy(message)
                run_msg = f'[{func.__name__}]执行结束, 耗时{round(end - start, 4)}s'
                inner_message.subject = f"[成功]{inner_message.subject}"
                inner_message.content = f"{inner_message.content}\n\n{run_msg}"

                # 邮件发送
                resp = mail_tool.send(message=inner_message)
                logger.info(f"发送{'成功' if resp else '失败'}")
            except Exception as e:
                end = time.time()

                # 消息装饰，添加执行时间和主题带标识
                inner_message = copy.deepcopy(message)
                run_msg = f'[{func.__name__}]执行结束, 耗时{round(end - start, 4)}s'
                inner_message.subject = f"[失败]{inner_message.subject}"
                inner_message.content = f"{inner_message.content}\n\n{run_msg}\n\n异常信息如下: {traceback.format_exc()}"

                resp = mail_tool.send(message=inner_message)
                logger.info(f"发送{'成功' if resp else '失败'}")
                raise e
            return result

        return wrapper

    return inner
