# @Time    : 2020/8/3 15:08
# @Author  : YuQL
# @FileName: annotations.py
# @Software: PyCharm
"""
公共注解
"""

from basic_support.logger.logger_config import logger


def logged(class_):
    """ 类级别日志记录器装饰器 """
    class_.logger = logger
    return class_
