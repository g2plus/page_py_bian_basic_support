#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: inspect_utils.py
@Description: inspect相关工具
@time: 2024/1/30 11:04
"""
import pkgutil
import inspect
import importlib
from typing import Set, List, Tuple


class InspectUtils:

    @staticmethod
    def get_path_and_cls_name(cls: type) -> Tuple[str, str]:
        cls_path = inspect.getfile(cls)
        cls_qualname = cls.__qualname__
        return cls_path, cls_qualname

    @staticmethod
    def find_classes_in_package(package_name: str, filter_cls: Set[type] = None) -> List[type]:
        """
        递归地查找给定包中定义的所有类
        :param package_name: 包名
        :param filter_cls: 需要保留下的类的
        :return:
        """
        classes = set()
        seen_modules = set()  # 保存已经检查过的模块
        package = importlib.import_module(package_name)

        cls_qualname_infos = [f"{'->'.join(InspectUtils.get_path_and_cls_name(cls))}" for cls in filter_cls]

        for importer, modname, ispkg in pkgutil.walk_packages(package.__path__, package.__name__ + '.'):
            if modname not in seen_modules:  # 检查模块是否已经检查过
                seen_modules.add(modname)
                module = importlib.import_module(modname)
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    # 检查类定义是否在这个模块里，忽略导入的类
                    if obj.__module__ == modname:
                        obj_info = f"{'->'.join(InspectUtils.get_path_and_cls_name(obj))}"
                        # 是否子类
                        any_sub_cls = any(issubclass(obj, cls) for cls in filter_cls)
                        # 是否为同一个类
                        any_equ = any(obj_info == info for info in cls_qualname_infos)

                        if filter_cls is None or any_sub_cls or any_equ:
                            classes.add(obj)

        return list(classes)
