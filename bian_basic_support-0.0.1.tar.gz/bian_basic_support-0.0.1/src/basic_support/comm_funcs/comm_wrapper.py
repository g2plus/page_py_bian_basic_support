#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: comm_wrapper.py
@Description: 通用装饰器函数模块
@time: 2022/4/13 14:48
"""

import logging
import random
import time
import traceback
from functools import partial
from itertools import count

from decorator import decorator
import inspect
from dataclasses import dataclass, field, fields, Field
import dataclasses

dataclasses._MISSING_TYPE

warp_logger = logging.getLogger(__name__)

handler = logging.StreamHandler()
handler.setLevel(logging.WARNING)
formatter = logging.Formatter("%(asctime)s %(module)s:%(lineno)d %(levelname)s: %(message)s")
handler.setFormatter(formatter)
warp_logger.addHandler(handler)


def __retry_internal(f, exceptions=Exception, tries=-1, delay: float = 0, penalty_factor=1, jitter=0, max_delay=None,
                     logger=warp_logger):
    """ 失败时重试执行函数 f
    :param f: 实际执行的函数
    :param exceptions: 需要捕获的异常, 默认为Exception
    :param tries: 重试次数, 默认为-1, 表示重试之成功
    :param delay: 每次重试的间隔, 单位为秒, 默认为 0
    :param max_delay: 最大重试间隔时间限制, 默认为None, 表示没有限制
    :param penalty_factor: 间隔惩罚因子, 默认为1, 表示无因子影响, 主要用于延长每次的间隔
    :param jitter: 两次间隔添加额外的时间, 默认为0
                   可以固定一个正整数, 或者是正整数的元组(a, b),此时随机生成一个(a,b)之间的值作为额外的间隔时间
    :param logger: 形式为 logger.warning(fmt, error, delay)
                   默认取值为logging_logger, 如果取None, 则不会有日志记录
    :returns: 实际执行的函数结果
    """
    # 重试次数 和 每次重试间隔
    _tries, _delay = tries, delay
    retry_counter = count()
    while _tries:
        try:
            return f()
        except Exception as e:
            # 重试次数递减
            _tries = _tries - 1

            if not _tries:
                raise

            # 日志输出
            if logger is not None:
                retry_times = next(retry_counter)
                logger.warning(f'{traceback.format_exc()}'
                               f'重试函数和参数为: [{f.func}, {f.args}, {f.keywords}]\n'
                               f'重试第{retry_times}次, 本次休眠时间为 {_delay} seconds...\n')

            # 开始休眠
            time.sleep(_delay)

            # 时间惩罚因子
            _delay = _delay * penalty_factor

            # 两次间隔额外的时间惩罚
            jitter_delay = random.uniform(*jitter) if isinstance(jitter, tuple) else jitter
            _delay = _delay + jitter_delay

            # 最大重试间隔时间限制
            _delay = min(_delay, max_delay) if max_delay is not None else _delay


def retry_this_function(exceptions=Exception, tries=-1, delay=0, penalty_factor=1, jitter=0, max_delay=None,
                        logger=warp_logger):
    """ 返回一个重试装饰器
    :param exceptions: 需要捕获的异常, 默认为Exception
    :param tries: 重试次数, 默认为-1, 表示重试之成功
    :param delay: 每次重试的间隔, 单位为秒, 默认为 0
    :param max_delay: 最大重试间隔时间限制, 默认为None, 表示没有限制
    :param penalty_factor: 间隔惩罚因子, 默认为1, 表示无因子影响, 主要用于延长每次的间隔
    :param jitter: 两次间隔添加额外的时间, 默认为0
                   可以固定一个正整数, 或者是正整数的元组(a, b),此时随机生成一个(a,b)之间的值作为额外的间隔时间
    :param logger: 形式为 logger.warning(fmt, error, delay)
                   默认取值为logging_logger, 如果取None, 则不会有日志记录
    :returns: 重试装饰器
    """

    @decorator
    def retry_decorator(f, *fargs, **fkwargs):
        """
        @param f: 实际执行的函数
        @param fargs: 实际函数执行需要的参数列表
        @param fkwargs: 实际函数执行需要的参数映射
        """
        args = fargs if fargs else list()
        kwargs = fkwargs if fkwargs else dict()
        p_f = partial(f, *args, **kwargs)
        return __retry_internal(f=p_f, exceptions=exceptions, tries=tries, delay=delay, max_delay=max_delay,
                                penalty_factor=penalty_factor, jitter=jitter, logger=logger)

    return retry_decorator


def retry_call_function(f, fargs=None, fkwargs=None, exceptions=Exception, tries=-1, delay=0.0, penalty_factor=1,
                        jitter=0, max_delay=None, logger=warp_logger):
    """ 失败重试函数
    :param f: 实际执行的函数
    :param fargs: 实际函数执行需要的参数列表
    :param fkwargs: 实际函数执行需要的参数映射
    :param exceptions: 需要捕获的异常, 默认为Exception
    :param tries: 重试次数, 默认为-1, 表示重试之成功
    :param delay: 每次重试的间隔, 单位为秒, 默认为 0
    :param max_delay: 最大重试间隔时间限制, 默认为None, 表示没有限制
    :param penalty_factor: 间隔惩罚因子, 默认为1, 表示无因子影响, 主要用于延长每次的间隔
    :param jitter: 两次间隔添加额外的时间, 默认为0
                  可以固定一个正整数, 或者是正整数的元组(a, b),此时随机生成一个(a,b)之间的值作为额外的间隔时间
    :param logger: 形式为 logger.warning(fmt, error, delay)
                  默认取值为logging_logger, 如果取None, 则不会有日志记录
    :return: 实际执行的函数结果
    """
    args = fargs if fargs else list()
    kwargs = fkwargs if fkwargs else dict()
    p_f = partial(f, *args, **kwargs)
    return __retry_internal(f=p_f, exceptions=exceptions, tries=tries, delay=delay, max_delay=max_delay,
                            penalty_factor=penalty_factor, jitter=jitter, logger=logger)


def get_default_value(field: Field):
    def_value = field.default

    if type(def_value) == dataclasses._MISSING_TYPE:
        if type(field.default_factory) != dataclasses._MISSING_TYPE:
            def_value = field.default_factory()
    return def_value


def attr_dataclass(cls):
    """
    在dataclass上 适配了*args, **kwargs参数
    :param cls:
    :return:
    example:

    @attr_dataclass
    @dataclass
    class BertConfig:
        name: str = field(default='ha~')
        hidden_dropout_prob: float = field(default=0.1)

    cfg = BertConfig('wu~', hidden_dropout_prob=8, other=9)

    """

    EXIST_INIT_KEY = 'EXIST_INIT_KEY'

    # 获取 ElfModuleArguments 类的所有字段
    all_fields = fields(cls)

    # defaults = [(key, cls.__dict__[key]) for key, value in cls.__annotations__.items()]
    sorted_keys = [key for key, value in cls.__annotations__.items()]
    key_2_field = {field.name: field for field in all_fields}

    # defaults = [(field.name, get_default_value(field=field)) for field in all_fields]
    defaults = [(key, get_default_value(key_2_field[key])) for key in sorted_keys]
    mros = inspect.getmro(cls)

    def __init__(self, *args, **kwargs):
        # ori_key_values = {k: getattr(self, k) for k, v in defaults if hasattr(self, k)}

        # 获取当前cls 定义的参数列表
        exist_init_key = kwargs.pop(EXIST_INIT_KEY, set())
        all_keys = {a for a, b in defaults}

        # 初始化默认值(子类已存在的参数不设置默认值, 以子类为准, 不然会覆盖子类的默认值)
        for default_key, default_value in defaults:
            if default_key not in exist_init_key:
                setattr(self, default_key, default_value)
        for key in all_keys:
            exist_init_key.add(key)

        # args参数列表 匹配默认参数
        exist_keys = set()
        for arg, (default_key, default_value) in zip(args, defaults):
            setattr(self, default_key, arg)
            exist_keys.add(default_key)
        reserve_args = args[len(defaults):]

        # kwargs参数列表 匹配默认参数
        for key, value in kwargs.items():
            if key in exist_keys:
                raise TypeError(f"{self.__class__.__name__}.__init__() got multiple values for argument '{key}'")
            if key in all_keys:
                setattr(self, key, value)
                exist_keys.add(key)

        #  父类初始化
        for mro in mros[1:-1]:
            # 获取 Example 类的 __init__ 方法的签名
            init_signature_keys = inspect.signature(mro.__init__).parameters.keys()
            # 获取参数信息
            init_kwargs = {key: kwargs[key] for key in init_signature_keys if key != 'self' and key in kwargs}

            for key in init_signature_keys:
                exist_keys.add(key)

            if reserve_args:
                assert hasattr(mro, '__is_dataclass__'), "请确认参数顺序正确"

            try:
                init_kwargs[EXIST_INIT_KEY] = exist_init_key
                mro.__init__(self, *reserve_args, **init_kwargs)
            except Exception as e:
                init_kwargs.pop(EXIST_INIT_KEY)
                mro.__init__(self, *reserve_args, **init_kwargs)

            if hasattr(mro, '__is_dataclass__'):
                reserve_args = reserve_args[getattr(mro, '__arg_num__'):]

        reserve_params = {k: v for k, v in kwargs.items() if k not in exist_keys}
        for key, value in reserve_params.items():
            if key != EXIST_INIT_KEY:
                setattr(self, key, value)

        # for k, v in ori_key_values.items():
        #     setattr(self, k, v)
        #
        # for k, v in ori_key_values.items():
        #     if type(v) == dataclasses._MISSING_TYPE:
        #         raise TypeError(f"{self.__class__.__name__}.__init__() missing 1 required positional argument: '{k}'")

        for arg, (default_key, default_value) in zip(args, defaults):
            setattr(self, default_key, arg)

        for key, value in kwargs.items():
            # if key in exist_keys:
            #     raise TypeError(f"{self.__class__.__name__}.__init__() got multiple values for argument '{key}'")
            if key in all_keys:
                setattr(self, key, value)

        for key in all_keys:
            if type(getattr(self, key)) == dataclasses._MISSING_TYPE:
                raise TypeError(f"{self.__class__.__name__}.__init__() missing 1 required positional argument: '{key}'")

        if hasattr(self, EXIST_INIT_KEY):
            delattr(self, EXIST_INIT_KEY)

        if hasattr(self, '__post_init__'):
            self.__post_init__()

    cls.__init__ = __init__
    cls.__is_dataclass__ = True
    cls.__arg_num__ = len(defaults)

    return cls


if __name__ == '__main__':
    @retry_this_function(tries=20, )
    def retry_func_warp(pa, pb, dc, dd):
        import random
        print(pa, pb, dc, dd)
        it = random.randint(1, 80)
        if it >= 70:
            return it
        raise Exception("数值小于70")


    def retry_func(pa, pb, dc, dd):
        import random
        print(pa, pb, dc, dd)
        it = random.randint(1, 80)
        if it >= 70:
            return it
        raise Exception("数值小于70")


    pab = [1, 2]
    pcd = {"dc": 7, "dd": 8}
    mit = retry_func_warp(*pab, **pcd)
    print(f'获取到大于70的值: {mit}')

    mit = retry_call_function(retry_func, pab, pcd, tries=20, delay=0.2)
    print(f'获取到大于70的值: {mit}')

    print("程序结束")
