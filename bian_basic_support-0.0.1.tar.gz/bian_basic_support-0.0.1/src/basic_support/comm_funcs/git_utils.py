#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: git_utils.py
@Description: git相关的工具
@time: 2024/10/25 14:09
"""

import os
import subprocess
from typing import Generator, Dict

from dateutil import parser


def get_git_commit_info(repo_path, n: int = 10) -> Generator[Dict, None, None]:
    """
    获取git提交历史
    :param repo_path:
    :param n: 获取的提交数量
    :return:
    """
    # 检查路径是否存在
    if not os.path.isdir(repo_path):
        print(f"Error: The path '{repo_path}' does not存在或不是一个目录.")
        return

    # 检查是否是一个Git仓库
    if not os.path.isdir(os.path.join(repo_path, '.git')):
        print(f"Error: The path '{repo_path}' 不像是一个Git仓库.")
        return

    try:
        # 获取最近的提交信息，包含完整日期 (%cd) 和其他字段
        result = subprocess.run(
            ['git', 'log', '--pretty=format:%H - %cd', f'-{n}'],
            cwd=repo_path,
            capture_output=True,
            text=True,
            encoding='utf-8',
            check=True
        )

        # 处理并格式化输出
        for line in result.stdout.splitlines():
            try:
                # 提取日志字段
                commit_hash, date_str = line.split(' - ')

                # 使用 dateutil 解析日期
                date_obj = parser.parse(date_str)
                formatted_date = date_obj.strftime("%Y年%m月%d日 %H:%M:%S")

                # 输出格式化后的日志信息
                yield {"commit_hash": commit_hash, "formatted_date": formatted_date}
            except ValueError as e:
                print(f"Error parsing line: {line}")
                print(e)

    except subprocess.CalledProcessError as e:
        print(f"CalledProcessError: {e}")
        print(f"stderr: {e.stderr}")
        print(f"stdout: {e.stdout}")
    except Exception as e:
        print(f"Unexpected error: {e}")
