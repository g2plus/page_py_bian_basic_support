#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: inspect_utils.py
@Description: 
@time: 2024/7/29 15:47
"""
from collections import OrderedDict
from dataclasses import dataclass, field

from basic_support.comm_funcs.assert_utils import Assert

# !/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: inspect_utils.py
@Description: inspect相关工具
@time: 2024/1/30 11:04
"""

import importlib
import inspect
import pkgutil
from typing import Set, List, Tuple, Dict


@dataclass
class MethodParamMeta:
    P_TYPE_KEY = "KEY"
    P_TYPE_VAR_PARAM = "PARAM"
    P_TYPE_VAR_KWARGS = "KWARGS"

    name: str = field(default=None, metadata={"help": "方法参数名"})
    must: bool = field(default=True, metadata={"help": "方法参数是否必须"})
    default: str = field(default=None, metadata={"help": "默认值"})
    param_type: str = field(default=P_TYPE_KEY, metadata={"help": "*param或**kwargs参数"})


class InspectUtils:

    @staticmethod
    def get_object_type(name):
        return globals().get(name)

    @staticmethod
    def fill_method_params(method, param_vals: Dict[str, object], is_must=True):
        param_metas: Dict[str, MethodParamMeta] = InspectUtils.get_func_param_metas(method)
        param = OrderedDict()
        var_param = set()
        for p_name, p_meta in param_metas.items():
            if p_meta.param_type == MethodParamMeta.P_TYPE_KEY:
                if p_name in param_vals:
                    p_val = param_vals[p_name]
                    param[p_name] = p_val
                elif p_meta.must and is_must and p_meta.default is None:
                    raise Exception(f"[{method.__name__}.{p_meta.name}]是必填项，但参数集合没有该名称的值")
                else:
                    param[p_name] = p_meta.default
            if p_meta.param_type == MethodParamMeta.P_TYPE_VAR_PARAM:
                val_param = set(param_vals.keys())
                key_param = set(param.keys())
                var_param_name = val_param - (key_param - var_param)
                var_param.add(p_name)
                param[p_name] = [v for k, v in param_vals.items() if k in var_param_name]
            if p_meta.param_type == MethodParamMeta.P_TYPE_VAR_KWARGS:
                val_param = set(param_vals.keys())
                key_param = set(param.keys())
                var_param_name = val_param - (key_param - var_param)
                param[p_name] = {k: v for k, v in param_vals.items() if k in var_param_name}
        return param

    @staticmethod
    def get_func_param_metas(func) -> Dict[str, MethodParamMeta]:
        sig = inspect.signature(func)
        params = OrderedDict()
        for name, p in sig.parameters.items():
            default = p.default if p.default != p.empty else None
            param_type = MethodParamMeta.P_TYPE_KEY
            if p.kind == p.VAR_POSITIONAL:
                param_type = MethodParamMeta.P_TYPE_VAR_PARAM
            elif p.kind == p.VAR_KEYWORD:
                param_type = MethodParamMeta.P_TYPE_VAR_KWARGS

            params[name] = MethodParamMeta(name=name,
                                           must=p.default == p.empty and p.kind not in (
                                               p.VAR_POSITIONAL, p.VAR_KEYWORD),
                                           default=default, param_type=param_type)
        return params

    @staticmethod
    def get_func_param_names(func):
        sig = inspect.signature(func)
        return [name for name, p in sig.parameters.items()]

    @staticmethod
    def get_path_and_cls_name(cls: type) -> Tuple[str, str]:
        cls_path = inspect.getfile(cls)
        cls_qualname = cls.__qualname__
        return cls_path, cls_qualname

    @staticmethod
    def find_obj_in_package(package, filter_cls: Set[type] = None) -> List[type]:
        return InspectUtils.find_elements_in_package(package=package, filter_type=isinstance, filter_cls=filter_cls)

    @staticmethod
    def find_classes_in_package(package, filter_cls: Set[type] = None) -> List[type]:
        return InspectUtils.find_elements_in_package(package=package, filter_type=issubclass, filter_cls=filter_cls)

    @staticmethod
    def filter_elements_in_package(package, filter_method) -> Dict:
        classes = {}
        seen_modules = set()  # 保存已经检查过的模块
        for importer, modname, ispkg in pkgutil.walk_packages(package.__path__, package.__name__ + '.'):
            modnames = modname.removeprefix(package.__name__ + ".").split(".")
            Assert.not_empty(modnames, "子模块")
            cur_mod = classes
            l = modnames if ispkg else modnames[:-1:]
            for m in l:
                tmp = {}
                if m not in cur_mod:
                    cur_mod[m] = tmp
                else:
                    tmp = cur_mod[m]
                cur_mod = tmp

            if modname not in seen_modules:  # 检查模块是否已经检查过
                seen_modules.add(modname)
                module = importlib.import_module(modname)
                for name, obj in inspect.getmembers(module, filter_method):
                    # 检查类定义是否在这个模块里，忽略导入的类
                    cur_mod[modnames[-1]] = obj
        return classes

    @staticmethod
    def find_elements_in_package(package, filter_type, filter_cls: Set[type] = None) -> List[type]:
        """
        递归地查找给定包中定义的所有类
        :param package_name: 包名
        :param filter_cls: 需要保留下的类的
        :return:
        """
        classes = set()
        seen_modules = set()  # 保存已经检查过的模块

        cls_qualname_infos = [f"{'->'.join(InspectUtils.get_path_and_cls_name(cls))}" for cls in filter_cls]

        for importer, modname, ispkg in pkgutil.walk_packages(package.__path__, package.__name__ + '.'):
            if modname not in seen_modules:  # 检查模块是否已经检查过
                seen_modules.add(modname)
                module = importlib.import_module(modname)
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    # 检查类定义是否在这个模块里，忽略导入的类
                    if obj.__module__ == modname:
                        obj_info = f"{'->'.join(InspectUtils.get_path_and_cls_name(obj))}"
                        # 是否子类
                        any_sub_cls = any(filter_type(obj, cls) for cls in filter_cls)
                        # 是否为同一个类
                        any_equ = any(obj_info == info for info in cls_qualname_infos)

                        if filter_cls is None or any_sub_cls or any_equ:
                            classes.add(obj)

        return list(classes)

    @staticmethod
    def find_elements_in_package(package, filter_type, filter_cls: Set[type] = None) -> List[type]:
        """
        递归地查找给定包中定义的所有类
        :param package_name: 包名
        :param filter_cls: 需要保留下的类的
        :return:
        """
        classes = set()
        seen_modules = set()  # 保存已经检查过的模块

        cls_qualname_infos = [f"{'->'.join(InspectUtils.get_path_and_cls_name(cls))}" for cls in filter_cls]

        for importer, modname, ispkg in pkgutil.walk_packages(package.__path__, package.__name__ + '.'):
            if modname not in seen_modules:  # 检查模块是否已经检查过
                seen_modules.add(modname)
                module = importlib.import_module(modname)
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    # 检查类定义是否在这个模块里，忽略导入的类
                    if obj.__module__ == modname:
                        obj_info = f"{'->'.join(InspectUtils.get_path_and_cls_name(obj))}"
                        # 是否子类
                        any_sub_cls = any(filter_type(obj, cls) for cls in filter_cls)
                        # 是否为同一个类
                        any_equ = any(obj_info == info for info in cls_qualname_infos)

                        if filter_cls is None or any_sub_cls or any_equ:
                            classes.add(obj)

        return list(classes)

    @staticmethod
    def find_elements_in_package_name(package_name, filter_type, filter_cls: Set[type] = None) -> List[type]:
        package = importlib.import_module(package_name)
        return InspectUtils.find_elements_in_package(package=package, filter_type=filter_type, filter_cls=filter_cls)

    @staticmethod
    def find_obj_in_package_name(package_name: str, filter_cls: Set[type] = None) -> List[type]:
        package = importlib.import_module(package_name)
        return InspectUtils.find_obj_in_package(package=package, filter_cls=filter_cls)

    @staticmethod
    def filter_elements_in_package_name(package_name, filter_method) -> Dict:
        package = importlib.import_module(package_name)
        return InspectUtils.filter_elements_in_package(package=package, filter_method=filter_method)

    @staticmethod
    def get_classes_to_dict(package_name: str, filter_cls: Set[type] = None) -> Dict[str, type]:
        classes = InspectUtils.get_classes_list(package_name=package_name, filter_cls=filter_cls)
        return {i.__name__: i for i in classes}

    @staticmethod
    def get_classes_list(package_name: str, filter_cls: Set[type] = None) -> List[type]:
        """
        递归地查找给定包中定义的所有类
        :param package_name: 包名
        :param filter_cls: 需要保留下的类的
        :return:
        """
        package = importlib.import_module(package_name)
        return InspectUtils.find_classes_in_package(package=package, filter_cls=filter_cls)


def aa(p1, p2=None, *param, **kwargs):
    pass


if __name__ == '__main__':
    p = InspectUtils.fill_method_params(aa, {"p2": "dd", "p3": 12, "p5": "23"}, is_must=False)
    print(p)
