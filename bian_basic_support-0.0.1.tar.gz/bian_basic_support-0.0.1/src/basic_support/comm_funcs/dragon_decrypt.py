enc_key = "DragonSoftCreation"


def dragon_decrypt(val: str) -> str:
    """
    巨龙加密字符串的解密
    :param val:
    :return:
    """
    result = ""
    if val is None or len(val) == 0:
        return result
    len1 = int(len(val) / len(enc_key))
    long_key = ""
    for i in range(len1 + 1):
        long_key += enc_key
    long_key_bytes = long_key.encode()
    enc_value_bytes = bytearray.fromhex(val)
    lp_result_bytes = bytearray(b'')
    for i in range(len(enc_value_bytes)):
        lp_result_bytes.append(enc_value_bytes[i] ^ long_key_bytes[i])
    return lp_result_bytes.decode(encoding='utf8', errors='strict')


if __name__ == "__main__":
    s = "341D1213081C361C"
    dec_str = dragon_decrypt(s)
    print(dec_str)
