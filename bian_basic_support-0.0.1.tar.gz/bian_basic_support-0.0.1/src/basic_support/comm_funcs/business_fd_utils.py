#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: business_fd_utils.py
@Description: 业务相关的工具方法
              当前项目中，该文件依赖其他的文件，而其他文件不该依赖他
@time: 2023/8/16 15:21
"""
from typing import Dict, List, Set, Tuple, Union, Any

import os
import time
import requests
from basic_support.comm_funcs.comm_utils import find_root_path_by_resources, read_yaml, merge_nested_dicts
from basic_support.comm_funcs.comm_utils import uniform_n_split_lst
from basic_support.logger.logger_config import logger


def read_yaml_cfg() -> Dict:
    """ 读取项目配置文件 """
    # 获取项目根路径
    root_path = find_root_path_by_resources()
    # 资源配置所在路径
    resources_path = root_path.joinpath('resources')

    # 读取环境配置
    cfg_path = resources_path.joinpath('config.yaml').as_posix()
    cfg_yaml = read_yaml(yaml_path=cfg_path)
    assert 'use' in cfg_yaml, 'config.yaml缺少use配置'
    use = cfg_yaml.get('use')

    # 读取实际配置
    cfg_project_path = resources_path.joinpath(f'project_config_{use}.yaml').as_posix()
    cfg_project_yaml = read_yaml(yaml_path=cfg_project_path)

    # 获取补充配置
    for augment_cfg_file in resources_path.glob("**/augment*.yaml"):
        if augment_cfg_file.is_file():  # 确保是文件而不是目录
            augment_cfg = read_yaml(yaml_path=augment_cfg_file.as_posix())
            if augment_cfg is not None:
                cfg_project_yaml = merge_nested_dicts(augment_cfg, cfg_project_yaml)

    # 读取公有配置
    cfg_common_path = resources_path.joinpath('project_config_common.yaml').as_posix()
    if os.path.exists(cfg_common_path):
        cfg_common = read_yaml(yaml_path=cfg_common_path)
        if cfg_common is not None:
            cfg_project_yaml = merge_nested_dicts(cfg_common, cfg_project_yaml)
    else:
        logger.warning(f"当前找不到配置: {cfg_common_path}")

    return cfg_project_yaml


def cal_embedding(
        embedding_server: str,
        contents: List[str],
        batch_size: int = 100
):
    """对文本内容列表进行批量embedding
    :param str embedding_server: embedding服务的url，如:http://region-8.seetacloud.com:36146/nlp/embSentences
    :param List[str] contents: _description_
    :param int batch_size: _description_, defaults to 100
    :raises Exception: _description_
    :return _type_: _description_
    """
    ret = []
    for subl in uniform_n_split_lst(contents, batch_size=batch_size):
        x = requests.post(embedding_server, json=subl)
        if x.status_code == 200:
            ret.extend(x.json()['response'])
        else:
            raise Exception("访问异常")
    return ret


def sentence_tok(url, contents: List[str], ignore_cus_dict: bool = False, pos: bool = True, dep: bool = True,
                 con: bool = True, merge_tok: bool = False, merge_tags: Set[str] = None, max_merge_count: int = 2,
                 retry_times: int = 10, timeout: int = 5000) -> Dict[
    str, Union[List[Union[str, Tuple[int, str]]], Any]]:
    """对句子列表进行分词，以及根据入参可选进行词性标注、依存句法分析、成分句法分析等操作
    :param _type_ url: 远程URL
    :param List[str] contents: 待处理的句子列表
    :param bool ignore_cus_dict: 切词是否忽略用户词典，默认为False
    :param bool pos: 是否进行词性标注，默认为True
    :param bool dep: 是否进行依存句法分析，默认为True
    :param bool con: 是否进行成分句法分析，默认为True
    :param bool merge_tok: 是否进行带合并的重叠切词，默认为False,如果为True,则强制con为True
    :param Set[str] merge_tags: 要合并的句法成分标签集合
    :param int max_merge_count: 合并节点子树的最大合并次数
    :return Dict[ str, Union[ List[ Union[ str, Tuple[int,str] ] ], Tree ] ]: _description_
    """
    from phrasetree.tree import Tree
    merge_tags = [] if merge_tags is None else list(merge_tags)
    req_param = {
        "sentences": contents,
        "ignore_cus_dict": ignore_cus_dict,
        "pos": pos,
        "dep": dep,
        "con": con,
        "merge_tok": merge_tok,
        "merge_tags": merge_tags,
        "max_merge_count": max_merge_count
    }
    for i in range(retry_times):
        r = requests.post(url=url, json=req_param, timeout=timeout)
        if r.status_code == 200:
            ret = r.json()
            for item in ret:
                if 'con' in item:
                    try:
                        item['con'] = Tree.fromstring(item['con'])
                    except Exception:
                        print(f"解析con字符串抛出异常，con字符串:{item['con']}")
                        item['con'] = None
            return ret
        else:
            t = i + 1 if i <= 2 else (i + 1) * 2
            print(f"[sentence_tok]第{i + 1}次重试，等待时间:{t}秒")
            time.sleep(t)
    raise Exception("访问异常")


if __name__ == "__main__":
    # from basic_support.comm_funcs.business_fd_utils import sentence_tok
    url = "http://region-8.seetacloud.com:36146/nlp/tokSentences"
    ret = sentence_tok(
        url,
        contents=[
            "政府购买了大量新装备以保障应急救援人员生命安全。",
            "报刊音像出版单位",
            "农产品质量安全管理水平",
            "锅炉质量安全风险隐患"
        ],
        ignore_cus_dict=False,
        pos=False,
        dep=False,
        con=False
    )
    print(ret)
