#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: net_utils.py
@Description: 
@time: 2023/2/15 14:47
"""

import errno
import os
import os.path as osp
import ssl
import sys
import traceback
import urllib
from typing import Optional, List, Callable, Dict
from urllib.parse import unquote
from urllib.parse import urlparse

import requests
from basic_support.comm_funcs.io_utils import print_to_file

from basic_support.logger.logger_config import logger

import socket


def get_local_ip():
    try:
        # 创建一个 UDP 套接字，不会真正发送数据
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))  # Google DNS，仅用于获取本地IP
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'  # 回退为本地回环地址


def makedirs(path: str):
    r"""Recursive directory creation function."""
    try:
        os.makedirs(osp.expanduser(osp.normpath(path)))
    except OSError as e:
        if e.errno != errno.EEXIST and osp.isdir(path):
            raise e


def download_url(url: str, folder: str, log: bool = True, file_name: Optional[str] = None):
    """
    Downloads the content of an URL to a specific folder.
    :param url: url地址
    :param folder: 下载到的文件夹
    :param log: 是否打印日志
    :param file_name: 文件名(可选)，默认从url解析文件名
    :return: 文件保存路径
    """
    if file_name is None:
        file_name = url.rpartition('/')[2]
        file_name = file_name if file_name[0] == '?' else file_name.split('?')[0]

    save_path = osp.join(folder, file_name)

    # 路径检查，已存在的话报错
    if osp.exists(save_path):  # pragma: no cover
        if log:
            print(f'Using existing file {file_name}', file=sys.stderr)
        return save_path

    if log:
        print(f'Downloading {url}', file=sys.stderr)

    makedirs(folder)

    context = ssl._create_unverified_context()
    data = urllib.request.urlopen(url, context=context)

    # 文件保存
    with open(save_path, 'wb') as f:
        # workaround for https://bugs.python.org/issue42853
        while True:
            chunk = data.read(10 * 1024 * 1024)
            if not chunk:
                break
            f.write(chunk)

    return save_path


def extract_main_domain(url):
    parsed_url = urlparse(url)
    main_domain = f"{parsed_url.scheme}://{parsed_url.hostname}"
    return main_domain


def gen_download_hf_models_script(model_url: str, file_name: str, filter_types: List[str] = None):
    """
    产生下载hf模型的脚本
    :param model_url: 支持 https://hf-mirror.com 和 https://huggingface.co/models
                    如: https://hf-mirror.com/baichuan-inc/Baichuan2-13B-Chat/tree/v2.0
    :param file_name: 输出文件名字, 如nohup_download_baichuan2.sh
    :param filter_types: 需要过滤的文件类型[暂时没实现]
    :return:
    """
    from bs4 import BeautifulSoup

    # 获取主要域名
    main_domain = extract_main_domain(model_url)

    # 输出主要域名
    logger.info(f"解析到域名为：{main_domain}")

    # 发送HTTP GET请求获取网页内容
    logger.info("开始解析下载")
    response = requests.get(model_url)
    logger.info("网页下载完成, 准备解析下载地址")
    html_content = response.text

    # 使用BeautifulSoup对HTML内容进行解析
    soup = BeautifulSoup(html_content, 'html.parser')

    download_files = soup.findAll('a', {'title': 'Download file'})

    try:
        output_dir = soup.find('a', class_='break-words').text.strip()
    except Exception as e:
        output_dir = os.path.split(file_name)[-1].split('.')[0]

    with print_to_file(file_name):
        print(f'mkdir {output_dir}')
        print(f'echo "创建文件夹{output_dir}"\n')

        print(f'cd {output_dir}')
        print('echo "开始下载模型等文件"\n')

        for idx, download_file in enumerate(download_files):
            href = unquote(download_file.get('href'))
            print('date +"当前时间为: %Y-%m-%d %H:%M:%S"')
            url = f"{main_domain}{href}"

            download_file_name = os.path.basename(href).split('?')[0]
            print(f'wget -O "{download_file_name}" "{url}"')
            print(f'echo "下载完成"\n')

        print('date +"当前时间为: %Y-%m-%d %H:%M:%S"')
        print('echo "Download completed successfully."')

    logger.info("下载地址解析完毕")
    logger.info(f"脚本输出路径为: {file_name}")


class UrlRequests:
    @staticmethod
    def _call_url(url: str, params: Dict, method: Callable = None, parse_func: Callable = None, **kwargs):
        parse_func = parse_func or (lambda k: k.json()['response'])
        x = method(url, json=params, **kwargs)
        if x.status_code == 200:
            resp = parse_func(x) if parse_func else x
        else:
            raise Exception(f"访问异常: {traceback.format_exc()}")
        return resp

    @staticmethod
    def get(url: str, params: Dict, parse_func: Callable = None, **kwargs):
        return UrlRequests._call_url(url=url, method=requests.get, params=params, parse_func=parse_func, **kwargs)

    @staticmethod
    def post(url: str, params: Dict, parse_func: Callable = None, **kwargs):
        return UrlRequests._call_url(url=url, method=requests.post, params=params, parse_func=parse_func, **kwargs)


if __name__ == '__main__':
    test_url = r"https://hf-mirror.com/baichuan-inc/Baichuan2-13B-Chat/tree/v2.0"
    # test_url = r"https://hf-mirror.com/baichuan-inc/Baichuan2-13B-Chat-4bits/tree/v2.0"

    gen_download_hf_models_script(model_url=test_url, file_name='noup_download_baichuan2.sh')
