#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: db_connection_abs.py
@Description: 
@time: 2020/7/30 13:48
"""

import os

from dbutils.pooled_db import PooledDB

# try:
#     from DBUtils.PooledDB import PooledDB
# except:
#     from dbutils.pooled_db import PooledDB

from basic_support.data_access.connection.cache_meta_class import RdbConnCache

os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'


class BaseDbConnection:
    """
    数据库连接技术最高抽象父类
    """

    def __init__(self):
        pass


class AbstractRawConnection(BaseDbConnection, metaclass=RdbConnCache):
    """
    数据库 连接方式父类
    """

    def __init__(self):
        super(AbstractRawConnection, self).__init__()


class AbstractRdbConn(AbstractRawConnection):
    """
    关系型数据库 连接方式父类
    """

    def __init__(self):
        super(AbstractRdbConn, self).__init__()

    @property
    def connection(self):
        return self.conn

    @staticmethod
    def get_conn_str(*args, **kwargs):
        pass


class AbstractRawPool(BaseDbConnection):
    """
    数据库 连接池方式父类
    """

    def __init__(self):
        super(AbstractRawPool, self).__init__()

    @property
    def connection(self):
        return None


class AbstractRdbPool(AbstractRawPool):
    """
    关系型数据库 连接池方式父类
    连接池中配置的连接数都是一个进程为单位的（即上面的最大连接数，都是在一个进程中的连接数）
    连接池对性能的提升表现在：
        1.在程序创建连接的时候，可以从一个空闲的连接中获取，不需要重新初始化连接，提升获取连接的速度
        2.关闭连接的时候，把连接放回连接池，而不是真正的关闭，所以可以减少频繁地打开和关闭连接
    """

    def __init__(self,
                 db_creator,
                 db_type: str,
                 max_cached: int = 0,
                 max_connections: int = 16,
                 max_usage: int = 0,
                 blocking: bool = True,
                 **config):
        """
        :param db_creator: 数据库驱动模块，如常见的pymysql,pymssql,cx_Oracle模块。无默认值
        :param db_type: 关系库类型
        :param max_cached: 池中空闲连接的最大数量。默认为0，即无最大数量限制。(建议默认)
        :param max_connections: 被允许的最大连接数。默认为0，无最大数量限制。(视情况而定)
        :param max_usage: 连接的最大使用次数。默认0，即无使用次数限制。(建议默认)
        :param blocking: 连接数达到最大时，新连接是否可阻塞。默认False，即达到最大连接数时，再取新连接将会报错。
                        (建议True，达到最大连接数时，新连接阻塞，等待连接数减少再连接)
        :param config: 关系库配置信息
        """
        super(AbstractRdbPool, self).__init__()
        self.db_type = db_type
        cfg = self.supply_cfg(config)
        self.pool = PooledDB(db_creator,
                             maxcached=max_cached,
                             maxconnections=max_connections,
                             maxusage=max_usage,
                             blocking=blocking,
                             **cfg)

    def supply_cfg(self, config):
        return config

    @property
    def connection(self):
        return self.pool.connection()
