#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: rdb_pool.py
@Description: 
@time: 2020/7/25 22:07
"""

import importlib
from functools import wraps

from basic_support.comm_funcs.comm_utils import gen_uuid32
from basic_support.comm_funcs.utils_func import load_ini_config
from basic_support.data_access.config.impl.rdb_config import RdbConfig
from basic_support.data_access.connection.db_connection_abs import AbstractRdbPool
from basic_support.data_access.dao.impl.mysql_dao import MysqlDao
from basic_support.data_access.dao.impl.oracle_dao import OracleDao
from basic_support.data_access.dao.impl.pg_dao import PgDao
from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao

"""
定义一些常量
"""
oracle_type = 'oracle'
mysql_type = 'mysql'
postgres_type = 'postgres'
sqlserver_type = 'sqlserver'
sqlite_type = 'sqlite3'
hbase_type = 'hbase'

# 构造器工厂
pool_dict = dict()


def wrap_pool_dict(cls):
    """
    连接池添加装饰器, 通过类装饰器将连接池添加到 连接池字典里
    :param cls: 连接池类
    """
    pool_dict[cls.db_type] = cls

    @wraps(cls)
    def inner(*args, **kwargs):
        return cls(*args, **kwargs)

    return inner


dao_dict = {
    oracle_type: OracleDao,
    mysql_type: MysqlDao,
    postgres_type: PgDao,
    # sqlserver_type: SqlServerPool,
    # sqlite_type: SqlitePool,
    # hbase_type: HbasePool
}


@wrap_pool_dict
class OraclePool(AbstractRdbPool):
    db_type = oracle_type

    def __init__(self, rdb_config: RdbConfig):
        config = {
            'user': rdb_config.user,
            'password': rdb_config.password,
            'dsn': "/".join([":".join([rdb_config.host, str(rdb_config.port)]), rdb_config.db]),
            'nencoding': rdb_config.charset
        }
        # TODO  失败时自动安装
        db_creator = importlib.import_module("cx_Oracle")
        super(self.__class__, self).__init__(db_creator, self.db_type, **config)


@wrap_pool_dict
class MysqlPool(AbstractRdbPool):
    db_type = mysql_type

    def __init__(self, rdb_config: RdbConfig):
        config = {
            'host': rdb_config.host,
            'port': rdb_config.port,
            'database': rdb_config.db,
            'user': rdb_config.user,
            'password': rdb_config.password,
            'charset': rdb_config.charset
        }
        db_creator = importlib.import_module("pymysql")
        super(self.__class__, self).__init__(db_creator, self.db_type, **config)


@wrap_pool_dict
class SqlServerPool(AbstractRdbPool):
    db_type = sqlserver_type

    def __init__(self, rdb_config: RdbConfig):
        config = {
            'host': rdb_config.host,
            'port': rdb_config.port,
            'database': rdb_config.db,
            'user': rdb_config.user,
            'password': rdb_config.password,
            'charset': rdb_config.charset
        }
        db_creator = importlib.import_module("pymssql")
        super(self.__class__, self).__init__(db_creator, self.db_type, **config)


@wrap_pool_dict
class SqlitePool(AbstractRdbPool):
    db_type = sqlite_type

    def __init__(self, rdb_config: RdbConfig):
        config = {
            'database': rdb_config.db
        }
        db_creator = importlib.import_module("sqlite3")
        super(self.__class__, self).__init__(db_creator, self.db_type, **config)


@wrap_pool_dict
class HbasePool(AbstractRdbPool):
    db_type = hbase_type

    def __init__(self, rdb_config: RdbConfig):
        config = {
            'url': f'http://{rdb_config.host}:{rdb_config.port}',
            'user': rdb_config.user,
            'password': rdb_config.password,
            'autocommit': True
        }
        db_creator = importlib.import_module("phoenixdb")
        super(self.__class__, self).__init__(db_creator, self.db_type, **config)


@wrap_pool_dict
class PostgresPool(AbstractRdbPool):
    db_type = postgres_type

    def __init__(self, rdb_config: RdbConfig):
        """
        psycopg2版本中 配置参数用的是database
        psycopg版本中 配置参数用的是dbname
        @param rdb_config:
        """
        from psycopg import ServerCursor
        from functools import partial

        # 解决游标的问题, 默认使用的是ClientCursor
        cls = partial(ServerCursor, name=gen_uuid32())

        config = {
            'host': rdb_config.host,
            'port': rdb_config.port,
            'dbname': rdb_config.db,
            'user': rdb_config.user,
            'password': rdb_config.password,
            # 'prepare_threshold':None,
            # 'cursor_factory': cls
        }
        db_creator = importlib.import_module("psycopg")
        super(self.__class__, self).__init__(db_creator, self.db_type, **config)

    def supply_cfg(self, config):
        dic = dict(keepalives=1, keepalives_idle=30, keepalives_interval=10, keepalives_count=5)
        dic.update(config)
        return dic


class RdbDaoCreator(object):
    """
    创建数据库连接池
    每种配置的数据库只能存在一个连接池
    """

    def __init__(self):
        self.cache_db_pools = {}

    def get_rdb_pool(self, rdb_config: RdbConfig) -> AbstractRdbDao:
        assert rdb_config.db_type in pool_dict, f"暂不支持{rdb_config.db}数据库"
        if rdb_config not in self.cache_db_pools:
            self.cache_db_pools[rdb_config] = pool_dict[rdb_config.db_type](rdb_config)
        rdb_pool = self.cache_db_pools[rdb_config]
        return dao_dict[rdb_config.db_type](rdb_pool)


# 定义一个实例外部直接用
rdb_dao_creator = RdbDaoCreator()


def load_rdb_dao(path: str):
    from parse import parse
    with open(path, 'r', encoding='utf-8') as f:
        config_text = [_[:-1] if _[-1] == '\n' else _ for _ in f.readlines()]
    config_text = ''.join(config_text)
    pattern = 'host={host}' \
              'port={port:d}' \
              'user={user}' \
              'password={password}' \
              'db={db}' \
              'db_type={db_type}'
    config_dict = parse(pattern, config_text).named
    dao: AbstractRdbDao = rdb_dao_creator.get_rdb_pool(RdbConfig(**config_dict))
    return dao


def load_rdb_dao_from_cfg(cfg_path, dao_type):
    cfg = load_ini_config(cfg_path)
    dao_cfg = cfg[dao_type]
    dao_cfg = RdbConfig(**dao_cfg)
    dao = rdb_dao_creator.get_rdb_pool(dao_cfg)
    return dao
