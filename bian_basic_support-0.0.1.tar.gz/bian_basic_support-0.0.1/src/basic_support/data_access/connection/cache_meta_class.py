#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: cache_meta_class.py
@Description: 
@time: 2020/7/25 9:12
"""


class RdbConnCache(type):
    """
    缓存数据库连接，按配置进行hash计算键值
    ps: 这里需要返回对象的conn属性
    """

    def __init__(cls, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # TODO 后续考虑使用弱引用
        # cls.__cache = weakref.WeakValueDictionary()
        cls.__cache = {}

    def __call__(cls, *args, **kwargs):
        kw_lst = [(k,v) for k,v in kwargs.items()]
        kw_lst.sort(key=lambda i:i[0])
        key = str(args)+"::"+str(kw_lst)
        if key in cls.__cache:
            return cls.__cache[key]
        else:
            obj = super().__call__(*args,**kwargs)
            cls.__cache[key] = obj
            return cls.__cache[key]

# class Singleton(type):
#     def __init__(cls, *args, **kwargs):
#         cls.__instance = None
#         super().__init__(*args, **kwargs)
#
#     def __call__(cls, *args, **kwargs):
#         if cls.__instance is None:
#             cls.__instance = super().__call__(*args, **kwargs)
#             return cls.__instance
#         else:
#             return cls.__instance
#
#
# class Cached(type):
#     def __init__(cls, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         cls.__cache = weakref.WeakValueDictionary()
#
#     def __call__(cls, *args):
#         if args in cls.__cache:
#             return cls.__cache[args]
#         else:
#             obj = super().__call__(*args)
#             cls.__cache[args] = obj
#             return obj
