#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: es_conn.py
@Description: 
@time: 2020/7/24 23:54
"""
from basic_support.data_access.connection.db_connection_abs import AbstractRawConnection
from elasticsearch import Elasticsearch


class EsConn(AbstractRawConnection):
    """
    获取es库连接
    """

    def __init__(
        self, 
        hosts, 
        timeout=3600 * 24, 
        **kwargs
    ):
        super(EsConn, self).__init__()
        self.timeout = timeout
        self.conn = Elasticsearch(
            hosts, timeout=timeout, **kwargs
        )
