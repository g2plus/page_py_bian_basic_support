#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: hdfs_conn.py
@Description: hdfs连接类
@time: 2021/11/12 15:13
"""

from typing import Dict

from hdfs3 import HDFileSystem
from hdfs3.utils import MyNone

from basic_support.data_access.connection.db_connection_abs import AbstractRawConnection


class HdfsConn(AbstractRawConnection):
    def __init__(self, host: str = MyNone, port: int = MyNone,
                 connect: bool = True, autoconf: bool = True,
                 pars: Dict[str, str] = None):
        """

        @param host: Overrides which take precedence over information in conf files and other passed parameters
        @param port:
        @param connect: Whether to automatically attempt to establish a connection to the name-node.
        @param autoconf: Whether to use the configuration found in the conf module as the set of defaults
        @param pars: any parameters for hadoop, that you can find in hdfs-site.xml,
                     https://hadoop.apache.org/docs/r2.6.0/hadoop-project-dist/hadoop-hdfs/hdfs-default.xml
                     This dict looks exactly like the one produced by conf - you can,
                     for example, remove any problematic entries.
        """
        super(HdfsConn, self).__init__()
        self.conn = HDFileSystem(host=host, port=port, connect=connect, autoconf=autoconf, pars=pars)
