#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: rdb_conn.py
@Description: 
@time: 2020/7/24 23:31
"""
from basic_support.data_access.connection.db_connection_abs import AbstractRdbConn
from basic_support.data_access.config.impl.rdb_config import RdbConfig
import importlib


class PgConn(AbstractRdbConn):
    """
    获取pg库连接
    """

    def __init__(self, config: RdbConfig, timeout=1000):
        super(PgConn, self).__init__()
        # self.timeout = timeout
        psycopg = importlib.import_module("psycopg")
        self.conn = psycopg.connect(host=config.host,
                                    port=config.port,
                                    user=config.user,
                                    password=config.password,
                                    database=config.db,
                                    keepalives=1,
                                    keepalives_idle=30,
                                    keepalives_interval=10,
                                    keepalives_count=5)

    @staticmethod
    def get_conn_str(config: RdbConfig, charset):
        return f'postgresql://{config.user}:{config.password}@{config.host}:{config.port}/{config.db}?charset={charset}'


class MysqlConn(AbstractRdbConn):
    """
    获取Mysql库连接
    """

    def __init__(self, rdb_config: RdbConfig, charset="utf8mb4", timeout=1000):
        super(MysqlConn, self).__init__()
        pymysql = importlib.import_module("pymysql")
        self.conn = pymysql.connect(host=rdb_config.host,
                                    port=rdb_config.port,
                                    user=rdb_config.user,
                                    password=rdb_config.password,
                                    db=rdb_config.db,
                                    charset=charset,
                                    cursorclass=pymysql.cursors.DictCursor)

    @staticmethod
    def get_conn_str(config: RdbConfig, charset="utf8mb4"):
        return f'mysql+pymysql://{config.user}:{config.password}@{config.host}:{config.port}/{config.db}?charset={charset}'


class OracleConn(AbstractRdbConn):
    """
    获取Oracle库连接
    """

    def __init__(self, config: RdbConfig, encoding="UTF-8", timeout=1000):
        super(OracleConn, self).__init__()
        conn_str = str(config.user) + "/" + str(config.password)
        conn_str += "@" + str(config.host)
        conn_str += ":" + str(config.port)
        conn_str += "/" + str(config.db)
        cx_Oracle = importlib.import_module("cx_Oracle")
        self.conn = cx_Oracle.connect(conn_str, encoding=encoding, nencoding=encoding)

    @staticmethod
    def get_conn_str(config: RdbConfig, encoding="UTF-8"):
        return f'oracle://{config.user}:{config.password}@{config.host}:{config.port}/{config.db}?charset={encoding}'
