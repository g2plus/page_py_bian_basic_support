#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: dao_utils.py
@Description: dao有关的工具函数，简化一些操作
@time: 2023/11/6 15:24
"""
from typing import List, Iterable, Tuple, Callable, Dict
from typing import Mapping

from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao
from basic_support.logger.logger_config import logger


class DaoUtils:

    @staticmethod
    def utils_inject_insert_sql(dao: AbstractRdbDao, sql: str = None) -> Callable[[Iterable[Mapping]], None]:
        """
        将sql注入到dao中，产生一个带sql的到函数
        :param dao: dao对象
        :param sql: 入库sql
        :return:
        """
        dao, sql = dao, sql

        def inner(values: Iterable[Mapping]):
            dao.insert_batch_row(sql=sql, values=values)

        return inner

    @staticmethod
    def utils_inject_insert_sql_with_params(dao: AbstractRdbDao, table_name: str, params: List[str],
                                            time_cols: Tuple[str, ...] = None) \
            -> Tuple[Callable[[Iterable[Mapping]], None], str]:
        """
        生成insert sql，并将sql注入到dao中，产生一个带sql的到函数
        :param dao: dao对象
        :param table_name: 表名
        :param params:
        :param time_cols:
        :return:
        """
        sql = dao.utils_gen_insert_sql(table_name=table_name, params=params, time_cols=time_cols)
        return DaoUtils.utils_inject_insert_sql(dao=dao, sql=sql), sql

    @staticmethod
    def utils_get_last_version(dao: AbstractRdbDao, table_name: str, version_col: str = 'version',
                               conditions: str = None) -> int:
        """
        获取指定表的最大版本号+1(即本次需要写入的版本号)
        :param dao: dao对象
        :param table_name: 表名
        :param version_col: 版本字段(int类型)
        :param conditions: 查询条件
        :return: 最大版本号
        """
        if not dao.is_exist_table(table_name=table_name):
            return -1
        conditions_str = f' where {conditions}' if conditions else ''
        sql = f"SELECT (CASE WHEN MAX({version_col}) IS NULL THEN -1 ELSE MAX({version_col}) END) + 1 AS version FROM {table_name}{conditions_str}"
        last_version = dao.get_one_row(sql=sql)['version']
        return last_version

    @staticmethod
    def utils_select_records(dao: AbstractRdbDao, table_name: str, cols: List[str] = None,
                             as_dict: Dict[str, str] = None, conditions: str = None, orderby: List[str] = None,
                             desc: bool = False, limit: int = None) -> Iterable:
        """
        数据库记录查询工具方法(单表的查询)
        :param dao: dao对象
        :param table_name: 表名
        :param cols: 查询的列
        :param as_dict: 查询别名
        :param conditions: 查询条件
        :param orderby: 排序字段
        :param desc: 是否降序
        :param limit: 记录限制
        :return: 记录迭代器
        """
        as_dict = as_dict or dict()
        inner_as_dict = {k: f' as {v}' for k, v in as_dict.items()}
        col_str = ', '.join(f"{col}{inner_as_dict.get(col, '')}" for col in cols) if cols else '*'
        orderby_str = ','.join(orderby) if orderby else ''

        # 构建sql
        sql = f"select {col_str} from {table_name}"
        if conditions:
            sql = f"{sql} where {conditions}"
        if orderby_str:
            desc_str = 'desc' if desc else 'asc'
            sql = f"{sql} order by {orderby_str} {desc_str}"
        if limit:
            sql = f"{sql} limit {limit}"

        logger.info(f"生成的查询sql为: {sql}")

        yield from dao.query_batch_iter(sql=sql)
