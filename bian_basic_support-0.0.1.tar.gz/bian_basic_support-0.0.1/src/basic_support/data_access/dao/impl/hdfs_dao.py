#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: hdfs_dao.py
@Description: https://blog.csdn.net/u013429010/article/details/81772130
              https://hdfs3.readthedocs.io/en/latest/
              https://www.jianshu.com/p/68472b6fc7f7
@time: 2021/11/12 15:10
"""

from hdfs3.core import DEFAULT_WRITE_BUFFER_SIZE

from basic_support.data_access.connection.conn_impl.hdfs_conn import HdfsConn
from basic_support.data_access.dao.base_dao_abs import BaseDao


class HdfsDao(BaseDao):
    def __init__(self, hdfs_conn: HdfsConn):
        super(HdfsDao, self).__init__()
        self.hdfs_conn = hdfs_conn

    def disconnect(self):
        return self.hdfs_conn.conn()

    def open(self, path, mode='rb', replication=0, buff=0, block_size=0):
        return self.hdfs_conn.conn.open(path=path, mode=mode, replication=replication, buff=buff, block_size=block_size)

    def isdir(self, path: str):
        return self.hdfs_conn.conn.isdir(path=path)

    def isfile(self, path):
        return self.hdfs_conn.conn.isfile(path=path)

    def walk(self, path):
        return self.hdfs_conn.conn.walk(path=path)

    def host(self):
        return self.hdfs_conn.conn.host()

    def port(self):
        return self.hdfs_conn.conn.port()

    def mkdir(self, path):
        return self.hdfs_conn.conn.mkdir(path=path)

    def makedirs(self, path, mode=0o711):
        return self.hdfs_conn.conn.makedirs(path=path, mode=mode)

    def mv(self, path1, path2):
        return self.hdfs_conn.conn.mv(path1=path1, path2=path2)

    def rm(self, path, recursive=True):
        return self.hdfs_conn.conn.rm(path=path, recursive=recursive)

    def exists(self, path):
        return self.hdfs_conn.conn.exists(path=path)

    def chmod(self, path, mode):
        return self.hdfs_conn.conn.chmod(path=path, mode=mode)

    def cat(self, path):
        return self.hdfs_conn.conn.cat(path=path)

    def put(self, filename, path, chunk=DEFAULT_WRITE_BUFFER_SIZE, replication=0, block_size=0):
        return self.hdfs_conn.conn.put(filename=filename, path=path, chunk=chunk, replication=replication,
                                       block_size=block_size)

    def tail(self, path, size=1024):
        return self.hdfs_conn.conn.tail(path=path, size=size)

    def head(self, path, size=1024):
        return self.hdfs_conn.conn.head(path=path, size=size)

    def touch(self, path):
        return self.hdfs_conn.conn.touch(path=path)
