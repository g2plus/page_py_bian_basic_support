#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: oracle_dao.py
@Description: 
@time: 2020/7/25 1:54
"""
import contextlib
from typing import Mapping, Dict, Iterator, List, Tuple

from basic_support.data_access.connection.db_connection_abs import AbstractRdbPool
from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao
from basic_support.data_access.dao.rdb_meta import RdbSchema
from basic_support.logger.logger_config import logger


class OracleDao(AbstractRdbDao):
    def __init__(self, base_db_conn: AbstractRdbPool):
        super(OracleDao, self).__init__(base_db_conn)

    def default_cur_parse(self, cur):
        """
        对cur信息进行处理
        @param cur: 游标
        @return: 对cur的解析结果，作为default_deal_fun的rdb_schemas参数
        """
        return [RdbSchema(col_name=descp[0].lower(), col_type=descp[1]) for descp in cur.description]

    # def default_deal_fun(self, record, rdb_schemas, encoding='UTF-8') -> Mapping:
    #    import cx_Oracle
    #    lst = {}
    #    for des, red in zip(rdb_schemas, record):
    #        if des.col_type is cx_Oracle.BLOB:
    #            res = red.read()
    #            try:
    #                lst[des.col_name] = res.decode('GB18030')
    #            except Exception as e:
    #                logger.exception('解码错误: %s\n具体错误为: %s' % (res, e))
    #                return None
    #        elif des.col_type is cx_Oracle.CLOB:
    #            lst[des.col_name] = red.read()
    #        else:
    #            lst[des.col_name] = red
    #    return lst

    def default_deal_fun(self, record, rdb_schemas, encoding='UTF-8') -> Mapping or None:
        """
        对查询结果进行处理，得到自己需要的结果
        @param record: 一条数据查询结果
        @param rdb_schemas: default_cur_parse的返回结果，一般是传入数据表的schemas信息
        @param encoding: 编码方式
        @return: 查询结果的处理输出
        """
        import cx_Oracle
        lst = {}
        for des, red in zip(rdb_schemas, record):
            if des.col_type is cx_Oracle.BLOB:
                if red is None:
                    res = None
                else:
                    res = red.read()
                # encoding=cchardet.detect(res)['encoding']
                # import pdb;pdb.set_trace()
                try:
                    lst[des.col_name] = res.decode(encoding)
                except Exception as e:
                    logger.exception('解码错误: %s\n具体错误为: %s' % (res, e))
                    return None
            elif des.col_type is cx_Oracle.CLOB:
                lst[des.col_name] = red.read()
            else:
                lst[des.col_name] = red
        return lst

    def drop_table(self, table_name: str, commit: bool = True):
        """
        删除表
        @param table_name: 需要清空数据的表名
        @param commit: 是否提交到数据库，默认会自动提交
        @return:
        """
        drop_sql = f'DROP TABLE {table_name}'
        self.execute_sql_with_params(sql=drop_sql, commit=commit)
        logger.info(f'{table_name}删除表完成')

    def execute_sql_with_params(self, sql: str, params: Mapping or None = None, commit: bool = True):
        """
        带参数列表执行sql，主要用于增删改数据以及建表、清空表和删除表操作
        @param sql: sql语句
        @param params: 参数
        @param commit: 是否提交到数据库，默认会自动提交
        @return: 执行脚本的结果
        """
        params = params if params else {}
        return super().execute_sql_with_params(sql=sql, params=params, commit=commit)

    def _deal_batch(self, records, rdb_schemas, encoding):
        for record in records:
            yield self.default_deal_fun(record, rdb_schemas, encoding)

    def query_batch_row(self, sql: str, params: Mapping or None = None, batch_size=1000, encoding='UTF-8',
                        to_dict: bool = True) -> Iterator[Iterator[Mapping] or Iterator[Tuple]]:
        """
        按批查询数据
        @param sql: 查询语句
        @param params: 参数, 暂时没用
        @param batch_size: 查询批次大小
        @param encoding: 编码方式
        @param to_dict: 是否将结果转为字典形式
        """
        conn, is_close = self.get_inner_conn
        try:
            with conn.cursor() as cur:
                # TODO params带入
                cur.execute(sql)
                rdb_schemas = self.default_cur_parse(cur)
                while records := cur.fetchmany(batch_size):
                    yield self._deal_batch(records, rdb_schemas, encoding) if to_dict else records
        except Exception as e:
            logger.exception(e)
            raise Exception(f'读取数据出错，具体错误如下：\n{e}')
        finally:
            if is_close:
                conn.close()

    @contextlib.contextmanager
    def dict_cur(self, conn, to_dict: bool = True):
        """
        获取字典型的连接
        :param conn: 数据库连接
        :param to_dict: 是否将结果转为字典形式
        """
        pass

    def query_table_meta(self, table_name: str, to_py: bool = True) -> Dict:
        """
        查看表的meta信息
        @param table_name: 表明
        @param to_py: 是否转python类型
        @return:
        """
        raise Exception("未实现的抽象方法！")

    def upsert_batch(self, table_name: str, values: List[Dict], conflict: Tuple[str, ...], batch_size: int = 5000,
                     update_cols: Tuple[str, ...] = None):
        """
        批量更新或写入
        @param table_name: 表名
        @param values: 需要写入的值列表
        @param conflict: 冲突字段
        @param batch_size: 批量大小
        @param update_cols: 更新字段
        """
        raise Exception("未实现的抽象方法！")

    @staticmethod
    def utils_gen_insert_sql(table_name: str, params: List[str], time_cols: Tuple[str, ...] = None) -> str:
        raise Exception("未实现的抽象方法！")
