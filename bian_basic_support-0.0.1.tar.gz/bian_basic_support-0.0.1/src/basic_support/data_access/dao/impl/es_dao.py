# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: es_dao.py
@Description: Es统一操作类
@time: 2020/4/27 10:22
"""

import json
import logging
import os
from collections import ChainMap
from os import path
from typing import Generator, Dict, List, Mapping, Callable

import pandas as pd
from elasticsearch.helpers import bulk, parallel_bulk

from basic_support.comm_funcs.comm_utils import iter_slice_tool
from basic_support.data_access.connection.conn_impl.es_conn import EsConn
from basic_support.data_access.dao.base_dao_abs import BaseDao

logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("elasticsearch").setLevel(logging.WARNING)


class EsDao(BaseDao):
    """
    非关系型数据库dao父类，目前只有es的实现
    """

    def __init__(self, es_conn: EsConn):
        super(EsDao, self).__init__()
        self.es_conn = es_conn

    @classmethod
    def init_from_str(cls, hosts: str, timeout: int = 3600 * 24, **kwargs):
        """
        从字符串构建实例对象
        :param hosts: es地址字符串
        :param timeout: 超时
        :param kwargs: 其他参数
        :return:
        """
        return cls(EsConn(hosts, timeout, **kwargs))

    def max(self, index_name, field):
        query_body = {"sort": [{field: {"order": "desc"}}]}
        result = self.es_conn.conn.search(index=index_name, body=query_body, size=1, _source_include=[field])
        return result['hits']['hits'][0]['_source'][field] if result['hits']['hits'] else None

    def slice_scroll_page(self, index: str, body, slice_idx, max_slice=None, doc_type=None, scroll='1m', size=2000):
        """
        es中的slice_scroll分页查询
        @param max_slice: 最大切片数目
        @param slice_idx: 切片索引
        @param index: 索引名称
        @param body: 查询体
        @param doc_type: 文档类型
        @param scroll: 快照时间
        @param size: 分页大小
        @return:
        """
        cluster_shards = len(self.es_conn.conn.search_shards(index, doc_type)['shards'][0])
        # if max_slice:
        #     if max_slice > cluster_shards:
        #         warnings.warn(f'max_slice值最好不超过集群shards数目{cluster_shards}!')
        # else:
        #     max_slice = cluster_shards
        max_slice = max_slice or cluster_shards
        if slice_idx >= max_slice:
            raise Exception(f'切片索引值为{slice_idx},须小于最大切片{max_slice}')
        slice_scroll_body = {
            "slice": {
                "id": slice_idx,
                "max": max_slice
            },
            "sort": [
                "_doc"
            ]
        }
        body = dict(ChainMap(body, slice_scroll_body))
        page = self.es_conn.conn.search(index=index, doc_type=doc_type, scroll=scroll, body=body, size=size)
        scroll_id = page['_scroll_id']
        scroll_size = page['hits']['total']

        while scroll_size > 0:
            document = [document['_source'] for document in page["hits"]["hits"]]
            yield from document
            page = self.es_conn.conn.scroll(scroll_id=scroll_id, scroll=scroll, request_timeout=30)
            scroll_id = page['_scroll_id']
            scroll_size = len(page['hits']['hits'])
        self.es_conn.conn.clear_scroll(body={'scroll_id': scroll_id})

    def save_data_list(
        self, 
        index_name: str, 
        data_list: List[Dict], 
        chunk_size: int = 5000,
        max_retries:int = 0
    ):
        """
        保存数据列表到es的指定索引中
        :param index_name: 索引名称
        :param data_list: 数据列表，列表元素代表一行数据，元素类型为dict
        :param chunk_size: 写入批次大小
        :return:
        """

        if len(data_list) > 0 and '_id' in data_list[0]:
            for _, bulk_data in iter_slice_tool(data_list, chunk_size):
                actions = [{
                    "_index": index_name,
                    # "_type": index_name,
                    "_id": data.pop("_id"),
                    "_source": data
                }
                    for data in bulk_data
                ]
                bulk(
                    self.es_conn.conn, 
                    actions, 
                    index=index_name, 
                    raise_on_error=True, 
                    chunk_size=chunk_size,
                    max_retries=max_retries
                )
        else:
            for _, bulk_data in iter_slice_tool(data_list, chunk_size):
                actions = [{
                    "_index": index_name,
                    # "_type": index_name,
                    "_source": data
                }
                    for data in bulk_data
                ]
                bulk(
                    self.es_conn.conn, actions, 
                    index=index_name, 
                    raise_on_error=True, 
                    chunk_size=chunk_size,
                    max_retries=max_retries
                )

    def is_index_exists(self, index_name: str):
        """
        判断指定索引是否存在
        :param index_name: 索引名称
        :return:
        """
        return self.es_conn.conn.indices.exists(index=index_name)

    def delete_by_query(self, index_name: str, query_body):
        """
        按查询结果删除数据
        :param index_name:
        :param query_body:
        :return:
        """
        return self.es_conn.conn.delete_by_query(index_name, query_body)

    def clear_index_data(self, index_name: str, doc_type=None):
        """
        清空指定索引的数据
        :param index_name: 需要清空索引名
        :return: 是否清空成功
        """
        # return self.delete_by_query(index_name=index_name,query_body={"query": {"match_all": {}}})
        mapping = self.query_index_mapping(index_name=index_name) \
            ['mappings'][doc_type or index_name]['properties']
        if self.delete_index(index_name):
            return self.create_index(index_name, mapping, doc_type)
        return False

    def delete_index(self, index_name: str):
        """
        删除指定索引
        :param index_name: 需要删除索引名
        :return: 是否删除成功
        """
        if self.is_index_exists(index_name):
            return self.es_conn.conn.indices.delete(index=index_name)['acknowledged']
        return False

    def save_df_data(self, index_name: str, df):
        """
        保存pandas的DataFrame到es的指定索引中
        :param index_name: 索引名称
        :param df: 要保存的dataframe
        :return:
        """
        col_lst = df.columns.tolist()
        dic_lst = [dict([(c, v) for c, v in zip(col_lst, r)]) for r in df.values.tolist()]
        self.save_data_list(index_name=index_name, data_list=dic_lst)

    def create_index(
        self, 
        index_name: str, 
        mapping_properties: Dict, 
        doc_type=None,
        settings=None,
        timeout=None
    ):
        """
        创建索引
        :param index_name: 索引名称
        :param mapping_properties: 索引mapping中的属性列表
        :return:
        """
        if not self.es_conn.conn.indices.exists(index=index_name):
            body = {
                "mappings": {
                    # doc_type or index_name: {
                        "properties": mapping_properties
                    # }
                }
            }
            if settings is not None:
                body["settings"] = settings
            res = self.es_conn.conn.indices.create(index=index_name, body=body, timeout=timeout)
            if res is not None and 'acknowledged' in res:
                return res.get('acknowledged')
        return False
    
    def search(self,index_name:str, query_body: Dict, **kwargs)->Generator[any,None,None]:
        ret = self.es_conn.conn.search(
            index=index_name,
            body=query_body,
            **kwargs
        )
        hits = ret["hits"]["hits"]
        for hit in hits:
            d = hit["_source"].copy()
            d["_id"] = hit["_id"]
            d["_score"] = hit["_score"]
            yield d

    def query_for_df(self, index_name: str, query_body: Dict, query_parse_fun=None) -> pd.DataFrame:
        """
        执行查询并获取pandas.DataFrame格式的返回值
        :param index_name: 索引名称
        :param query_body: 查询条件
        :param query_parse_fun: 查询结果解析函数
        :return:
        """
        sources = []
        for sub_source in self._search_with_scroll(index_name=index_name, query_body=query_body,
                                                   query_parse_fun=query_parse_fun):
            sources.extend(sub_source)
        return pd.DataFrame(sources)

    def query_for_data_list(self, index_name: str, query_body: Dict, query_parse_fun=None) -> List[Dict]:
        """
        执行查询并获取pandas.DataFrame格式的返回值
        :param index_name: 索引名称
        :param query_body: 查询条件
        :param query_parse_fun: 查询结果解析函数
        :return:
        """
        sources = []
        for sub_source in self._search_with_scroll(index_name=index_name, query_body=query_body,
                                                   query_parse_fun=query_parse_fun):
            sources.extend(sub_source)
        return sources

    def query_for_data_flow(self,
                            index_name: str,
                            query_body: Dict,
                            query_parse_fun: Callable = None,
                            query_batch_size: int = 10000) -> Generator[Dict, None, None]:
        """
        执行查询并按一行一行的数据流的形式返回数据
        :param index_name: 索引名称
        :param query_body: 查询条件
        :param query_parse_fun: 查询结果处理函数
        :param query_batch_size: 查询批次大小
        :return:
        """
        if "size" not in query_body:
            query_body["size"] = query_batch_size
        for sub_source in self._search_with_scroll(index_name=index_name, query_body=query_body,
                                                   query_parse_fun=query_parse_fun):
            if sub_source is not None:
                for item in sub_source:
                    yield item

    def query_for_df_with_batch(self,
                                index_name: str,
                                query_body: Dict,
                                query_batch_size: int = 5000,
                                query_parse_fun=None) -> Generator[pd.DataFrame, None, None]:
        """
        按批次大小查询并返回pandas.DataFrame的generator格式的返回值
        :param index_name: 索引名称
        :param query_body: 查询条件
        :param query_batch_size: 批次大小
        :param query_parse_fun: 查询结果处理函数
        :return:
        """
        if "size" not in query_body:
            query_body["size"] = query_batch_size
        for sub_source in self._search_with_scroll(index_name=index_name, query_body=query_body,
                                                   query_parse_fun=query_parse_fun):
            yield pd.DataFrame(sub_source)

    def query_for_data_list_with_batch(self,
                                       index_name: str,
                                       query_body: Dict,
                                       query_batch_size: int = 5000,
                                       query_parse_fun=None) -> Generator[Dict, None, None]:
        """
        按批次大小查询并返回Dict的generator格式的返回值
        :param index_name: 索引名称
        :param query_body: 查询条件
        :param query_batch_size: 批次大小
        :param query_parse_fun: 查询结果处理函数
        :return:
        """
        if "size" not in query_body:
            query_body["size"] = query_batch_size
        for sub_source in self._search_with_scroll(index_name=index_name, query_body=query_body,
                                                   query_parse_fun=query_parse_fun):
            yield sub_source

    def get_first_row_with_df(self, index_name: str, query_parse_fun=None):
        """
        获取指定索引的首行数据，格式为pandas.DataFrame
        可用于获取索引的元信息
        :param index_name: 索引名称
        :param query_parse_fun: 查询结果处理函数
        :return:
        """
        query_body = {
            "size": 1,
            "query": {
                "match_all": {}
            }
        }
        for sub_source in self._search_with_scroll(index_name=index_name, query_body=query_body,
                                                   query_parse_fun=query_parse_fun):
            return pd.DataFrame(sub_source)

    def _search_with_scroll(self, index_name: str, query_body: Dict, query_batch_size: int = 5000,
                            query_parse_fun: Callable = None):
        """
        具体查询逻辑实现
        @param index_name: 索引名
        @param query_body: 查询体
        @param query_batch_size: 查询批次大小
        @param query_parse_fun: 查询结果处理函数 如：lambda response: response["aggregations"][aggs_name]["buckets"]
        """
        if "size" not in query_body:
            query_body["size"] = query_batch_size
        response = self.es_conn.conn.search(
            index=index_name,
            body=query_body,
            search_type="dfs_query_then_fetch",
            scroll="180m",
            timeout="120m"
        )
        scroll_id = response["_scroll_id"]

        inner_query_parse = query_parse_fun or self.default_query_parse
        query_parse, doc_parse = inner_query_parse(query_body)

        while True:
            sources = [doc_parse(doc) for doc in query_parse(response)]
            if len(sources) == 0:
                break
            yield sources
            response = self.es_conn.conn.scroll(scroll_id=scroll_id, scroll="180m")

    def default_query_parse(self, query_body=None):
        """
        查询默认解析方法
        @param query_body:　查询体
        @return: 解析方法
        """
        # if "aggs" in query_body:
        #     aggs_name = list(query_body['aggs'].keys())[0]
        #     return lambda response: response["aggregations"][aggs_name]["buckets"], lambda d: d
        # else:
        return lambda response: response["hits"]["hits"], lambda d: d["_source"]

    def query_index_mapping(self, index_name: str, doc_type=None) -> Mapping:
        """
        根据index获取mapping信息
        @param index_name:　索引名称
        @param doc_type:　文档类型
        @return: mapping信息
        """
        mapping_infos = self.es_conn.conn.indices.get_mapping(index=index_name, doc_type=doc_type)
        return mapping_infos[index_name]

    def agg_query_for_data_list(self, index_name: str, query_body: Dict):
        """
        简单聚合查询
        @param index_name: 索引名称
        @param query_body: 查询条件
        @return: 聚合查询结果
        """
        aggs_name = list(query_body['aggs'].keys())[0]
        response = self.es_conn.conn.search(index=index_name, body=query_body)
        return response["aggregations"][aggs_name]["buckets"]

    def parallel_write(self, index_name: str, data_flow: List[Dict],
                       thread_count: int = 4,
                       chunk_size: int = 500,
                       max_chunk_bytes: int = 100 * 1024 * 1024,
                       queue_size: int = 4,):
        """
        并行化写入
        :param action:
        :param index_name: 索引名
        :param data_flow: 数据流
        :param thread_count: size of the threadpool to use for the bulk requests
        :param chunk_size: number of docs in one chunk sent to es (default: 500)
        :param max_chunk_bytes: the maximum size of the request in bytes (default: 100MB)
        :param queue_size: size of the task queue between the main thread (producing
        chunks to send) and the processing threads.
        """
        action = {"_index": index_name,
                  "_type": '_doc'}

        def actions(input_data):
            for data in input_data:
                _id=data.pop('_id') if data.get('_id') else None
                if _id:
                    action['_id']=_id
                action['_source'] = data
                yield action

        response = parallel_bulk(self.es_conn.conn, actions(data_flow), thread_count=thread_count,
                                 chunk_size=chunk_size,
                                 max_chunk_bytes=max_chunk_bytes,
                                 queue_size=queue_size)
        for success, info in response:
            if not success:
                print('A document failed:', info)

    def upsert_doc(self, index_name: str, doc_id, query_body, retry_on_conflict=20):
        self.es_conn.conn.update(index=index_name, doc_type='_doc', id=doc_id, body=query_body,
                                 retry_on_conflict=retry_on_conflict)  #

    def query_by_doc_id(self, index_name: str, doc_id, feature_field):
        doc = self.es_conn.conn.get(index=index_name, id=doc_id, doc_type='_doc')['_source']
        return {k: v for k, v in doc.items() if k in feature_field}  #

    def data_export_with_txt(self, index_name: str, query_body: Dict, base_path: str = '.', write_batch_size=5000):
        """
        将数据从es库导出到本地，包括mapping和数据部分
        :param index_name: 索引名
        :param query_body: 查询体
        :param base_path: 数据文件路径
        :param write_batch_size: 每次导出batch大小
        :return:
        """
        base_path = path.join(base_path, index_name)
        if not path.exists(base_path):
            os.makedirs(base_path)

        # 1. 索引信息导出
        meta_path = path.join(base_path, f"{index_name}.json")
        meta_infos = self.query_index_mapping(index_name=index_name)['mappings'][index_name]['properties']
        with open(meta_path, 'w', encoding='utf-8') as f:
            f.write(json.dumps(meta_infos, ensure_ascii=False))

        # 2. 索引数据导出
        data_path = path.join(base_path, f"{index_name}.txt")
        with open(data_path, 'w', encoding='utf-8') as file:
            data_lst = []
            for data in self.query_for_data_flow(index_name, query_body):
                data_lst.append(str(data) + '\n')
                if len(data_lst) >= write_batch_size:
                    file.writelines(data_lst)
                    data_lst = []
            if data_lst:
                file.writelines(data_lst)
        return True

    def data_import_with_txt(self, base_path: str, index_name: str = None, write_batch_size=5000):
        """
        将数据导入es库
        :param base_path: 数据文件路径
        :param index_name: 索引名，默认None，表示索引与文件夹同名
        :param write_batch_size: 每次导入batch大小
        :return:
        """
        files = os.listdir(base_path)
        meta_path, data_path = None, None
        for file in files:
            if file.endswith(".json"):
                meta_path = path.join(base_path, file)
            elif file.endswith(".txt"):
                data_path = path.join(base_path, file)
        index_name = index_name or path.split(meta_path)[1][:-5]

        # 1. 新建索引
        mapping = json.loads(open(meta_path, 'r', encoding='utf-8').readline())
        self.create_index(index_name=index_name, mapping_properties=mapping)

        # 2. 写入数据
        with open(data_path, 'r', encoding='utf-8') as file:
            datas = []
            for line in file.readlines():
                datas.append(eval(line.strip()))
                if len(datas) >= write_batch_size:
                    self.parallel_write(index_name=index_name, data_flow=datas)
                    datas = []
            if datas:
                self.save_data_list(index_name=index_name, data_list=datas)
        return True
