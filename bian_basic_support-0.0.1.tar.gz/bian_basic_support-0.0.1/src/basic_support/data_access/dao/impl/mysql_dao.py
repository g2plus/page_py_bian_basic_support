#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: mysql_dao.py
@Description: 
@time: 2020/7/25 1:54
"""
import contextlib
from typing import Dict, List, Tuple

from basic_support.data_access.connection.db_connection_abs import AbstractRdbPool
from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao


class MysqlDao(AbstractRdbDao):
    def __init__(self, base_db_conn: AbstractRdbPool):
        super(MysqlDao, self).__init__(base_db_conn)

    # def default_cur_parse(self, cur):
    #     return [RdbSchema(col_name=descp[0], col_type=descp[1]) for descp in cur.description]
    #
    # def default_deal_fun(self, record, rdb_schemas, encoding='UTF-8') -> Mapping:
    #     if type(record) == dict:
    #         return record
    #     lst = {}
    #     for des, red in zip(rdb_schemas, record):
    #         lst[des.col_name] = red
    #     return lst

    # def default_deal_fun(self, record, rdb_schemas, encoding='UTF-8') -> Mapping:
    #     lst = {}
    #     for des, red in zip(rdb_schemas, record):
    #         if isinstance(red, bytes):
    #             try:
    #                 lst[des.col_name] = red.decode(encoding)
    #             except:
    #                 lst[des.col_name] = red
    #         else:
    #             lst[des.col_name] = red
    #     return lst

    @contextlib.contextmanager
    def dict_cur(self, conn, to_dict: bool = True):
        """
        获取字典型的连接
        :param conn: 数据库连接
        :param to_dict: 是否将结果转为字典形式
        """
        from pymysql.cursors import DictCursor
        cur = conn.cursor(cursor=DictCursor) if to_dict else conn.cursor()
        yield cur
        cur.close()

    def query_table_meta(self, table_name: str, to_py: bool = True) -> Dict:
        """
        查看表的meta信息
        @param table_name: 表明
        @param to_py: 是否转python类型
        @return:
        """
        raise Exception("未实现的抽象方法！")

    def upsert_batch(self, table_name: str, values: List[Dict], conflict: Tuple[str, ...], batch_size: int = 5000,
                     update_cols: Tuple[str, ...] = None):
        """
        批量更新或写入
        @param table_name: 表名
        @param values: 需要写入的值列表
        @param conflict: 冲突字段
        @param batch_size: 批量大小
        @param update_cols: 更新字段
        """
        raise Exception("未实现的抽象方法！")

    @staticmethod
    def utils_gen_insert_sql(table_name: str, params: List[str], time_cols: Tuple[str, ...] = None) -> str:
        raise Exception("未实现的抽象方法！")
