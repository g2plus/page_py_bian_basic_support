#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: pg_dao.py
@Description:
https://www.psycopg.org/docs/usage.html#adaptation-of-python-values-to-sql-types
@time: 2020/7/25 1:54
"""
import contextlib
import csv
import importlib
import os
import re
from collections.abc import Sized
from copy import deepcopy
from datetime import datetime, date
from functools import lru_cache
from functools import partial
from io import StringIO
from threading import Lock
from typing import Dict, List, Tuple, Set, Iterator
from typing import Iterable, Mapping

from dbutils.pooled_db import PooledDB
from psycopg import ServerCursor
from psycopg import sql as pg_sql
from psycopg.rows import dict_row

from basic_support.comm_funcs.comm_utils import gen_uuid32, iter_slice_tool
from basic_support.data_access.connection.db_connection_abs import AbstractRdbPool
from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao, sql_format, extract_table_name_from_insert
from basic_support.logger.logger_config import logger

to_py_dict = {'character': str, 'text': str, 'uuid': str,
              'double': float, 'integer': int, 'bigint': int,
              'boolean': bool,
              'timestamp': datetime, 'date': date}
# 查找表名和插入列
# sql_search_pattern = re.compile(r'insert\s+into\s+(\w+)\s+\(?([\w,\s]*?)\)?\s*values', re.I)
sql_search_pattern = re.compile(r'insert\s+into\s+(\w+?\.?\w+)\s*\(?([\w,\s"\']*)\)?\s*values', re.I)


def has_len(obj):
    return isinstance(obj, Sized)


class PgDao(AbstractRdbDao):
    def __init__(self, base_db_conn: AbstractRdbPool):
        super(PgDao, self).__init__(base_db_conn)
        self.type_dict = {}
        self.lock = Lock()

    @lru_cache(maxsize=128)
    def _get_table_cols(self, table_name: str) -> List[str]:
        meta_dict = self.query_table_meta(table_name=table_name)
        return list(meta_dict.keys())

    # def default_cur_parse(self, cur):
    #     if cur.description:
    #         return [RdbSchema(col_name=descp.name, col_type=descp.type_code) for descp in cur.description]
    #     if cur._cursor.description:
    #         return [RdbSchema(col_name=descp.name, col_type=descp.type_code) for descp in cur._cursor.description]
    #     raise Exception(f"获取描述信息时异常, cur.description: {cur.description}")
    #
    # def default_deal_fun(self, record, rdb_schemas, encoding='UTF-8') -> Mapping:
    #     if type(record) == dict:
    #         return record
    #     lst = {}
    #     for des, red in zip(rdb_schemas, record):
    #         if des.col_type == 1114:
    #             lst[des.col_name] = str(red)
    #         else:
    #             lst[des.col_name] = red
    #     return lst

    @contextlib.contextmanager
    def dict_cur(self, conn, to_dict: bool = True):
        """
        获取字典型的连接
        :param conn: 数据库连接
        :param to_dict: 是否将结果转为字典形式
        psycopg2的语法: cur = conn.cursor(cursor_factory=RealDictCursor) if to_dict else conn.cursor()
        """
        from psycopg.rows import dict_row
        cur = conn.cursor(row_factory=dict_row) if to_dict else conn.cursor()
        yield cur
        cur.close()

    def _to_py_type(self, type_str: str):
        return to_py_dict.get(type_str.split(' ')[0].split('(')[0], str)

    @lru_cache(maxsize=128)
    def query_table_meta(self, table_name: str, to_py: bool = True) -> Dict:
        # 去掉schema
        table_name = table_name.split('.')[-1].lower()
        sql = f"SELECT col_description(a.attrelid,a.attnum) as comment,format_type(a.atttypid,a.atttypmod) as type,a.attname as name, a.attnotnull as notnull " \
              f"FROM pg_class as c,pg_attribute as a " \
              f"where c.relname = '{table_name}' and a.attrelid = c.oid and a.attnum>0"

        meta_info = dict()
        for lines in self.query_batch_row(sql=sql):
            for line in lines:
                meta_info[line['name'].lower()] = self._to_py_type(line['type']) if to_py else line['type']

        return meta_info

    def _flat_values(self, values: List[Dict], table_name: str) -> Tuple[str, str, Dict]:
        """
        暂时弃用、用于批量upsert (unnest方式)
        :param values:
        :return:
        """
        keys = list(values[0].keys())

        table_meta_dict = self.query_table_meta(table_name=table_name, to_py=True)

        pats = []
        value_dic = dict()
        for key in keys:
            pat = []
            for idx, value in enumerate(values):
                k = f"{key}_{idx}"
                pat.append(f"%({k})s")
                value_dic[k] = value[key]
            if table_meta_dict[key] == datetime:
                pats.append(f"to_timestamp(unnest(array[{','.join(pat)}]))")
            # if key == "emb":
            #     pats.append(f"to_tsvector(unnest(array[{','.join(pat)}]))")
            else:
                pats.append(f"unnest(array[{','.join(pat)}])")

        return ','.join(keys), ','.join(pats), value_dic

    def _flat_values_nor(self, values: List[Dict], table_name: str) -> Tuple[str, str]:
        """
        用于批量upsert (普通方式)
        :param values:
        :return:
        """
        keys = list(values[0].keys())
        table_meta_dict = self.query_table_meta(table_name=table_name, to_py=True)

        pats = []
        for key in keys:
            if table_meta_dict[key] == datetime and not isinstance(values[0][key], str):
                pats.append(f"to_timestamp(%({key})s)")
            else:
                pats.append(f"%({key})s")

        return ','.join(keys), ','.join(pats)

    def upsert_batch(self, table_name: str, values: List[Dict], conflict: Tuple[str, ...], batch_size: int = 5000,
                     update_cols: Tuple[str, ...] = None):
        """
        批量更新或写入 (需要高版本(16+)的pg库才支持这个语法)
        @param table_name: 表名
        @param values: 需要写入的值列表
        @param conflict: 冲突字段
        @param batch_size: 批量大小
        @param update_cols: 更新字段, 如果什么都不写表示不做任何事
        """
        if not values:
            return

        # 单次写入的最大参数量
        max_number = 65535
        # 实际单批次可写入的最大数据量
        max_actual = min(max_number // len(values[0]), batch_size)
        keys, pats = self._flat_values_nor(values=values, table_name=table_name)

        if update_cols:
            update_ = ','.join([f"{col} = excluded.{col} " for col in update_cols])
            upsert_sql = f"insert into {table_name} ({keys}) values ({pats}) on conflict ({','.join(conflict)}) do update set {update_}"
        else:
            upsert_sql = f"insert into {table_name} ({keys}) values ({pats}) on conflict ({','.join(conflict)}) do NOTHING"

        return self.insert_batch_row(sql=upsert_sql, values=values, batch_size=max_actual)

    def _gen_copy_from_sql(self, sql: str, data) -> Tuple[str, Set]:
        """
        构建copy_sql, 使用copy命令比insert_sql效率高15倍+
        @param sql: insert_sql
        @param data: 样例数据
        @return: copy_sql,
        """
        with self.lock:
            if sql in self.type_dict:
                return self.type_dict[sql]
        p_col_names = list(data.keys())

        table_name, col_names = sql_search_pattern.search(sql).groups()
        table_meta = self.query_table_meta(table_name=table_name)

        dif_keys = {(k, table_meta[k.lower()]) for k, v in data.items() if table_meta[k.lower()] in (int, float)}
        # new_dif_keys = set()
        # for key, r_type in dif_keys:
        #     # 只做数值型转换
        #     try:
        #         data[key] = r_type(data[key]) if data[key] else data[key]
        #         new_dif_keys.add((key, r_type))
        #     except:
        #         logger.warning(f"尝试转换{key}_{r_type}:[{data[key]}] 格式失败, 请确保输入正确的数据")

        if p_col_names:
            col_names = p_col_names
        if not col_names:
            col_names = list(table_meta.keys())

        if isinstance(col_names, str):
            col_names = col_names.replace('"', '').replace("'", '').split(',')

        col_names = ','.join([f'"{col}"' for col in col_names])

        copy_from_sql = f"COPY {table_name} ({col_names}) FROM STDIN".lower()
        logger.info(f"copy from sql: {copy_from_sql}")
        with self.lock:
            self.type_dict[sql] = (copy_from_sql, dif_keys)
        return copy_from_sql, dif_keys

    @staticmethod
    def utils_gen_insert_sql(table_name: str, params: List[str], time_cols: Tuple[str, ...] = None) -> str:
        """
        生成insert sql
        :param table_name: 表名
        :param params: 需要插入的列名
        :param time_cols: 时间列
        :return: insert sql
        """
        params_lst = []
        for param in params:
            if time_cols and param in time_cols:
                # params_lst.append(f"to_timestamp(%({param})s, 'YYYY-MM-DD HH24:MI:SS')::timestamp")
                params_lst.append(f"%({param})s::timestamp")
            else:
                params_lst.append(f"%({param})s")
        params = [f'"{p}"' for p in params]
        params_str = ', '.join(params_lst)
        insert_sql = f"insert into {table_name} ({', '.join(params)}) VALUES ({params_str})"
        return insert_sql

    def _copy_to_db(self, sql: str, params_list: Iterable[Mapping] = None, batch_size: int = 100000,
                    commit: bool = True):
        """
        带参数列表执行sql，主要用于增删改数据
        @param sql: sql语句
        @param params_list: 参数列表
        @param batch_size: 批次大小
        @param commit: 是否提交到数据库，默认会自动提交
        """
        assert isinstance(params_list, Iterable), '请提供Iterable类型的参数'
        conn, is_close = self.get_inner_conn
        table_name = extract_table_name_from_insert(insert_sql=sql)

        # 提取列名顺序
        params_list = list(params_list)
        if not params_list:
            return
        insert_num = len(params_list)
        try:
            field_names = list(params_list[0].keys())
            table_cols = set(map(str.lower, self._get_table_cols(table_name=table_name)))
            exit_col_names = [field_name for field_name in field_names if field_name.lower() in table_cols]

            # 构建 COPY 语句
            # 转换列名为小写并拼接
            columns_sql = ", ".join(f'"{col.lower()}"' for col in exit_col_names)
            # 构造 COPY SQL 语句（用 f-string 拼接）
            copy_sql_str = f"COPY {table_name} ({columns_sql}) FROM STDIN WITH (FORMAT csv, HEADER false)"
            # 使用 psycopg2.sql.SQL 包装（推荐保持 SQL 安全）
            copy_query = pg_sql.SQL(copy_sql_str)

            logger.debug(copy_query)
            with conn.cursor() as cur:
                for k, values in iter_slice_tool(params_list, batch_size=batch_size):
                    values = list(values)
                    csv_buffer = StringIO()
                    writer = csv.DictWriter(csv_buffer, fieldnames=exit_col_names, extrasaction='ignore',
                                            quoting=csv.QUOTE_MINIMAL)
                    writer.writerows(values)
                    csv_buffer.seek(0)
                    # logger.debug(csv_buffer.getvalue()[:100])  # 打印前500字符检查格式
                    # csv_buffer.seek(0)

                    logger.debug("开始写入")
                    with cur.copy(copy_query) as copy:
                        for row in csv_buffer:
                            copy.write(row.encode('utf-8'))
                logger.debug("准备commit")
                if commit:
                    conn.commit()
                logger.debug("写入完成")
        except Exception as e:
            logger.exception(e)
            raise Exception(f"COPY 插入失败, 总数据量[{insert_num}]：{e}\n部分数据：{params_list[:5]}")
        finally:
            if is_close:
                conn.close()

        logger.debug(f'脚本执行完成, 总数据量[{insert_num}]: \n{sql.strip()}')

    def insert_batch_row(self, sql: str, values: Iterable[Mapping], batch_size: int = 100000, commit: bool = True):
        """
        批量写入数据库
        @param sql: 插入语句
                    example：INTO table_name (id,blob_cl,clob_cl) VALUES (:ID, rawtohex(:BLOB_CL), :CLOB_CL)
        @param values: 插入的数据列表
        @param batch_size: 批次大小
        @param commit: 是否提交到数据库，默认会自动提交
        """
        if has_len(obj=values) and len(values) < 50000:
            self.execute_sql_with_params_list(sql=sql, params_list=values, batch_size=batch_size, commit=commit)
        else:
            self._copy_to_db(sql=sql, params_list=values, batch_size=batch_size, commit=commit)

    # def insert_batch_row(self, sql: str, values: Iterable[Mapping], batch_size: int = 100 * 10000, commit: bool = True):
    #     """
    #     批量写入数据库, 使用copy命令来实现写入
    #     @param sql: 插入语句
    #                 example: INTO table_name (id,blob_cl,clob_cl) VALUES (:ID, rawtohex(:BLOB_CL), :CLOB_CL)
    #     @param values: 插入的数据列表
    #     @param batch_size: 批次大小，默认100w
    #     @param commit: 是否提交到数据库，默认会自动提交
    #     """
    #     copy_sql = None
    #     values = iter(values)
    #     try:
    #         data: Dict = dict(next(values))
    #         copy_sql, dif_keys = self._gen_copy_from_sql(sql=sql, data=data)
    #         values = chain([data], values)
    #     except Exception as e:
    #         logger.exception(e)
    #         raise Exception(f"解析copy_sql: {sql.strip()}失败")
    #
    #     for key, records in iter_slice_tool(values, batch_size=batch_size):
    #         conn, is_close = self.get_inner_conn
    #         try:
    #             with conn.cursor() as cur:
    #                 with cur.copy(copy_sql) as copy:
    #                     for record in records:
    #                         for r_key, r_type in dif_keys:
    #                             record[r_key] = r_type(record[r_key]) if record[r_key] is not None else record[r_key]
    #                         copy.write_row(list(record.values()))
    #             if commit:
    #                 conn.commit()
    #         except Exception as e:
    #             logger.exception(f"copy_sql:{copy_sql}\nand dif_key: {dif_keys}")
    #             value = record if 'record' in locals() or 'record' in globals() else ''
    #             raise Exception(f'脚本执行出错\nsql:{sql.strip()}\nparams_list:{values}具体错误如下：\n{e}\n{value}')
    #         finally:
    #             conn.close()
    #     logger.debug(f'{sql.strip()}批量插入完成')

    # def query_batch_row(self, sql: str, batch_size=1000, encoding='UTF-8',
    #                     to_dict: bool = True) -> Iterator[Iterator[Mapping] or Iterator[Tuple]]:
    #     """
    #     按批查询数据
    #     @param sql: 查询语句
    #     @param batch_size: 查询批次大小
    #     @param encoding: 编码方式
    #     @param to_dict: 是否将结果转为字典形式
    #     """
    #     total_try = try_nums = 4
    #     while try_nums := try_nums - 1:
    #         conn, is_close = self.get_inner_conn
    #         normal = True
    #         try:
    #             with self.dict_cur(conn=conn, to_dict=to_dict) as cur:
    #                 normal = False
    #                 it_records = cur.stream(sql)
    #                 for _, records in iter_slice_tool(it_records, batch_size=batch_size):
    #                     yield records
    #                 normal = True
    #         except Exception as e:
    #             logger.warning(f'第[{total_try - try_nums}]次 读取数据出错sql: {sql.strip()}\n具体错误如下：\n{e}')
    #             time.sleep(3)
    #             # raise Exception(f'读取数据出错sql: {sql.strip()}\n具体错误如下：\n{e}')
    #         finally:
    #             if is_close:
    #                 conn.close()
    #         if normal:
    #             break
    #
    #     if not normal:
    #         yield from super(PgDao, self).query_batch_row(sql=sql, batch_size=batch_size, encoding=encoding,
    #                                                       to_dict=to_dict)

    def query_batch_row(self, sql: str, params: Mapping or None = None, batch_size=1000, encoding='UTF-8',
                        to_dict: bool = True) -> Iterator[Iterator[Mapping] or Iterator[Tuple]]:

        os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'

        original_config = self.get_inner_conn[0]._con._kwargs
        #避免影响全局配置
        config = deepcopy(original_config)

        # 解决游标的问题, 默认使用的是ClientCursor
        cls = partial(ServerCursor, name=gen_uuid32())
        config['cursor_factory'] = cls

        db_creator = importlib.import_module("psycopg")

        max_cached = 0
        max_connections = 16
        max_usage = 0
        blocking = True

        """
        max_cached: 池中空闲连接的最大数量。默认为0，即无最大数量限制。(建议默认)
        max_connections: 被允许的最大连接数。默认为0，无最大数量限制。(视情况而定)
        max_usage: 连接的最大使用次数。默认0，即无使用次数限制。(建议默认)
        blocking: 连接数达到最大时，新连接是否可阻塞。默认False，即达到最大连接数时，再取新连接将会报错。
                 (建议True，达到最大连接数时，新连接阻塞，等待连接数减少再连接)
        """
        pool = PooledDB(db_creator,
                        maxcached=max_cached,
                        maxconnections=max_connections,
                        maxusage=max_usage,
                        blocking=blocking,
                        **config)

        conn = pool.connection()

        cur = conn.cursor(row_factory=dict_row)
        cur.itersize = batch_size
        new_sql = sql_format(sql=sql, params=params)
        cur.execute(new_sql, params)

        while records := cur.fetchmany(batch_size):
            yield records if to_dict else [tuple(record.values()) for record in records]

        with contextlib.suppress(Exception):
            cur.close()
        with contextlib.suppress(Exception):
            conn.close()
        # with contextlib.suppress(Exception):
        #     pool.close()

    def is_exist_table(self, table_name: str) -> bool:
        """
        判断指定表有没存在
        @param table_name: 表名
        @return: 表是否存在
        """
        sql = f"""SELECT EXISTS (SELECT 1 FROM information_schema.tables where table_name = '{table_name}') as is_exists"""
        conn, is_close = self.get_inner_conn
        exist_table: bool = True
        try:
            exist_table = self.get_one_row(sql=sql)['is_exists']
        except Exception as e:
            exist_table = False
        finally:
            if is_close:
                conn.close()
        return exist_table
