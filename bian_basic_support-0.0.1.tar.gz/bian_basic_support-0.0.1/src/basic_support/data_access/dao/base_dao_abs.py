#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: base_dao_abs.py
@Description: 数据库 抽象BaseDao类+关系库dao类+非关系库dao类
@time: 2020/7/24 22:25
"""
from abc import ABC, ABCMeta


class BaseDao(ABC, metaclass=ABCMeta):
    """
    basedao类
    """

    def __init__(self):
        # TODO 单例模式  https://blog.csdn.net/nosprings/article/details/100034502
        pass
