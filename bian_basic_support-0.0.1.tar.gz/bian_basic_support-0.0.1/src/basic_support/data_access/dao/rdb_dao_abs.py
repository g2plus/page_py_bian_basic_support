#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: rdb_dao_abs.py
@Description: 
@time: 2020/7/30 14:47
"""
import contextlib
import copy
import re
import traceback
from abc import abstractmethod
from functools import lru_cache
from typing import List, Iterator, Iterable, Dict, Tuple
from typing import Mapping

from basic_support.comm_funcs.comm_utils import iter_slice_tool, iter_uniform_tool
from basic_support.data_access.connection.db_connection_abs import AbstractRdbPool, AbstractRdbConn
from basic_support.data_access.dao.base_dao_abs import BaseDao
from basic_support.logger.logger_config import logger

sql_reserve = lambda k: k.groups()[0]
sql_remove = lambda k: ''


#
#
# def sql_format(sql: str, params: Dict = None) -> str:
#     """
#     自定义 /~  ~/语法解析
#     :param sql: 查询sql
#     :param params: 参数
#     :return:
#
#     例子：
#     sql = sql_format(
#     sql="select a.* from t_wf_buis_form a "
#         "  left join t_wf_ref b "
#         "    on a.id = b.end_element_id"
#         " where 1 = 1 "
#         " /~and a.id = %(form_id)s ~/ "
#         " /~and b.start_element_id = %(node_id)s ~/ "
#         " /~and a.is_input = %(is_input)s ~/",
#     params={"form_id": form_id,
#             "node_id": node_id,
#             "is_input":is_input})
#     """
#     if params is None:
#         return sql
#     for key, value in params.items():
#         pattern = re.compile(f"/~([^~]*?{key}[^~]*?)~/") if value is not None else re.compile(f"(/~[^~]*?{key}[^~]*?~/)")
#         sql = re.sub(pattern, sql_reserve if value is not None else sql_remove, sql)
#
#     sql = re.sub(r' {2,}', ' ', sql)
#
#     return sql


def sql_format(sql: str, params: Dict):
    new_sql = copy.copy(sql)
    if not params:
        pattern = re.compile(f"(/~[^~]*~/)")
        subs = pattern.findall(new_sql)
        for sub in subs:
            new_sql = new_sql.replace(sub, "")
        return new_sql
    p = {}
    for key, param in params.items():
        pattern = re.compile(f"(/~[^~]*?\({key}\)[^~]*?~/)")
        # match = pattern.search(new_sql, 0)
        # if not match:
        #     param_pattern = re.compile(f"%\({key}\)s")
        #     param_match = param_pattern.search(new_sql, 0)
        #     if not param_match:
        #         p[key] = param
        # else:
        #     if param is None:
        #         new_sql = pattern.sub('', new_sql)
        #         p[key] = param
        #     else:
        #         sub = new_sql[match.start() + 2:match.end() - 2]
        #         new_sql = pattern.sub(sub, new_sql)

        matchs = pattern.findall(new_sql, 0)
        if not matchs:
            param_pattern = re.compile(f"%\({key}\)s")
            param_match = param_pattern.search(new_sql, 0)
            if not param_match:
                p[key] = param
        else:
            if param is None:
                new_sql = pattern.sub('', new_sql)
                p[key] = param
            else:
                for match in matchs:
                    new_sql = new_sql.replace(match, match[2:-2])

    pattern = re.compile(f"(/~[^~]*~/)")

    subs = pattern.findall(new_sql)
    for sub in subs:
        new_sql = new_sql.replace(sub, "")

    return new_sql


@lru_cache(maxsize=128)
def extract_table_name_from_insert(insert_sql: str) -> str:
    """
    从 INSERT SQL 中提取表名，支持带schema、双引号和空格的情况
    """
    # 匹配INSERT INTO 后跟的完整表名，允许schema（用点连接）
    # 允许表名或schema用双引号括起来，允许中间空格
    pattern = re.compile(
        r'INSERT\s+INTO\s+((?:"[^"]+"|\w+)(?:\s*\.\s*(?:"[^"]+"|\w+))*)',
        re.IGNORECASE
    )
    match = pattern.search(insert_sql)
    if match:
        # 去除空格和多余的双引号
        table_full = match.group(1)
        # 去除表名中间多余空白，统一去掉引号
        table_full = re.sub(r'\s*\.\s*', '.', table_full)  # 去掉点周围空格
        table_full = table_full.replace('"', '')  # 去掉双引号
        logger.debug(f"从sql: {insert_sql}\n提取到表名为: {table_full}")
        return table_full.lower()
    raise ValueError("无法从 SQL 中提取表名")




class AbstractRdbDao(BaseDao):
    """
    关系型数据库dao父类，主要包括了Oracle、Postgres、Mysql、SqlServer、Sqlite、Hbase
    """

    def __init__(self, base_db_conn: AbstractRdbPool):
        """
        @param base_db_conn: 关系库连接池对象
        """
        super(AbstractRdbDao, self).__init__()
        self.base_db_conn = base_db_conn

    def create_table(self, sql: str, commit: bool = True):
        """
        创建新表
        @param sql: 建表语句
        @param commit: 是否提交到数据库，默认会自动提交
        @return:
        """
        res = self.execute_sql_with_params(sql=sql, commit=commit)
        logger.debug('创建表完成')
        return res

    def truncate_table(self, table_name: str, commit: bool = True):
        """
        清空表数据
        @param table_name: 需要清空数据的表名
        @param commit: 是否提交到数据库，默认会自动提交
        @return:
        """
        truncate_sql = f'TRUNCATE TABLE {table_name}'
        self.execute_sql_with_params(sql=truncate_sql, commit=commit)
        logger.debug(f'{table_name}表清空完成')

    def drop_table(self, table_name: str, commit: bool = True):
        """
        删除表
        @param table_name: 需要清空数据的表名
        @param commit: 是否提交到数据库，默认会自动提交
        @return:
        """
        if self.is_exist_table(table_name=table_name):
            drop_sql = f'DROP TABLE IF EXISTS {table_name}'
            self.execute_sql_with_params(sql=drop_sql, commit=commit)
            logger.debug(f'{table_name}删除表完成')

    def execute_non_transactional_sql(self, sql: str, params: Mapping or None = None):
        """
        执行非事务性SQL命令（如VACUUM、CREATE DATABASE等）
        这些命令不能在事务块内执行，需要使用自动提交模式
        @param sql: SQL语句
        @param params: 参数
        @return: 执行结果
        """
        assert params is None or isinstance(params, Mapping), '请提供字典类型的参数'

        import psycopg
        conn = None
        try:
            # 从连接池参数获取连接信息
            pool_kwargs = self.base_db_conn.connection._pool._kwargs

            # 创建新的连接参数，确保启用自动提交
            conn_params = pool_kwargs.copy()
            conn_params['autocommit'] = True  # 关键：启用自动提交模式
            conn = psycopg.connect(**conn_params)

            with conn.cursor() as cur:
                logger.trace(f">>> 非事务性SQL执行 - 游标类型: {type(cur).__name__}")
                formatted_sql = sql_format(sql=sql, params=params) if hasattr(self, 'sql_format') else sql
                response = cur.execute(formatted_sql, params)
                logger.debug(f'非事务性SQL执行完成: \n{formatted_sql.strip()}')
                return response

        except Exception as e:
            logger.exception(e)
            raise Exception(f'非事务性SQL执行出错\nsql:{sql}\nparams_list:{params}具体错误如下：\n{e}')
        finally:
            if conn:
                conn.close()

    def execute_sql_with_params_list(self, sql: str, params_list: Iterable[Mapping] = None, batch_size: int = 5000,
                                     commit: bool = True):
        """
        带参数列表执行sql，主要用于增删改数据
        @param sql: sql语句
        @param params_list: 参数列表
        @param batch_size: 批次大小
        @param commit: 是否提交到数据库，默认会自动提交
        """
        assert isinstance(params_list, Iterable), '请提供Iterable类型的参数'
        conn, is_close = self.get_inner_conn
        insert_num = 0
        try:
            with conn.cursor() as cur:
                logger.trace(f">>> 游标类型:{type(cur).__name__}")
                if not params_list:
                    response = cur.execute(sql)
                else:
                    for k, value in iter_slice_tool(params_list, batch_size=batch_size):
                        value = list(value)
                        insert_num += len(value)
                        pas_lst = sql, value
                        # retry_call_function(cur.executemany, pas_lst, tries=3, delay=10, jitter=10)
                        cur.executemany(sql, value)
                if commit:
                    cur.execute('commit')
        except Exception as e:
            logger.exception(e)
            value = value if 'value' in locals() or 'value' in globals() else ''
            if type(params_list) != list:
                params_list = list(params_list)
            raise Exception(
                f'脚本执行出错\nsql:{sql.strip()}\nparams_list[{len(params_list)}]:{params_list[:20]}具体错误如下：\n{traceback.format_exc()}\n{value}')
        finally:
            if is_close:
                conn.close()
        logger.debug(f'脚本执行完成, 总数据量[{insert_num}]: \n{sql.strip()}')

    def execute_sql_with_params(self, sql: str, params: Mapping or None = None, commit: bool = True):
        """
        带参数列表执行sql，主要用于增删改数据以及建表、清空表和删除表操作
        @param sql: sql语句
        @param params: 参数
        @param commit: 是否提交到数据库，默认会自动提交
        @return: 执行脚本的结果
        """
        assert params is None or isinstance(params, Mapping), '请提供字典类型的参数'
        conn, is_close = self.get_inner_conn
        try:
            sql = sql_format(sql=sql, params=params)
            with conn.cursor() as cur:
                logger.trace(f">>> 游标类型:{type(cur).__name__}")
                response = cur.execute(sql, params)
                if commit:
                    cur.execute('commit')
        except Exception as e:
            logger.exception(e)
            raise Exception(f'脚本执行出错\nsql:{sql}\nparams_list:{params}具体错误如下：\n{e}')
        finally:
            if is_close:
                conn.close()
        logger.debug(f'脚本执行完成: \n{sql.strip()}')
        return response

    def execute_sql_with_params_list_multi_threads(self, sql: str, params_list=Iterable[Mapping],
                                                   batch_size: int = 5000, commit: bool = True, thread_num: int = 5, ):
        from threading import Thread
        datas_lst = iter_uniform_tool(params_list, thread_num)
        thread_lst = []
        for data_lst in datas_lst:
            t = Thread(target=self.execute_sql_with_params_list, kwargs={
                "sql": sql,
                "params_list": data_lst,
                "batch_size": batch_size,
                "commit": commit
            })
            t.start()
            thread_lst.append(t)
        for t in thread_lst:
            t.join()
        # if commit:
        #     conn, is_close = self.get_inner_conn
        #     try:
        #         with conn.cursor() as cur:
        #             cur.execute('commit')
        #     finally:
        #         if is_close:
        #             conn.close()

    def insert_batch_row(self, sql: str, values: Iterable[Mapping], batch_size: int = 5000, commit: bool = True):
        """
        批量写入数据库
        @param sql: 插入语句
                    example：INTO table_name (id,blob_cl,clob_cl) VALUES (:ID, rawtohex(:BLOB_CL), :CLOB_CL)
        @param values: 插入的数据列表
        @param batch_size: 批次大小，默认5000一批
        @param commit: 是否提交到数据库，默认会自动提交
        """
        self.execute_sql_with_params_list(sql=sql, params_list=values, batch_size=batch_size, commit=commit)

    def insert_single_row(self, sql: str, values: Mapping, commit: bool = True):
        """
        单条写入数据库
        @param sql: 插入语句
        @param values: 需要插入的数据
        @param commit: 是否提交到数据库，默认会自动提交
        """
        self.execute_sql_with_params(sql=sql, params=values, commit=commit)
        logger.debug(f'{sql.strip()}插入完成')

    def delete_sql_with_params(self, sql: str, params: Mapping = None, commit: bool = True):
        """
        删除数据操作
        @param sql: sql语句
        @param params: 参数
        @param commit: 是否提交到数据库，默认会自动提交
        """
        self.execute_sql_with_params(sql=sql, params=params, commit=commit)
        logger.debug('删除数据完成')

    @abstractmethod
    def upsert_batch(self, table_name: str, values: List[Dict], conflict: Tuple[str, ...], batch_size: int = 5000,
                     update_cols: Tuple[str, ...] = None):
        """
        批量更新或写入  注意conflict必须是主键，时间类型的字段必须是 datetime.datetime.now()类型
        @param table_name: 表名
        @param values: 需要写入的值列表
        @param conflict: 冲突字段
        @param batch_size: 批量大小
        @param update_cols: 更新字段
        """
        raise Exception("未实现的抽象方法！")

    def get_one_row(self, sql: str, params: Mapping or None = None, encoding='UTF-8',
                    to_dict: bool = True) -> Mapping or Tuple:
        """
        获取一条记录
        :param sql: 查询语句
        :param params: sql查询参数
        :param encoding: 编码方式
        :param to_dict: 是否将结果转为字典形式
        :return:
        """
        for record in self.query_batch_iter(sql=sql, params=params, encoding=encoding, batch_size=500, to_dict=to_dict):
            return record
        return None

    def query_single_row(self, sql: str, params: Mapping or None = None, encoding='UTF-8',
                         to_dict: bool = True) -> Iterator[Mapping or Tuple]:
        """
        数据查询(迭代器, 每次返回一条)
        @param sql: 查询语句
        @param params: sql查询参数
        @param encoding: 编码方式
        @param to_dict: 是否将结果转为字典形式
        """
        for record in self.query_batch_iter(sql=sql, params=params, encoding=encoding, batch_size=500, to_dict=to_dict):
            yield record

    def query_batch_row(self, sql: str, params: Mapping or None = None, batch_size=1000, encoding='UTF-8',
                        to_dict: bool = True) -> Iterator[Iterator[Mapping] or Iterator[Tuple]]:
        """
        数据查询(迭代器, 每次返回一批)
        @param sql: 查询语句
        @param params: sql查询参数
        @param batch_size: 查询批次大小
        @param encoding: 编码方式
        @param to_dict: 是否将结果转为字典形式
        """
        conn, is_close = self.get_inner_conn
        total_num = 0
        try:
            with self.dict_cur(conn=conn, to_dict=to_dict) as cur:
                new_sql = sql_format(sql=sql, params=params)
                if hasattr(cur, 'itersize'):
                    cur.itersize = batch_size
                cur.execute(new_sql, params)
                # if version_info.major == 3 and version_info.minor >= 8:
                while records := cur.fetchmany(batch_size):
                    total_num += len(records)
                    yield records
            # else:
            # while True:
            #     records = cur.fetchmany(batch_size)
            #     if records is None:
            #         break
            #     yield records

        except Exception as e:
            error_msg = traceback.format_exc()
            logger.exception(error_msg)
            raise Exception(f'读取数据出错, 具体错误如下: \n{error_msg}')
        finally:
            if is_close:
                conn.close()
        logger.debug(f"查询完成, 总数据量为: {total_num}:\n{sql.strip()}")

    def query_batch_iter(self, sql: str, params: Mapping or None = None, batch_size=1000, encoding='UTF-8',
                         to_dict: bool = True) -> Iterator[Mapping or Tuple]:
        """
        query_batch_row的迭代式接口函数
        @param sql: 查询语句
        @param params: sql查询参数
        @param batch_size: 查询批次大小
        @param encoding: 编码方式
        @param to_dict: 是否将结果转为字典形式
        :return:
        """
        for datas in self.query_batch_row(sql=sql, params=params, batch_size=batch_size, encoding=encoding,
                                          to_dict=to_dict):
            yield from datas

    def close_connection(self):
        """ 对于使用连接的方式，由调用者手动关闭 """
        if isinstance(self.base_db_conn, AbstractRdbConn):
            try:
                self.base_db_conn.connection.close()
            except:
                logger.warning("连接已处于关闭状态")

    def is_exist_table(self, table_name: str) -> bool:
        """
        判断指定表有没存在
        @param table_name: 表名
        @return: 表是否存在
        """
        sql = f"select 1 from {table_name} limit 1"
        conn, is_close = self.get_inner_conn
        exist_table: bool = True
        try:
            with conn.cursor() as cur:
                response = cur.execute(sql, None)
        except Exception as e:
            exist_table = False
        finally:
            if is_close:
                conn.close()
        return exist_table

    def is_exist_record(self, sql: str) -> bool:
        """
        判断查询记录是否存在
        @param sql: 查询sql
        @return: 记录是否存在
        """
        res = self.query_single_row(sql=sql)
        exist_record = True
        try:
            next(res)
        except Exception as e:
            exist_record = False
        return exist_record

    @abstractmethod
    def query_table_meta(self, table_name: str, to_py: bool = True) -> Dict:
        """
        查看表的meta信息
        @param table_name: 表明
        @param to_py: 是否转python类型
        @return:
        """
        raise NotImplementedError()

    @property
    def get_inner_conn(self):
        """
        获取关系库连接
        @return: 连接对象，是否关闭连接，对于使用连接的方式，由调用者手动关闭
        """
        if isinstance(self.base_db_conn, AbstractRdbPool):
            return self.base_db_conn.connection, True
        elif isinstance(self.base_db_conn, AbstractRdbConn):
            return self.base_db_conn.connection, False
        else:
            logger.exception("请确保连接类型为[AbstractRdbPool]或[AbstractRdbConn]的子类")
            raise Exception()

    @abstractmethod
    @contextlib.contextmanager
    def dict_cur(self, conn, to_dict: bool = True):
        """
        获取字典型的连接
        :param conn: 数据库连接
        :param to_dict: 是否将结果转为字典形式
        """
        raise Exception("未实现的抽象方法！")

    @staticmethod
    def utils_gen_insert_sql(table_name: str, params: List[str], time_cols: Tuple[str, ...] = None) -> str:
        """
        生成insert sql
        :param table_name: 表名
        :param params: 需要插入的列名
        :param time_cols: 时间列
        :return: insert sql
        """
        params_str = ', '.join([f'%({param})s' for param in params])
        insert_sql = f"insert into {table_name} ({', '.join(params)}) VALUES ({params_str})"
        return insert_sql

    def record_counter(self, table_name: str, conditions: str = None) -> int:
        """
        对指定表的记录进行统计
        :param table_name: 表名
        :param conditions: 条件
        例子:
            count_num = dao.record_counter('t_obj_laws', "code like '%35%' and name like '浙江%'")
        :return: 记录数
        """
        condition_str = f" where {conditions}" if conditions else ""
        sql = f"select count(1) as count_num from {table_name}{condition_str}"
        logger.info(f"查询表[{table_name}]记录数的sql为: {sql.strip()}")

        count_num = -1
        try:
            record = self.get_one_row(sql=sql)
            count_num = record['count_num']
        except Exception as e:
            pass

        return count_num


if __name__ == '__main__':
    template = f"""
                select * from aa a 
                 where 1 = 1
                   and a.ts_code like %(ts_code1)s
                /~ and a.ts_code like %(ts_code)s ~/
                /~ and a.aad >  %(aad)s ~/
            """
    template_params = None
    sql = sql_format(template, template_params)
    print(sql)
