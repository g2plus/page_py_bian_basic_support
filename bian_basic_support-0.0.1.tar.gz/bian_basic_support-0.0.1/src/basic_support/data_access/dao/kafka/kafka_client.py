import json
import threading
import time
import traceback
from abc import ABC, abstractmethod
from enum import Enum, auto
from typing import List, Optional, Dict

import xxhash
from basic_support.logger.logger_config import logger
from confluent_kafka import Consumer, KafkaError, KafkaException, TopicPartition, Producer


class DeliverySemantic(Enum):
    """消息传输语义"""
    AT_MOST_ONCE = auto()
    AT_LEAST_ONCE = auto()
    EXACTLY_ONCE = auto()

    @classmethod
    def values(cls):
        return [member.name for member in cls]



class ReceiveMessage:
    """监听器的返回消息体"""

    def __init__(self, is_success: bool):
        self.status = is_success


class CustomerMessageListener(ABC):
    """监听器接口"""

    @abstractmethod
    def listen_batch(self, messages: List[dict]) -> ReceiveMessage:
        """
        批量处理消息
        :param messages: 消息列表，dict格式如下：
        {
            'key': key,
            'value': 真正的值,
            'partition': 分区信息,
            'offset': 偏移量,
            'topic': 主题
        }
        """
        pass

    def listen(self, message: dict) -> ReceiveMessage:
        """
        逐条处理消息,可选的
        """
        return self.listen_batch([message])




class ProducerMessageCallback:
    """生成消息回调父类"""

    def on_success(self, message: dict):
        """
        逐条处理 成功的
        """
        pass

    def on_failure(self, exception: str, message: Optional[dict] = None):
        """
        逐条处理 失败的
        """
        pass


class KafkaPartitionStrategy:
    """分区策略，仅数值型和字符串型"""

    def __init__(self, partition_field: str, num_partitions: int):
        self.partition_field = partition_field
        self.num_partitions = num_partitions

    def get_partition(self, value: Dict, topic_partitions: int) -> Optional[int]:
        """
        根据 value 计算分区
        """
        assert self.num_partitions <= topic_partitions, f"请求的分区数 {self.num_partitions} 超过 topic 实际分区数 {topic_partitions}"
        # assert self.partition_field not in value, f"value 中没有字段 {self.partition_field}"
        if self.partition_field not in value:
            raise ValueError(f"value 中没有字段 {self.partition_field}")

        field_value = value[self.partition_field]

        try:
            if isinstance(field_value, (int, float)):
                return int(field_value) % self.num_partitions
            elif isinstance(field_value, str):
                hash_value = xxhash.xxh32_intdigest(field_value.encode('utf-8'))
                return hash_value % self.num_partitions
            else:
                logger.warning(f"字段 {self.partition_field} 的值 {field_value} 类型不支持，使用默认分区")
                hash_value = xxhash.xxh32_intdigest(str(field_value).encode('utf-8'))
                return hash_value % self.num_partitions
        except Exception:
            logger.error(f"分区计算失败: {traceback.format_exc()}")
            return None


class KafkaEventProducer:
    """生成者操作"""

    def __init__(
            self,
            bootstrap_servers: str,
            delivery_semantic: Optional[DeliverySemantic] = DeliverySemantic.AT_LEAST_ONCE,
            transactional_id: Optional[str] = None,
            partition_strategy: Optional[KafkaPartitionStrategy] = None,
            **producer_config
    ):
        """
        :param bootstrap_servers:
        :param delivery_semantic:
        :param transactional_id: 事务ID，精确一次必须用到
        :param producer_config: linger.ms, batch_size
        :param partition_strategy:分区策略
        """
        self.partition_strategy = partition_strategy
        self._partition_cache = {}
        default_conf = {
            'bootstrap.servers': bootstrap_servers,
            'acks': 'all' if delivery_semantic in [DeliverySemantic.AT_LEAST_ONCE,
                                                   DeliverySemantic.EXACTLY_ONCE] else '1',
            'compression.type': 'lz4',
            'batch.num.messages': 1000,
            'queue.buffering.max.ms': 500
        }

        if delivery_semantic == DeliverySemantic.EXACTLY_ONCE:
            assert transactional_id, f"{DeliverySemantic.EXACTLY_ONCE.name}需要配置transactional_id"
            default_conf.update({
                'transactional.id': transactional_id,
                'enable.idempotence': True
            })

        self.conf = {**default_conf, **producer_config}
        self.producer = Producer(self.conf)
        self.delivery_semantic = delivery_semantic.name

        if self.delivery_semantic == DeliverySemantic.EXACTLY_ONCE.name:
            try:
                self.producer.init_transactions()
            except KafkaException as e:
                logger.error(f"初始化事务失败: {traceback.format_exc()}")
                raise

    def get_topic_partitions(self, topic: str) -> int:
        if topic in self._partition_cache:
            return self._partition_cache[topic]
        try:
            metadata = self.producer.list_topics(topic)
            count = len(metadata.topics[topic].partitions)
            self._partition_cache[topic] = count
            return count
        except Exception as e:
            logger.error(f"获取主题 {topic} 的分区数失败: {traceback.format_exc()}")
            raise

    def send(
            self,
            topic: str,
            value: Dict,
            key: Optional[str] = None,
            callback: Optional[ProducerMessageCallback] = None
    ):
        """
        发送消息
        :param topic:
        :param value:
        :param key:
        :param callback: 回调
        :return:
        """

        def delivery_callback(err, msg):
            if err is not None:
                logger.error(f"消息发送失败: {err}")
                if callback:
                    callback.on_failure(err, msg)
            else:
                if callback:
                    callback.on_success(msg)

        partition = None
        if self.partition_strategy:
            total_partition = self.get_topic_partitions(topic)
            partition = self.partition_strategy.get_partition(value, total_partition)

        kwargs = {
            "topic": topic,
            "value": json.dumps(value).encode('utf-8'),
            "key": key.encode('utf-8') if key else None,
            "callback": delivery_callback
        }
        if partition is not None:
            kwargs["partition"] = partition
        self.producer.produce(
            **kwargs
        )

    def send_batch(
            self,
            topic: str,
            datas: List[dict],
            key: Optional[str] = None,
            callback: Optional[ProducerMessageCallback] = None
    ):
        self.topic = topic
        self.key = key
        # 事务模式
        if self.delivery_semantic == DeliverySemantic.EXACTLY_ONCE.name:
            try:
                self.producer.begin_transaction()
                serialized_data = [(json.dumps(data).encode('utf-8'), key.encode('utf-8') if key else None, data) for
                                   data in
                                   datas]
                for value, key, data in serialized_data:
                    self._send_in_transaction(
                        topic=self.topic,
                        value=value,
                        key=key,
                        data_4partition=data,
                        callback=callback
                    )
                self.producer.commit_transaction()



            except KafkaException as e:
                logger.error(f"事务回滚: {traceback.format_exc()}")
                try:
                    self.producer.abort_transaction()
                except KafkaException as abort:
                    logger.error(f"Kafka的abort事务失败: {traceback.format_exc()}")
                if callback:
                    callback.on_failure(str(e))
                raise

        # 非事务模式
        else:
            for data in datas:
                self.send(
                    topic=self.topic,
                    value=data,
                    key=self.key,
                    callback=callback
                )
            self.producer.flush()

    def _send_in_transaction(
            self,
            topic: str,
            value: bytes,
            data_4partition: Dict,
            key: Optional[str] = None,
            callback: Optional[ProducerMessageCallback] = None
    ):
        """事务内专用发送方法"""

        def delivery_callback(err, msg):
            if err:
                if callback:
                    callback.on_failure(err, msg)
                raise KafkaException(err)
            else:
                if callback:
                    callback.on_success(msg)

        partition = None
        if self.partition_strategy:
            topic_partitions = self.get_topic_partitions(topic)
            partition = self.partition_strategy.get_partition(data_4partition, topic_partitions)

        self.producer.produce(
            topic=topic,
            value=value,
            key=key.encode('utf-8') if key else None,
            partition=partition,
            on_delivery=delivery_callback
        )


class KafkaEventConsumer:
    """Kafka 消费者"""

    def __init__(
            self,
            bootstrap_servers: str,
            group_id: str,
            topics: List[str],
            listen: CustomerMessageListener,
            batch_size: int = 10,
            delivery_semantic: DeliverySemantic = DeliverySemantic.AT_LEAST_ONCE,
            partition_strategy: Optional[KafkaPartitionStrategy] = None,
            partition: Optional[List[int]] = None,
            concurrency: Optional[int] = 1,
            max_retries: Optional[int] = 3
    ):
        """
        :param bootstrap_servers:
        :param group_id:
        :param topics:
        :param listen:
        :param batch_size:
        :param delivery_semantic: 交付语义
        :param partition_strategy: 分区策略，根据指定分区去消费，一般要和生产者配套，与下面的paritition互斥，只能2选一
        :param partition: 指定分区逻辑，与分区策略互斥
        :param concurrency:
        :param max_retries:
        """
        self.partition_strategy = partition_strategy
        self.dead_letter_queue = []
        self.max_retries = max_retries
        self._partition_cache = {}
        self.assign_partition = partition

        if delivery_semantic not in DeliverySemantic:
            raise ValueError(f"无效的消息交付语义. 必须在下面的列表中选择: {','.join(DeliverySemantic.values())}")

        self.conf = {
            'bootstrap.servers': bootstrap_servers,
            'group.id': group_id,
            'auto.offset.reset': 'earliest',
            'enable.auto.commit': delivery_semantic == DeliverySemantic.AT_MOST_ONCE
        }
        if delivery_semantic == DeliverySemantic.EXACTLY_ONCE:
            self.conf.update({
                'isolation.level': 'read_committed',
                'enable.auto.commit': False
            })

        self.topics = topics
        self.listen = listen
        self.concurrency = max(1, concurrency)
        self.batch_size = max(1, batch_size)
        self.delivery_semantic = delivery_semantic.name
        self.consumers: List[Consumer] = []
        self.threads: List[threading.Thread] = []
        self.running = False

    def get_topic_partitions(self, topic: str, consumer: Consumer) -> int:
        """获取指定主题的分区列表"""
        if topic in self._partition_cache:
            return self._partition_cache[topic]
        try:
            metadatas = consumer.list_topics(topic)
            count = len(metadatas.topics[topic].partitions)
            self._partition_cache[topic] = count
            return count
        except Exception as e:
            logger.error(f"获取主题分区列表失败: {traceback.format_exc()}")
            raise

    def get_assigned_partitions(self, topic: str, consumer: Consumer) -> List[int]:
        """根据分区策略分配分区"""
        if not self.partition_strategy:
            return None
        topic_partitions = self.get_topic_partitions(topic, consumer)
        assert self.partition_strategy.num_partitions <= topic_partitions, f"num_partitions ({self.partition_strategy.num_partitions}) 超过当前topic的总partition：({topic_partitions}),以topic的分区数消费"
        # 返回分区范围 [0, num_partitions-1]
        return list(range(self.partition_strategy.num_partitions))

    def start(self):
        self.running = True
        consumer = Consumer(self.conf)
        if self.assign_partition:
            topic_partitions = [TopicPartition(topic, p) for topic in self.topics for p in self.assign_partition]
            consumer.assign(topic_partitions)
        elif self.partition_strategy:
            topic_partitions = []
            for topic in self.topics:
                partitions = self.get_assigned_partitions(topic, consumer)
                topic_partitions.extend([TopicPartition(topic, p) for p in partitions])
            consumer.assign(topic_partitions)
        else:
            consumer.subscribe(self.topics)

        self.consumers.append(consumer)
        thread = threading.Thread(target=self._consume_loop, args=(consumer,))
        thread.daemon = True
        self.threads.append(thread)
        thread.start()

    def start_with_thread(self):
        """多线程调用，先弃用"""
        if self.running:
            logger.warning("消费者已在运行")
            return

        logger.trace(
            f"启动消费者，主题: {self.topics}，并发: {self.concurrency}，批量大小: {self.batch_size}，语义: {self.delivery_semantic}")
        self.running = True

        for i in range(self.concurrency):
            consumer = Consumer(self.conf)
            if self.assign_partition:
                topic_partitions = [TopicPartition(topic, p) for topic in self.topics for p in self.assign_partition]
                consumer.assign(topic_partitions)
            elif self.partition_strategy:
                topic_partitions = []
                for topic in self.topics:
                    partitions = self.get_assigned_partitions(topic, consumer)
                    topic_partitions.extend([TopicPartition(topic, p) for p in partitions])
                consumer.assign(topic_partitions)
            else:
                consumer.subscribe(self.topics)
            self.consumers.append(consumer)

            thread = threading.Thread(target=self._consume_loop, args=(consumer, i))
            thread.daemon = True
            self.threads.append(thread)
            thread.start()

    def stop(self):
        """停止所有消费者"""
        if not self.running:
            logger.warning("消费者未运行")
            return

        logger.debug("正在停止消费者")
        self.running = False

        for consumer in self.consumers:
            try:
                consumer.close()
            except Exception as e:
                logger.error(f"关闭消费者失败: {traceback.format_exc()}")

        for thread in self.threads:
            thread.join()

        self.consumers.clear()
        self.threads.clear()
        logger.debug("所有消费者已停止")

    def _consume_loop(self, consumer: Consumer, thread_id: Optional[int] = None):
        """单个消费者"""
        while self.running:
            try:
                messages = consumer.consume(num_messages=self.batch_size, timeout=1.0)
                if not messages:
                    continue
                batch = []
                for msg in messages:
                    if msg.error():
                        if msg.error().code() == KafkaError._PARTITION_EOF:
                            logger.debug(f"consumer {consumer} 到达分区 {msg.partition()} 的末尾")
                        else:
                            logger.error(f"consumer {consumer} 消费错误: {msg.error()}")
                        continue

                    key = msg.key().decode('utf-8') if msg.key() else None
                    # value = msg.value().decode('utf-8') if msg.value() else None
                    value = json.loads(msg.value().decode('utf-8')) if msg.value() else None
                    partition = msg.partition()
                    offset = msg.offset()
                    batch.append({
                        'key': key,
                        'value': value,
                        'partition': partition,
                        'offset': offset,
                        'topic': msg.topic()
                    })

                if not batch:
                    continue

                try:
                    receive_msg = self.listen.listen_batch(batch)
                    if self.delivery_semantic == DeliverySemantic.AT_MOST_ONCE.name:
                        consumer.commit(asynchronous=False)

                    elif self.delivery_semantic == DeliverySemantic.AT_LEAST_ONCE.name:
                        if receive_msg.status:
                            consumer.commit(asynchronous=False)
                        else:
                            continue

                    elif self.delivery_semantic == DeliverySemantic.EXACTLY_ONCE.name:
                        if receive_msg.status:
                            # 成功时提交当前批次各分区最大offset
                            partition_offsets = {}
                            for msg in batch:
                                tp = TopicPartition(msg['topic'], msg['partition'], msg['offset'] + 1)
                                if tp not in partition_offsets or msg['offset'] + 1 > partition_offsets[tp].offset:
                                    partition_offsets[tp] = tp
                            consumer.commit(offsets=list(partition_offsets.values()), asynchronous=False)
                        else:
                            # 失败时不提交offset，并回滚到批次起始offset
                            start_offset = min(msg['offset'] for msg in batch)
                            logger.warning(f"消费者业务处理失败，offset不提交，将回滚到 {start_offset}")
                            # 检查重试次数
                            retry_exceeded = False
                            for msg in batch:
                                msg['retry_count'] = msg.get('retry_count', 0) + 1
                                if msg['retry_count'] >= self.max_retries:
                                    logger.error(f"消息 {msg} 达到最大重试次数 {self.max_retries}，移入死信队列")
                                    self.dead_letter_queue.append(msg)
                                    retry_exceeded = True
                            if retry_exceeded:
                                # 如果有消息达到最大重试次数，提交offset以跳过这些消息
                                partition_offsets = {}
                                for msg in batch:
                                    tp = TopicPartition(msg['topic'], msg['partition'], msg['offset'] + 1)
                                    if tp not in partition_offsets or msg['offset'] + 1 > partition_offsets[tp].offset:
                                        partition_offsets[tp] = tp
                                consumer.commit(offsets=list(partition_offsets.values()), asynchronous=False)
                                continue
                            # 回滚到批次起始offset
                            for msg in batch:
                                tp = TopicPartition(msg['topic'], msg['partition'], start_offset)
                                consumer.seek(tp)
                            continue

                except Exception as e:
                    logger.error(f"业务处理异常: {traceback.format_exc()}")
                    if self.delivery_semantic == DeliverySemantic.EXACTLY_ONCE.name:
                        # 异常时不提交offset，并回滚到批次起始offset
                        start_offset = min(msg['offset'] for msg in batch)
                        logger.warning(f"业务异常，offset不提交，将回滚到 {start_offset}")
                        for msg in batch:
                            msg['retry_count'] = msg.get('retry_count', 0) + 1
                            if msg['retry_count'] >= self.max_retries:
                                logger.error(f"消息 {msg} 达到最大重试次数 {self.max_retries}，移入死信队列")
                                self.dead_letter_queue.append(msg)
                        if any(msg['retry_count'] >= self.max_retries for msg in batch):
                            # 提交offset以跳过达到最大重试次数的消息
                            partition_offsets = {}
                            for msg in batch:
                                tp = TopicPartition(msg['topic'], msg['partition'], msg['offset'] + 1)
                                if tp not in partition_offsets or msg['offset'] + 1 > partition_offsets[tp].offset:
                                    partition_offsets[tp] = tp
                            consumer.commit(offsets=list(partition_offsets.values()), asynchronous=False)
                            continue
                        # 回滚到批次起始offset
                        for msg in batch:
                            tp = TopicPartition(msg['topic'], msg['partition'], start_offset)
                            consumer.seek(tp)
                        continue

            except Exception as e:
                logger.error(f"Kafka 异常: {traceback.print_exc()}")
                time.sleep(1)

        logger.debug(f"消费者停止")
