import traceback
from typing import Dict, List, Optional

from basic_support.logger.logger_config import logger
from confluent_kafka import KafkaException
from confluent_kafka.admin import AdminClient, NewTopic


class TopicManager:
    """
    Kafka 主题管理类
    """

    def __init__(self, bootstrap_servers: str, config: Optional[Dict] = None):
        """
        初始化 TopicManager
        """
        self.bootstrap_servers = bootstrap_servers
        self.config = config or {}
        self.config["bootstrap.servers"] = bootstrap_servers
        try:
            self.admin_client = AdminClient(self.config)
            logger.debug(f"成功连接到kafka集群{bootstrap_servers}")
        except KafkaException as e:
            logger.error(f"kafka集群连接失败：{traceback.format_exc()}")
            raise

    def create_topic(
            self,
            topic_name: str,
            num_partitions: int = 1,
            replication_factor: int = 1,
            topic_config: Optional[Dict] = None
    ) -> bool:
        """
        创建 Kafka 主题。
        retention.ms 保留时间，单位MS
        retention.bytes 保留大小，单位K
        """
        try:
            new_topic = NewTopic(
                topic=topic_name,
                num_partitions=num_partitions,
                replication_factor=replication_factor,
                config=topic_config or {}
            )
            # 异步创建主题
            fs = self.admin_client.create_topics([new_topic])
            # 等待创建结果
            for topic, f in fs.items():
                try:
                    f.result()  # 阻塞直到创建完成
                    logger.debug(f"主题 '{topic}' 创建成功")
                    return True
                except KafkaException as e:
                    logger.error(f"主题创建失败 '{topic}': {e}")
                    return False
        except Exception as e:
            logger.error(f"主题创建失败'{topic_name}': {e}")
            return False

    def delete_topic(self, topic_name: str) -> bool:
        """
        删除 Kafka 主题。
        """
        try:
            fs = self.admin_client.delete_topics([topic_name])
            for topic, f in fs.items():
                try:
                    f.result()  # 阻塞直到删除完成
                    logger.debug(f"主题 '{topic}'删除成功")
                    return True
                except KafkaException as e:
                    logger.error(f"主题删除失败'{topic}': {traceback.format_exc()}")
                    return False
        except Exception as e:
            logger.error(f"主题删除失败{topic_name}': {traceback.format_exc()}")
            return False

    def list_topics(self) -> List[str]:
        """
        获取所有主题列表。
        """
        try:
            cluster_metadata = self.admin_client.list_topics(timeout=10)
            topics = [
                topic for topic in cluster_metadata.topics.keys()
                # 过滤内部主题（如 __consumer_offsets）
                if not topic.startswith("_")
            ]
            logger.debug(f"共计主题数： {len(topics)} ")
            return topics
        except KafkaException as e:
            logger.error(f"获取主题失败: {e}")
            return []

    def describe_topic(self, topic_name: str) -> Optional[Dict]:
        """
        获取指定主题的详细信息。
        """

        try:
            cluster_metadata = self.admin_client.list_topics(timeout=10)
            if topic_name not in cluster_metadata.topics:
                logger.error(f"主题 '{topic_name}' 不存在")
                return None

            topic_metadata = cluster_metadata.topics[topic_name]
            topic_info = {
                "topic": topic_name,
                "partitions": len(topic_metadata.partitions),
                "replication_factor": len(
                    topic_metadata.partitions[0].replicas) if topic_metadata.partitions else 0,
            }
            logger.debug(f"主题详情'{topic_name}'获取成功(simplified)")
            return topic_info

        except KafkaException as e:
            logger.error(f"获取主题失败'{topic_name}': {traceback.format_exc()}")
            return None

    def close(self):
        """
        关闭 AdminClient 连接。
        """
        if self.admin_client:
            logger.debug("关闭客户端")
            self.admin_client = None



