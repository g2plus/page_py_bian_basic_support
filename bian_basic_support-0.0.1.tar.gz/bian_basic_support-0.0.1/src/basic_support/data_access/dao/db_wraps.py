#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: db_wraps.py
@Description: 数据库操作相关装饰器
@time: 2024/1/25 8:46
"""

from functools import wraps
from typing import Callable, Iterable, Dict, Any

from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao

from basic_support.comm_funcs.comm_utils import iter_slice_tool

from basic_support.logger.logger_config import logger

from basic_support.data_access.dao.dao_utils import DaoUtils


def write_to_db(dao: AbstractRdbDao, output_table: str, is_write_to_db: bool = True, batch_size: int = 1000):
    """
    输出到关系库的装饰器
    :param dao: dao对象
    :param batch_size: 单批量写入大小
    :param is_write_to_db: 是否输出到关系库
    :param output_table:
    :return:
    """

    def write_func(func: Callable[..., Iterable[Dict[str, Any]]]):
        inserter = None

        @wraps(func)
        def inner(*args, **kwargs):
            nonlocal inserter
            data_iter = func(*args, **kwargs)
            if data_iter is None:
                return data_iter
            for k, records in iter_slice_tool(data_iter, batch_size=batch_size):
                records = list(records)
                if is_write_to_db:
                    if inserter is None:
                        inserter, sql = DaoUtils.utils_inject_insert_sql_with_params(dao=dao, table_name=output_table,
                                                                                     params=list(records[0].keys()))
                    inserter(records)
                logger.info(f"{output_table}{'' if is_write_to_db else '[模拟]'}入库完成, 记录数为: {len(records)}")

            logger.info(f"入库任务结束")
            return data_iter

        return inner

    return write_func
