#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: rdb_meta.py
@Description: 
@time: 2020/7/16 16:35
"""
from basic_support.comm_classes.mixin_class import ReprMixin


class RdbSchema(ReprMixin):
    """
    关系库的字段名 + py字段类型
    """
    __slots__ = ('col_name', 'col_type')

    def __init__(self,
                 col_name,
                 col_type):
        self.col_name = col_name
        self.col_type = col_type

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"col_name: {self.col_name} col_type: {self.col_type}"
