from abc import ABC, abstractmethod

from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao


class AbsDataSourceFinder(ABC):

    def __init__(self):
        """
        数据元查找器抽象基类
        """
        pass

    @abstractmethod
    def find(self,
             classifier_stat_id: str,
             meta_db_dao: AbstractRdbDao
             ) -> "AbsDataSourceInfo" or None:
        """
        查找数据源信息
        :param classifier_stat_id: 表元信息id
        :param meta_db_dao: 元信息库dao
        :return:
        """
        raise Exception("未实现的抽象方法！")


class AbsDataSourceInfo(ABC):

    def __init__(self, db_type: str):
        self.db_type = db_type
