from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao
from basic_support.data_access.data_sources.data_source_finder_abs import AbsDataSourceFinder, AbsDataSourceInfo


class EsDataSourceFinder(AbsDataSourceFinder):

    def __init__(self):
        super().__init__()

    def find(self, classifier_stat_id: str, meta_db_dao: AbstractRdbDao) -> "EsDataSourceInfo" or None:
        pass


class EsDataSourceInfo(AbsDataSourceInfo):
    pass
