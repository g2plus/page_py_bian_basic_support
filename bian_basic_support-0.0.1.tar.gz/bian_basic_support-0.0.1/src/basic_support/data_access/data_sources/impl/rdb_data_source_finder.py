from basic_support.comm_funcs.dragon_decrypt import dragon_decrypt
from basic_support.data_access.dao.rdb_dao_abs import AbstractRdbDao
from basic_support.data_access.data_sources.data_source_finder_abs import AbsDataSourceFinder, AbsDataSourceInfo


class RdbDataSourceFinder(AbsDataSourceFinder):

    def __init__(self):
        """
        关系库数据源查找器
        """
        super().__init__()

    def find(self,
             classifier_stat_id: str,
             meta_db_dao: AbstractRdbDao
             ) -> "RdbDataSourceInfo" or None:
        sql = f"""
            select cs.db_type, rdb_cl.user_name, rdb_cl.password, mc.ip_address, dc.port, 
            rdb_sc.code db_ins, rdb_cl.name db_name, rdb_cl.code db_code
            from t_md_classifier_stat cs 
            join T_MD_RDB_SCHEMA rdb_sc on cs.owner_id=rdb_sc.id 
            join T_MD_RDB_CATALOG rdb_cl on rdb_sc.owner_id=rdb_cl.id 
            join t_md_deployed_comp dc on dc.owner_id=rdb_cl.id
            join t_md_machine mc on mc.id=dc.machine_id
            where cs.id='{classifier_stat_id}' and dc.is_master='1';
        """
        item_iter = meta_db_dao.query_single_row(sql)
        item = None
        for d in item_iter:
            item = d
            break
        if item is None:
            return None
        return RdbDataSourceInfo(
            db_type=item.get("db_type"),
            user_name=dragon_decrypt(item.get("user_name")),
            password=dragon_decrypt(item.get("password")),
            ip=item.get("ip_address"),
            port=int(item.get("port")),
            db_instance=item.get("db_ins"),
            db_name=item.get("db_name"),
            db_code=item.get("db_code")
        )


class RdbDataSourceInfo(AbsDataSourceInfo):

    def __init__(self,
                 db_type: str,
                 user_name: str,
                 password: str,
                 ip: str,
                 port: int,
                 db_instance: str,
                 db_name: str,
                 db_code: str
                 ):
        """
        关系库数据源信息
        :param db_type: 数据库类型
        :param user_name: 用户名
        :param password: 密码
        :param ip: ip地址
        :param port: 端口号
        :param db_instance: 数据库实例名
        :param db_name: 数据库中文名称
        :param db_code: 数据库英文名称
        """
        super().__init__(db_type)
        self.user_name = user_name
        self.password = password
        self.ip = ip
        self.port = port
        self.db_instance = db_instance
        self.db_name = db_name
        self.db_code = db_code





