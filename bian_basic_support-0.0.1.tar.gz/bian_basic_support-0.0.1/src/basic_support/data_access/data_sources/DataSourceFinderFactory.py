from basic_support.data_access.data_sources.data_source_finder_abs import AbsDataSourceFinder
from typing import Dict

from basic_support.data_access.data_sources.impl.rdb_data_source_finder import RdbDataSourceFinder


class DataSourceFinderFactory:
    """
    数据源查找器工厂类
    """

    __DB_TYPE_DSF__: Dict[str, AbsDataSourceFinder] = {
        "RdbDataObj": RdbDataSourceFinder()  # 关系库
    }

    @staticmethod
    def get_data_source_finder(ds_type: str) -> AbsDataSourceFinder:
        """
        获取数据源查找器
        :param meta_db_dao: 元库dao
        :param ds_type: 数据源类型
        :return:
        """
        return DataSourceFinderFactory.__DB_TYPE_DSF__.get(ds_type)