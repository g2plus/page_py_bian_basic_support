#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: config_abs.py
@Description: 
@time: 2020/7/24 23:22
"""

from basic_support.comm_classes.mixin_class import EasyEqMixin
from abc import (ABC,
                 ABCMeta)


class BaseConfig(EasyEqMixin, ABC, metaclass=ABCMeta):
    def __init__(self):
        pass
