#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: rdb_config.py
@Description: 
@time: 2020/7/24 23:28
"""
from basic_support.data_access.config.config_abs import BaseConfig


class RdbConfig(BaseConfig):
    def __init__(self,
                 db_type: str,
                 host: str = None,
                 port: int or str = None,
                 user: str = None,
                 password: str = None,
                 db: str = None,
                 charset='utf8'):
        """
        关系型 数据库配置类
        @param db_type: 关系库类型
        @param host: 数据库地址
        @param port: 数据库端口
        @param user: 用户名
        @param password: 密码
        @param db: 数据库名
        @param charset: 字符集
        """
        super(RdbConfig, self).__init__()
        self.db_type = db_type
        self.host = host
        self.port = int(port) if isinstance(port, str) else port
        self.user = user
        self.password = password
        self.db = db
        self.charset = charset

    @classmethod
    def parse_conn_str(cls, string):
        from parse import parse
        pattern = '{db_type}://{user}:{password}@{host}:{port}/{db}'
        result = parse(pattern, string)
        if result is None:
            raise Exception(f'连接字符串{string}格式错误！')
        cfg = result.named
        cfg = {k: 'postgres' if v == 'postgresql' else v for k, v in cfg.items()}
        cfg = cls(**cfg)
        return cfg

    @classmethod
    def get_from_dbconfig(cls, db_config: 'DbConf'):
        return cls(db_type=db_config.db_type, host=db_config.host, port=db_config.port,
                   user=db_config.user, password=db_config.password, db=db_config.db)

    def to_sqlalchemy_conn_str(self):
        db_type = 'postgresql' if self.db_type == 'postgres' else self.db_type
        return f'{db_type}://{self.user}:{self.password}@{self.host}:{self.port}/{self.db}'

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"{self.__class__.__name__}(host: {self.host}, db: {self.db})"

# if __name__ == '__main__':
#     cof = RdbConfig('mysql', '127.0.0.1', 2999, 'hyc', 'pa', 'hyc')
#     df = {}
#     df[cof] = 5
#     cof2 = RdbConfig('pg', '127.0.0.1', 2999, 'hyc', 'pa.', 'hyc')
#     df[cof] = 5
#     df[cof2] = 6
#     print(df[cof])
#     print(df[cof2])
