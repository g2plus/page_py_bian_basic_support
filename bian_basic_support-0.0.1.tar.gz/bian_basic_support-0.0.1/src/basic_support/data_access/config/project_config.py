# @Time    : 2020/8/11 16:36
# @Author  : YuQL
# @FileName: project_config.py
# @Software: PyCharm
import os


def get_project_root_path(project_name: str) -> str:
    cur_path = os.path.abspath(os.path.dirname(__file__))
    root_path = cur_path[:max(
        cur_path.find(project_name),
        cur_path.find(project_name + "\\"),
        cur_path.find(project_name + "/")
    ) + len(project_name) + 1]
    return root_path


class ProjectConfig:
    PROJECT_NAME = "py_bian_basic_support"
    PROJECT_PATH = get_project_root_path(PROJECT_NAME)

    # __curPath = os.path.abspath(os.path.dirname(__file__))
    # __rootPath = __curPath[:__curPath.find(PROJECT_NAME + "\\") + len(PROJECT_NAME + "\\")]
    # PROJECT_PATH = str(__rootPath).replace("\\", "/")


project_config = ProjectConfig()
