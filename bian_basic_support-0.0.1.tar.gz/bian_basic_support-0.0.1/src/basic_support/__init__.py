# @Time    : 2020/7/28 17:09
# @Author  : YuQL
# @FileName: __init__.py.py
# @Software: PyCharm
"""
基础支撑模块，存放提供基础功能的代码
"""