#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v0.1
@author: narutohyc
@file: logger_config.py
@Description: 日志配置字典 + 定义logger句柄供项目使用
              Python日志库logging总结-可能是目前为止将logging库总结的最好的一篇文章:
                  https://www.jianshu.com/p/7b5e4752932e
@time: 2020/5/23 21:34
"""
import logging
import os
from enum import Enum, unique
from functools import partial
from logging import config as logging_config
from os.path import join

from colorama import init, Fore, Style

from basic_support.comm_funcs.comm_utils import find_root_path_by_resources, merge_nested_dicts, read_yaml

# 初始化 Colorama 库
init()


class ColoredFormatter(logging.Formatter):
    COLORS = {
        'DEBUG': Style.BRIGHT + Fore.BLUE,
        'INFO': Style.BRIGHT + Fore.GREEN,
        'WARNING': Fore.YELLOW,
        'ERROR': Fore.RED,
        'TRACE': Style.BRIGHT + Fore.LIGHTBLACK_EX,
        'CRITICAL': Style.BRIGHT + Fore.RED
    }
    DEFAULT_COLOR = Fore.LIGHTWHITE_EX  # Define default white color

    # def format(self, record):
    #     log_message = super().format(record)
    #     return self.COLORS.get(record.levelname, '') + log_message + Style.RESET_ALL

    def format(self, record):
        # Format the log message
        log_message = super().format(record)

        # Split the log message
        static_part, dynamic_part = log_message.split(': ', 1)

        # Apply colors
        static_part_colored = self.DEFAULT_COLOR + static_part
        dynamic_part_colored = self.COLORS.get(record.levelname, '') + dynamic_part + Style.RESET_ALL

        return static_part_colored + ': ' + dynamic_part_colored


# 获取resources路径
resources_path = find_root_path_by_resources().as_posix()
yaml_config = None
if resources_path:
    logging_yaml = os.path.join(resources_path, 'resources', 'logging.yaml')
    if os.path.exists(logging_yaml):
        yaml_config = read_yaml(yaml_path=logging_yaml)

base_log_path = join(resources_path, 'logs')

# 文件目录不存在时, 创建该目录
if not os.path.exists(base_log_path):
    os.makedirs(base_log_path)


@unique
class LogLevel(Enum):
    """ 日志等级枚举类 """
    CRITICAL = '致命'  # 严重错误,表明程序本身可能无法继续运行
    ERROR = '错误'  # 由于更严重的问题,该软件无法执行某些功能
    WARNING = '警告'  # 表明发生了意外情况,或表明在不久的将来出现了一些问题 (例如 '磁盘空间不足')。但是该软件仍在按预期工作
    INFO = '普通'  # 确认事情按预期工作
    DEBUG = '详细'  # 详细信息,通常仅在诊断问题时才有意义
    TRACE = '跟踪'  # 追踪详细执行步骤,比DEBUG更低的日志级别
    NOTSET = '不设置'  # 意指不设置,所以按照父logger级别来过滤日志


# 定义TRACE的日志级别为5，比DEBUG低
TRACE_LEVEL_NUM = 5
logging.addLevelName(TRACE_LEVEL_NUM, LogLevel.TRACE.name)


# 定义trace方法
def trace(self, message, *args, **kws):
    """
    trace级别的日志配置
    :param self:
    :param message:
    :param args:
    :param kws:
    :return:
    """
    if self.isEnabledFor(TRACE_LEVEL_NUM):
        self._log(TRACE_LEVEL_NUM, message, args, **kws, stacklevel=2)


# 将trace方法添加到Logger类中
logging.Logger.trace = trace

file_handler = {
    "rotating": {
        'info_file_handler': {
            'level': LogLevel.INFO.name,  # 信息日志等级
            'formatter': 'info',
            'class': "concurrent_log_handler.ConcurrentRotatingFileHandler",  # 多进程下多线程安全
            'filename': os.path.join(base_log_path, 'info.log'),  # 信息日志文件输出目录
            'mode': 'a+',  # 日志文件模型 a表示追加  w是覆盖写
            'encoding': 'utf-8',
            'backupCount': 4,  # 4 = 自己+历史的3个
            'maxBytes': 1024 * 1024 * 50,  # 单个日志文件大小限制在 50MB内
            'use_gzip': False,
        },
        'error_file_handler': {
            'level': LogLevel.ERROR.name,  # 错误日志等级
            'formatter': 'error',
            'class': 'logging.FileHandler',
            # 'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(base_log_path, 'error.log'),  # 错误日志文件输出目录
            'mode': 'a+',
            'encoding': 'utf-8'
        }
    }
}

file_handler_type = yaml_config.pop("file_handler_type", "rotating")

# 日志相关配置
LOGGING_CONFIG = {
    'version': 1,
    'loggers': {  # 日志，暴露函数给应用程序，基于日志记录器和过滤器级别决定哪些日志有效
        'root_logger': {  # root logger
            'level': LogLevel.TRACE.name,  # 日志等级
            'handlers': ['console_handler', 'info_file_handler', 'error_file_handler'],
        }
    },
    'handlers': {  # 处理器, 将(日志记录器产生的)日志记录发送至合适的目的地
        'console_handler': {
            'level': LogLevel.INFO.name,  # 控制台日志等级 和 最终等级=max(当前等级,loggers)
            'formatter': 'info_color',
            'class': 'logging.StreamHandler',  # 日志类
            'stream': 'ext://sys.stdout',  # 日志流
        },
        'info_file_handler': file_handler[file_handler_type]['info_file_handler'],
        'error_file_handler': file_handler[file_handler_type]['error_file_handler'],
    },
    'formatters': {  # 格式化器, 指明了最终输出中日志记录的布局
        'info': {
            'format': '%(asctime)s %(module)s:%(lineno)d %(levelname)s: %(message)s',  # 日志输出格式化
            'datefmt': '%Y-%m-%d %H:%M:%S'  # 日期格式化
        },
        'info_color': {
            '()': ColoredFormatter,  # 指定使用自定义的 ColoredFormatter
            'format': '%(asctime)s %(module)s:%(lineno)d %(levelname)s: %(message)s',  # 日志输出格式化
            'datefmt': '%Y-%m-%d %H:%M:%S'  # 日期格式化
        },
        'error': {
            # 'format': '%(asctime)s-%(levelname)s-%(name)s-%(process)d::%(module)s|%(lineno)s:: %(message)s',
            'format': '%(asctime)s %(module)s|%(lineno)s %(levelname)s|%(process)d:  %(message)s',
            'datefmt': '%Y-%m-%d %H:%M:%S'
        },
    },
}
# 根据yaml更新日志配置
if yaml_config:
    LOGGING_CONFIG = merge_nested_dicts(LOGGING_CONFIG, yaml_config)

# 获取日志实例
logging_config.dictConfig(LOGGING_CONFIG)
logger = logging.getLogger('root_logger')

# 显式添加trace日志句柄
logger.trace = partial(trace, logger)

# logger.trace("This is a debug message.")
# logger.debug("This is a debug message.")
# logger.info("This is an info message.")
# logger.warning("This is a warning message.")
# logger.error("This is an error message.")
# logger.critical("This is a critical message.")

'''
Level	    Numeric value
CRITICAL	50
ERROR	    40
WARNING	    30
INFO	    20
DEBUG	    10
TRACE	    5
NOTSET	    0
'''

'''
%(levelno)s	    打印日志级别的数值
%(levelname)s	打印日志级别名称
%(pathname)s	打印当前执行程序的路径
%(filename)s	打印当前执行程序名称
%(funcName)s	打印日志的当前函数
%(lineno)d	    打印日志的当前行号
%(asctime)s	    打印日志的时间
%(thread)d	    打印线程id
%(threadName)s	打印线程名称
%(process)d	    打印进程ID
%(message)s	    打印日志信息

作者：mac在路上
链接：https://www.jianshu.com/p/1e08cca7e587
'''

""" 其他配置

# 按照文件大小做日志分隔，多线程下安全，多进程下不可用
'info_file_handler': {
            'level': LogLevel.INFO.name,  # 信息日志等级
            'formatter': 'info',
            'class': 'logging.handlers.RotatingFileHandler', # 单进程下多线程安全
            'filename': os.path.join(base_log_path, 'info.log'),  # 信息日志文件输出目录
            'mode': 'a+',  # 日志文件模型 a表示追加  w是覆盖写
            'encoding': 'utf-8',
            'maxBytes': 1024 * 1024 * 20,  # 20Mb
            'backupCount': 3
        }

"""
