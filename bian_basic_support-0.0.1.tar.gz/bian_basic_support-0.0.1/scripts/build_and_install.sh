#!/bin/bash

cd ..
if [ $# -eq 1 ]; then
    # 如果传入了一个参数，则执行 conda activate 参数
    source activate "$1"
fi

python setup.py bdist_wheel sdist

#!/bin/bash

dist_folder="dist"

for whl_file in $dist_folder/*.whl; do
    echo "Installing: $whl_file"
    pip install --user --force-reinstall -i https://pypi.tuna.tsinghua.edu.cn/simple  --trusted-host=pypi.tuna.tsinghua.edu.cn/simple "$whl_file"
done

echo "All .whl files in the 'dist' directory have been built and installed."
