#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: setup.py.py
@Description: https://blog.csdn.net/weixin_43940314/article/details/128349554
@time: 2023/8/2 8:46
"""
import shutil
from pathlib import Path
import os
from setuptools import setup, find_packages
import platform

# import tempfile

# 创建临时文件夹作为 build 文件夹
# build_temp = tempfile.mkdtemp()

# 包版本
VERSION = '0.0.1'
# 包作者
AUTHOR = "huangyc"
# 作者邮箱
AUTHOR_EMAIL = "1832044043@qq.com"
# 包名称
NAME = "bian-basic-support"
# 包的简单描述
DESCRIPTION = 'python公用基础能力提供包'
# 包的关键词
KEYWORDS = ['python', 'db_dao', ]
# 安装时需要安装的依赖包
INSTALL_REQUIRES = ['concurrent-log-handler==0.9.20',  # 多线程下的日志记录
                    'DBUtils==3.0.2',  # 数据库相关依赖库
                    'PyMySQL==1.0.2',  # 数据库相关依赖库
                    'psycopg==3.1.4',  # 数据库相关依赖库
                    'psycopg-binary==3.1.4',  # 数据库相关依赖库
                    'psycopg2-binary==2.9.5',
                    'PyYAML',  # yaml解析
                    ]  # 数据库相关依赖库

dir_path = Path('.')
for file in dir_path.iterdir():
    # 避免缓存引起的奇怪问题
    if file.is_dir() and (file.name.endswith('egg-info') or file.name == 'build' or file.name == 'dist'):
        shutil.rmtree(file.name)
        print(f"删除[{file.name}]文件夹")

setup(
    # 包名称
    name=NAME,
    # 包版本
    version=VERSION,
    # 包作者
    author=AUTHOR,
    # 作者邮箱
    author_email=AUTHOR_EMAIL,
    # 包的简单描述
    description=DESCRIPTION,
    # 包详细描述的内容类型
    long_description_content_type="text/markdown",
    # 包的详细描述
    long_description=open('README.md', encoding="UTF8").read() if os.path.exists('README.md') else "未设置README.md",

    # 需要打包的包
    # packages=find_packages('src'),
    packages=find_packages('src', exclude=find_packages(include=['tests', 'tests.*'])),
    package_dir={'': 'src'},
    # exclude_package_data={'tests': ['data_access/*']},
    # 安装时需要安装的依赖包
    install_requires=INSTALL_REQUIRES,

    # include_package_data=True,
    # 其他 setup 配置
    # cmdclass={
    #     'clean': CleanCommand,
    # },

    # 包的关键词
    keywords=KEYWORDS,
    # 打包时需要打包的数据文件，比如图片、配置文件等
    data_files=[],  #
    # 一个字典，用于定义你的 Python 项目的入口点。入口点允许你将某些功能或插件注册到特定的名称下，供其他程序或工具使用
    # 一个常见的使用场景是在你的项目中注册一个命令行工具
    entry_points={},
    # 授权信息
    license="MIT",
    # 官网地址
    url="https://www.github.com",
    # 指定可执行的脚本，安装时脚本会被安装到系统 PATH 路径下
    scripts=[f"scripts/build_and_install.{'sh' if platform.system().lower() == 'linux' else 'bat'}"],
    # 包所属分类列表：用于指定你的 Python 项目的分类信息
    # 这些分类信息通常用于指定你的项目适用于哪些操作系统、Python 版本、开发状态等
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows"
    ],
    platforms=['Windows', 'Linux'],
    # 将 build 文件夹设置为临时文件夹
    # options={'build': {'build_base': build_temp}},
)

"""
entry_points和scripts有什么不一样
* entry_points：允许你将项目注册为一个命令行工具，并指定可执行的函数或方法
* scripts：允许你将指定的脚本复制到用户的可执行路径中，以便用户可以直接运行这些脚本
"""

if os.path.exists('./src'):
    src_dir_path = Path('./src')
    for file in src_dir_path.iterdir():
        # 避免缓存引起的奇怪问题
        if file.is_dir() and (file.name.endswith('egg-info')):
            file_path = os.path.join('.', 'src', file.name)
            shutil.rmtree(file_path)
            print(f"删除[{file_path}]文件夹")
